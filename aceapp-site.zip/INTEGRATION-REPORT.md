# Aceapp v8 — integrated anatomy plate pass

## Newly reviewed foundation plates

- `1000093623.png` — **PASS**. Clean anterior + right-lateral anatomical model; used for Anatomical Position and Core Directional Terms.
- `1000093635.png` — **PASS but redundant** with the second proximal/distal plate; not shipped because one plate is enough.
- `1000093636.png` — **PASS / selected** for Proximal & Distal. Shoulder and hip attachment points are clear and both limbs remain readable on mobile.
- `1000093637.png` — **PASS** for Superficial & Deep. Layer ordering is visually clear; Aceapp adds the active depth overlay.
- `1000093638.png` — **PASS** for Ipsilateral/Contralateral and Bilateral/Unilateral. Aceapp highlights the relevant limb pairing or kidney pair dynamically.
- `1000093639.png` — **DO NOT USE** for supine/prone. It is a standing anterior/posterior plate and is superseded by the actual horizontal-position plate.
- `1000093640.png` — **PASS** for Supine & Prone.
- `1000093641.png` — **PASS** for Dorsal/Plantar and medial/lateral foot-side teaching. Hallux side is used as the medial/tibial reference.
- `1000093622.png` — **RETIRED**. The old merged directional/planes poster is too dense and contains material already replaced by smaller activities.
- `1000093621.png` — **PASS**. Corrected parasagittal teaching card.

## Previously accepted replacements now included

- Skull — anterior: `1000093607.png`
- Skull — lateral: `1000093608.png`
- Skull — inferior: `1000093609.png`
- Vertebral column: `1000093600.png`
- Skin section: `1000093602.png`
- Hair follicle: `1000093605.png`
- Inferior brain / cranial nerves overview: `1000093606.png` (quiz remains restricted to the clearly resolvable nerves)
- Transverse plane teaching card: `1000093611.png`
- Corrected midsagittal teaching card: `midsagittal_plane_anatomy_made_simple.png`
- Corrected frontal/coronal teaching card: `1000093613.png`
- Oblique teaching card: `1000093618.png`
- Final clean abdominopelvic 3×3 organ plate: `anatomical_abdomen_with_nine_region_grid.png`

## Product changes wired into v8

- Renamed the first category to **Foundations & Anatomical Terms**.
- Added **Anatomical Position** as the first activity.
- Rebuilt **Core Directional Terms** around the clean two-view anatomical model.
- Added separate activities for **Proximal & Distal**, **Superficial & Deep**, **Relationship Terms**, **Supine & Prone**, and **Foot Surface & Side Terms**.
- Body planes use the child-friendly analogy/section cards in Learn mode, while the quiz keeps a clean dynamic plane highlight.
- Abdominopelvic regions now use the real-organ plate and shade the **entire region** dynamically.
- Quiz wording can now be activity-specific (for example, “Which anatomical plane is highlighted?” rather than always “What structure is highlighted?”).
- Added `multi` and `arrow` annotation types to the overlay engine.
- Updated the first-run sequence to: Anatomical Position → Core Directional Terms → Body Planes & Sections → Cell Structure → Body Cavities → Nine Abdominopelvic Regions → the remaining relationship/position sets.
- Accepted high-resolution skull, column, skin, hair and cranial overview artwork is now used in the source; existing audited hotspot data was proportionally migrated to the new plate coordinate spaces.

## Still held

**Hand Surface & Side Terms** (Palmar, Dorsal hand, Radial, Ulnar) remains hidden with `qualityHold: true` because no dedicated hand-surface plate is present in the current uploaded set. A full-body hand crop is too small for Aceapp's mobile standard, so it was not forced into production.

The next generated hand plate should show the same hand in palmar and dorsal views with enough distal forearm to make radius/thumb side and ulna/little-finger side obvious.
