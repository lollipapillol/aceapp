# Aceapp diagram improvement backlog — v7

Status key: **P1 = fix/regenerate first**, **P2 = improve after launch-critical set**, **P3 = keep unless annotation audit finds a problem**.

Important: this list is a working backlog, not a claim that every P3 hotspot is already perfect. Each replacement plate must be visually re-audited before its annotations are trusted.

| Priority | Plate | System | Activity | Current size | Action | Why |
|---|---|---|---|---:|---|---|
| P1 | endo-glands.jpg | Endocrine System | Endocrine Glands | 560×840 | Redesign | Whole-body overview makes several endocrine targets tiny. Use overview plus dedicated regional plates or a much larger composition. |
| P1 | hair.jpg | Integumentary System | Hair Follicle, Longitudinal Section | 300×450 | Regenerate | 300×450; cuticle and follicular layers are not separable enough. |
| P1 | nail.jpg | Integumentary System | Nail, Sagittal Section | 430×229 | Regenerate | 430×229; sagittal structures are vertically compressed. |
| P1 | skin.jpg | Integumentary System | Skin, Section | 400×346 | Regenerate | 400×346; layers and glands are crowded for bracket/region teaching. |
| P1 | musc2-headneck.jpg | Muscular System | Head & Neck, Lateral | 300×473 | Regenerate | 300×473; too little resolution for small facial/neck muscles. |
| P1 | musc2-torsodeep.jpg | Muscular System | Torso, Deep Layer | 320×480 | Regenerate | 320×480; deep muscle/rib relationships deserve a larger plate. |
| P1 | nervous-cranial.jpg | Nervous System | Cranial Nerves | 620×678 | Regenerate | Inferior brain is not resolving all cranial nerves fairly at mobile size. Build a high-resolution CN I–XII plate with deliberate separation. |
| P1 | respir-tract.jpg | Respiratory System | Respiratory Tract | 560×700 | Retire | Known incorrect right-lung lobe depiction. Keep only as source archive; use upper-airway replacement and respir-lungs.jpg for lung anatomy. |
| P1 | skel-cervical.jpg | Skeletal System | Cervical Vertebrae | 460×154 | Regenerate | Very short 460×154 composite; C1/C2/typical cervical vertebrae are too small. |
| P1 | skel-column.jpg | Skeletal System | Vertebral Column, Lateral | 160×905 | Regenerate | Only 160 px wide; curves and individual levels are difficult to inspect on mobile. |
| P1 | skel-skullant.jpg | Skeletal System | Skull, Anterior | 330×469 | Regenerate | 330 px wide; facial foramina and small landmarks are too compressed. |
| P1 | skel-skullinf.jpg | Skeletal System | Skull, Inferior | 330×452 | Regenerate | 330 px wide; skull-base foramina and processes need more resolution and cleaner separation. |
| P1 | skel-skulllat.jpg | Skeletal System | Skull, Lateral | 400×381 | Regenerate | 400 px wide; improve small landmarks and temporal-region detail. |
| P2 | digest-tract.jpg | Digestive System | Digestive Tract | 560×840 | Keep + annotate | Good overview, but small organs/segments should use broader region highlights instead of points. |
| P2 | plates-lateral.jpg | Muscular System | Facial Muscles I — Scalp, Eye & Nose / Facial Muscles II — Mouth & Cheek / Facial Muscles III — Jaw & Neck | 400×529 | Regenerate | 400×529; facial muscles need finer boundaries. |
| P2 | plates-oblique.jpg | Muscular System | Facial Muscles I — Scalp, Eye & Nose / Facial Muscles II — Mouth & Cheek / Facial Muscles III — Jaw & Neck | 370×530 | Regenerate | 370×530; facial muscles need finer boundaries. |
| P2 | posterior.jpg | Muscular System | Back Muscles / Posterior Head & Neck | 380×504 | Regenerate | 380×504; posterior head/neck detail is limited. |
| P2 | torso-anterior.jpg | Muscular System | Torso I — Chest, Shoulder & Arm / Torso II — Abdomen & Back | 360×439 | Regenerate | 360×439; usable but soft for multi-muscle identification. |
| P2 | torso-posterior.jpg | Muscular System | Torso I — Chest, Shoulder & Arm / Torso II — Abdomen & Back | 360×446 | Regenerate | 360×446; usable but soft for posterior muscle boundaries. |
| P2 | repro-femaleinternal.jpg | Reproductive System | Female Internal Organs | 600×435 | Keep + annotate | Good plate; uterine tube/uterus/cervix/ovary are suited to polygons/ellipses. |
| P2 | repro-maleinternal.jpg | Reproductive System | Male Internal Organs | 445×457 | Keep + annotate | Good plate; several long ducts/glands should use line/area annotations rather than points. |
| P2 | skel-foot.jpg | Skeletal System | Foot | 560×672 | Improve | Many small bones; higher-resolution dorsal foot would make tarsal distinctions more reliable. |
| P2 | skel-hand.jpg | Skeletal System | Hand | 440×939 | Improve | Many small bones on a narrow 440×939 plate; zoom helps, but a wider dedicated carpal/hand layout would be clearer. |
| P2 | skel-wrist.jpg | Skeletal System | Carpal Bones | 520×584 | Keep + annotate | Carpal plate is useful; convert whole-bone targets to polygon/ellipse highlights where feasible. |
| P2 | senses-ear.jpg | Special Senses | Ear, Coronal Section | 620×413 | Improve | Dense anatomy at 620×413; consider a larger dedicated ear plate for ossicles and inner-ear targets. |
| P3 | cardio-heartext.jpg | Cardiovascular | Heart, Anterior View | 620×703 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | cardio-section.jpg | Cardiovascular | Heart, Coronal Section | 620×678 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | cell-structure.jpg | Cellular Level | Cell Structure | 620×620 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | digest-stomach.jpg | Digestive System | Stomach | 620×567 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | musc-abwall.jpg | Muscular System | Abdominal Wall, Layers | 620×567 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | musc-cuff.jpg | Muscular System | Posterior Rotator Cuff & Teres Major | 620×567 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | musc-leg.jpg | Muscular System | Leg | 620×567 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | musc-thigh.jpg | Muscular System | Thigh | 620×567 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | musc-triceps.jpg | Muscular System | Triceps Brachii | 560×840 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | plates-anterior.jpg | Muscular System | Facial Muscles I — Scalp, Eye & Nose / Facial Muscles II — Mouth & Cheek / Facial Muscles III — Jaw & Neck | 485×656 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | nervous-brainmid.jpg | Nervous System | Brain, Midsagittal | 620×520 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | nervous-cordsection.jpg | Nervous System | Spinal Cord, Cross Section | 600×537 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | terms-cavities.jpg | Planes, Sections & Anatomical Terms | Body Cavities | 560×840 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | terms-directional.jpg | Planes, Sections & Anatomical Terms | Directional Terms | 560×840 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | respir-alveoli.jpg | Respiratory System | Alveoli and Gas Exchange | 620×511 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | respir-lungs.jpg | Respiratory System | Lungs and Bronchial Tree | 560×613 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | skel-clavicle.jpg | Skeletal System | Clavicle | 620×496 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | skel-femur.jpg | Skeletal System | Femur | 620×496 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | skel-hip-lat.jpg | Skeletal System | Hip Bone, Lateral | 520×662 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | skel-humerus.jpg | Skeletal System | Humerus | 620×496 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | skel-pelvis.jpg | Skeletal System | Pelvis, Anterior | 620×319 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | skel-scapula-ant.jpg | Skeletal System | Scapula, Anterior | 620×499 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | skel-scapula-post.jpg | Skeletal System | Scapula, Posterior | 620×497 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | skel-thorax.jpg | Skeletal System | Thoracic Cage | 620×496 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | skel-tibfib.jpg | Skeletal System | Tibia and Fibula | 560×672 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | skel-ulnarad.jpg | Skeletal System | Ulna and Radius | 560×840 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |
| P3 | senses-eye.jpg | Special Senses | Eye, Sagittal Section | 600×533 | Keep | Current artwork is broadly suitable; continue annotation-by-annotation visual checking. |

## Additional active v6/v7 derived plate

- **respir-upperairway.jpg — P1 improve.** The crop safely removes the known incorrect lung-teaching portion, but the current derived asset is small. Replace it with a purpose-built high-resolution upper-airway sagittal/anterior composition showing nasal cavity, oral cavity, pharynx, epiglottis, larynx and trachea without requiring a lung overview.

## Current held structures

- Cranial nerves IV and VIII–XII, plus CN VII in the current inferior-brain quiz, remain held until a clearer cranial-nerve plate exists.
- Ulnar styloid process remains held on the current ulna/radius plate.
- Conoid tubercle remains held on the current clavicle plate.
- Hair cuticle remains held until a higher-resolution follicle plate clearly resolves it.

## Review order for future sessions

1. Cranial nerves
2. Skull anterior / inferior / lateral
3. Cervical vertebrae
4. Vertebral column
5. Skin
6. Hair follicle
7. Nail
8. Head & neck lateral muscles
9. Deep torso muscles
10. Endocrine overview / regional redesign
11. Facial and torso low-resolution plates
12. Ear / hand / foot dense-detail plates
13. Remaining P3 plates, one activity at a time