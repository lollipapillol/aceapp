# Aceapp replacement-plate prompts — Batch 1

These prompts are for **replacement source artwork**, not for the in-app overlay. Do not draw labels, arrows, circles, hotspot markers, letters, legends, borders, or watermarks into the image. Aceapp adds those separately.

Keep a consistent high-resolution medical-atlas style, neutral natural tissue colors, clean white background, realistic proportions, and enough separation around every target for mobile hotspot use.

---

## 1) Inferior brain — complete cranial nerves I–XII

Create a high-resolution medical atlas illustration of the **inferior surface of the adult human brain viewed directly from below**, centered on a pure white background. Show the inferior frontal and temporal lobes, optic apparatus, midbrain, pons, medulla, cerebellum, and upper cervical continuation with realistic proportions.

The plate is specifically for interactive identification of the cranial nerves. All **twelve paired cranial nerves** must be anatomically connected to their correct origins and visually separable enough for independent hotspots on a phone screen.

Required anatomy:
- CN I: olfactory bulbs and tracts on the inferior frontal lobes.
- CN II: optic nerves converging at a clearly visible optic chiasm, with optic tracts continuing posteriorly.
- CN III: oculomotor nerves emerging from the interpeduncular region of the ventral midbrain.
- CN IV: very thin trochlear nerves originating dorsally and wrapping around the midbrain so a visible lateral/inferior course can be identified.
- CN V: large trigeminal roots emerging from the lateral pons.
- CN VI: abducens nerves emerging close to the midline at the pontomedullary junction.
- CN VII: facial nerves at the cerebellopontine angle.
- CN VIII: vestibulocochlear nerves immediately lateral to CN VII, but with enough visible separation that VII and VIII can be independently targeted.
- CN IX: glossopharyngeal rootlets from the upper postolivary sulcus.
- CN X: vagal rootlets inferior to CN IX.
- CN XI: accessory rootlets extending inferiorly along the lateral medulla / upper cervical region.
- CN XII: hypoglossal rootlets from the preolivary sulcus between pyramid and olive.

Do not merge CN VII/VIII into one indistinguishable bundle. Do not merge CN IX/X/XI/XII into a single rootlet fan. Preserve realistic relative nerve thicknesses: CN V large, CN IV very thin. Every nerve must visibly connect to the appropriate brain/brainstem surface.

Composition requirement: leave enough white space around the brain so Aceapp can place external leader lines without covering neighboring nerves.

No labels, no text, no numbers, no arrows, no hotspot marks.

Target output: at least 1600 px wide, preferably 2000+ px.

---

## 2) Skull series — anterior, lateral, inferior

Create **three separate high-resolution adult human skull plates** in the same medical-atlas rendering style and scale:
1. Skull — anterior view
2. Skull — true lateral view
3. Skull base — inferior view

Pure white background, isolated bone, realistic ivory/cream bone color, crisp sutures, foramina and processes.

### Anterior plate must clearly resolve
Frontal bone, nasal bones, maxilla, mandible, zygomatic bones, orbits, nasal aperture, supraorbital foramen/notch, infraorbital foramen, mental foramen, alveolar processes, mandibular body and ramus.

### Lateral plate must clearly resolve
Frontal, parietal, temporal, occipital, sphenoid and zygomatic bones; zygomatic arch; external acoustic meatus; mastoid process; styloid process; mandibular condylar process; coronoid process; mandibular notch; ramus; angle; mental foramen; major visible sutures.

### Inferior plate must clearly resolve
Foramen magnum, occipital condyles, external occipital protuberance if visible, mastoid processes, styloid processes, carotid canals, jugular foramina, foramen ovale, foramen spinosum, hard palate, incisive foramen, choanae, pterygoid plates, mandibular fossae, and zygomatic arches.

Do not hide small foramina in overly dark shadows. Do not exaggerate them beyond anatomical plausibility, but render them crisply enough for mobile identification.

No labels, no text, no arrows, no colored highlights.

Target each plate at least 1400 px on its shortest dimension.

---

## 3) Cervical vertebrae — atlas, axis, typical cervical

Create a high-resolution comparative medical atlas plate showing **three cervical vertebrae separately with generous spacing** on a pure white background:

- C1 atlas — superior view
- C2 axis — superior/anterior-superior oblique view that clearly exposes the dens
- Typical mid-cervical vertebra (C3–C6) — superior view

Keep all three at similar visual scale.

Must clearly resolve:
- vertebral foramen
- transverse foramina
- vertebral body where present
- anterior and posterior arches of atlas
- lateral masses and superior articular facets of atlas
- dens of axis
- superior articular facets of axis
- transverse processes
- bifid spinous process on the typical cervical vertebra

C1 must not be drawn with a vertebral body. C2 must have a correctly positioned dens. The typical cervical vertebra must not look thoracic or lumbar.

No labels, text, arrows, numbers or embedded markers.

Target: 1800×1000 px or larger.

---

## 4) Vertebral column — lateral curves and regions

Create a high-resolution **true lateral view of the complete adult vertebral column**, including sacrum and coccyx, on a pure white background.

The entire column must be large enough that the cervical, thoracic, lumbar, sacral and coccygeal regions are visually distinguishable on a mobile zoom view.

Requirements:
- anatomically correct 7 cervical, 12 thoracic and 5 lumbar vertebral regions
- realistic cervical lordosis, thoracic kyphosis, lumbar lordosis and sacral kyphosis
- intervertebral discs clearly visible between movable vertebral bodies
- sacrum and coccyx clearly separated
- no exaggerated scoliosis or rotation
- no ribs or pelvis unless only a very subtle neutral orientation reference is necessary; preference is isolated vertebral column

Leave open white margin on both sides for Aceapp brackets showing spinal regions/curvatures.

No labels, text, arrows, colored zones or brackets embedded in the artwork.

Target: at least 1200×2200 px.

---

## 5) Skin section — layers and appendages

Create a high-resolution medical atlas cross-section of **human hairy skin**, wide enough to show the full depth from epidermal surface through hypodermis on a pure white background.

The image is for bracket- and region-based identification.

Must clearly distinguish:
- epidermis as a thin continuous superficial layer
- dermal papillae
- papillary dermis
- reticular dermis
- hypodermis/subcutaneous adipose tissue
- hair shaft and follicle
- sebaceous gland opening into a hair follicle
- eccrine sweat gland with a duct opening directly to the skin surface
- apocrine sweat gland associated with a hair follicle
- arrector pili muscle
- dermal blood vessels

Layer boundaries must be clear and anatomically plausible. Do not make papillary and reticular dermis the same texture. Make eccrine and apocrine glands visually distinguishable by location and duct destination.

No labels, text, arrows or annotation marks.

Composition: broad horizontal skin section with enough empty margin at the right side for vertical layer brackets.

Target: at least 1800×1400 px.

---

## 6) Hair follicle — high-resolution longitudinal section

Create a high-resolution longitudinal medical atlas illustration of a **single human hair follicle** extending from the skin surface to the bulb, on a pure white background.

The follicle must be large and central rather than a tiny element within a full skin diagram.

Clearly resolve:
- hair shaft
- hair cuticle as a distinct thin outer layer of the shaft
- hair cortex
- hair medulla where present
- follicular epithelial/root sheaths
- dermal root sheath
- hair bulb
- hair matrix
- dermal papilla entering the bulb
- sebaceous gland and its duct into the follicle
- arrector pili muscle
- surrounding dermis and superficial epidermis only as context

The cuticle must be visually separable from the cortex at phone zoom scale; do not represent it as an indistinguishable one-pixel edge.

No labels, text, arrows, numbers or hotspot marks.

Target: at least 1600×2000 px.
