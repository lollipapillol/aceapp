import { useState, useEffect, useMemo } from 'react';
import {
  Flame, Heart, User, Home, Target, Lock, Check, ChevronRight, X, RotateCcw, Dumbbell, FlaskConical,
  Camera, Atom, Layers, PersonStanding, Waves, SlidersHorizontal, Repeat, Syringe, Hand, Zap,
  Minimize2, Footprints, Battery, RefreshCw, Microscope, Lightbulb, MapPin, Compass, Sparkles,
  Brain, Eye, Utensils, Wind, CreditCard, ShieldCheck, ExternalLink, LoaderCircle, Moon, Sun,
} from 'lucide-react';

// Anatomical plates are served as files rather than inlined, so this
// module stays small enough to edit and load quickly. Point this at
// wherever the plates/ folder ends up.
const PLATE_BASE = './plates/';


// ============================================================
// ANNOTATION ENGINE
// Different anatomical targets need different visual grammar:
// a tiny landmark should be pointed to, a large muscle/organ can be
// outlined or shaded, and tissue layers are clearer with brackets.
// Existing [x,y] coordinates still work as point annotations.
// ============================================================
function normalizeAnnotation(value) {
  if (!value) return null;
  if (Array.isArray(value)) return { type: 'point', x: value[0], y: value[1] };
  if (value.type) return value;
  if (value.t === 'v') return { type: 'bracket', orientation: 'vertical', x: value.x, y0: value.y0, y1: value.y1, side: value.side || 'right' };
  if (value.t === 'h') return { type: 'bracket', orientation: 'horizontal', y: value.y, x0: value.x0, x1: value.x1, side: value.side || 'top' };
  return null;
}

function AnnotationOverlay({ annotation, w, h }) {
  const a = normalizeAnnotation(annotation);
  if (!a) return null;
  const teal = '#0F6E56';
  const fill = 'rgba(15,110,86,0.13)';
  const sw = Math.max(2, w * 0.006);
  const under = sw * 2.8;

  const stroked = (path, key = 'shape') => (
    <g key={key} fill="none" strokeLinecap="round" strokeLinejoin="round">
      {path('#FFFFFF', under)}
      {path(teal, sw)}
    </g>
  );

  if (a.type === 'multi') {
    return <g>{(a.items || []).map((item, i) => <AnnotationOverlay key={i} annotation={item} w={w} h={h} />)}</g>;
  }

  if (a.type === 'arrow') {
    const x1 = a.x1, y1 = a.y1, x2 = a.x2, y2 = a.y2;
    const dx = x2 - x1, dy = y2 - y1;
    const len = Math.max(1, Math.hypot(dx, dy));
    const ux = dx / len, uy = dy / len;
    const al = Math.max(w * 0.025, 12);
    const aw = al * 0.55;
    const bx = x2 - ux * al, by = y2 - uy * al;
    const px = -uy, py = ux;
    const arrow = `${x2},${y2} ${bx + px * aw},${by + py * aw} ${bx - px * aw},${by - py * aw}`;
    return (
      <g>
        <line x1={x1} y1={y1} x2={bx} y2={by} stroke="#FFFFFF" strokeWidth={under} strokeLinecap="round" />
        <line x1={x1} y1={y1} x2={bx} y2={by} stroke={teal} strokeWidth={sw} strokeLinecap="round" />
        <polygon points={arrow} fill={teal} stroke="#FFFFFF" strokeWidth={Math.max(2, sw * 0.7)} strokeLinejoin="round" />
      </g>
    );
  }

  if (a.type === 'point') {
    const x = a.x, y = a.y;
    const sx = x < w * 0.58 ? Math.min(w * 0.94, x + w * 0.16) : Math.max(w * 0.06, x - w * 0.16);
    const sy = Math.max(h * 0.06, y - h * 0.08);
    const dx = x - sx, dy = y - sy;
    const len = Math.max(1, Math.hypot(dx, dy));
    const ux = dx / len, uy = dy / len;
    const al = Math.max(w * 0.025, 10);
    const aw = al * 0.55;
    const bx = x - ux * al, by = y - uy * al;
    const px = -uy, py = ux;
    const arrow = `${x},${y} ${bx + px * aw},${by + py * aw} ${bx - px * aw},${by - py * aw}`;
    const r = Math.max(w * 0.018, 7);
    return (
      <g>
        <line x1={sx} y1={sy} x2={bx} y2={by} stroke="#FFFFFF" strokeWidth={under} strokeLinecap="round" />
        <line x1={sx} y1={sy} x2={bx} y2={by} stroke={teal} strokeWidth={sw} strokeLinecap="round" />
        <polygon points={arrow} fill={teal} stroke="#FFFFFF" strokeWidth={Math.max(2, sw * 0.7)} strokeLinejoin="round" />
        <circle cx={x} cy={y} r={r + sw * 1.2} fill="rgba(255,255,255,0.92)" />
        <circle cx={x} cy={y} r={r} fill="rgba(255,255,255,0.12)" stroke={teal} strokeWidth={sw} />
      </g>
    );
  }

  if (a.type === 'ellipse') {
    return (
      <g>
        <ellipse cx={a.cx} cy={a.cy} rx={a.rx} ry={a.ry} fill={fill} stroke="#FFFFFF" strokeWidth={under} />
        <ellipse cx={a.cx} cy={a.cy} rx={a.rx} ry={a.ry} fill={fill} stroke={teal} strokeWidth={sw} />
      </g>
    );
  }

  if (a.type === 'polygon') {
    const pts = (a.points || []).map((p) => p.join(',')).join(' ');
    return (
      <g>
        <polygon points={pts} fill={fill} stroke="#FFFFFF" strokeWidth={under} strokeLinejoin="round" />
        <polygon points={pts} fill={fill} stroke={teal} strokeWidth={sw} strokeLinejoin="round" />
      </g>
    );
  }

  if (a.type === 'area' || a.type === 'rect') {
    return (
      <g>
        <rect x={a.x} y={a.y} width={a.width} height={a.height} rx={a.rx || 0} fill={fill} stroke="#FFFFFF" strokeWidth={under} />
        <rect x={a.x} y={a.y} width={a.width} height={a.height} rx={a.rx || 0} fill={fill} stroke={teal} strokeWidth={sw} />
      </g>
    );
  }

  if (a.type === 'bracket') {
    if (a.orientation === 'horizontal') {
      const y = a.y, x0 = a.x0, x1 = a.x1;
      const tick = h * 0.045 * (a.side === 'bottom' ? 1 : -1);
      const path = (stroke, width) => (
        <path d={`M ${x0} ${y + tick} L ${x0} ${y} L ${x1} ${y} L ${x1} ${y + tick}`} stroke={stroke} strokeWidth={width} />
      );
      return stroked(path, 'hbracket');
    }
    const x = a.x, y0 = a.y0, y1 = a.y1;
    const tick = w * 0.04 * (a.side === 'left' ? -1 : 1);
    const path = (stroke, width) => (
      <path d={`M ${x + tick} ${y0} L ${x} ${y0} L ${x} ${y1} L ${x + tick} ${y1}`} stroke={stroke} strokeWidth={width} />
    );
    return stroked(path, 'vbracket');
  }

  return null;
}

// ============================================================
// A small, original, non-copied schematic animation of the
// sliding filament mechanism. No textbook art reproduced —
// just a generic thick/thin-filament diagram animating.
// ============================================================




// ============================================================
// LABELING SECTION — separate from the lesson/drill quizzes,
// and unlike lessons, nothing here is locked: any category or
// activity can be opened in any order. Each activity teaches
// every point first (with a mnemonic where one genuinely helps),
// then tests recall. Diagrams are simple original schematics,
// not realistic anatomical art (that needs a licensed image set
// or a commissioned illustrator) — for these specific topics a
// schematic is honestly how they're conventionally taught anyway.
// ============================================================
function AbdominopelvicDiagram({ activeName }) {
  const names = [
    'Right hypochondriac region', 'Epigastric region', 'Left hypochondriac region',
    'Right lumbar region', 'Umbilical region', 'Left lumbar region',
    'Right iliac (inguinal) region', 'Hypogastric (pubic) region', 'Left iliac (inguinal) region',
  ];
  const idx = Math.max(0, names.indexOf(activeName));
  const row = Math.floor(idx / 3), col = idx % 3;
  const P = {
    w: 1122, h: 1402,
    src: PLATE_BASE + 'foundations/abdominopelvic-regions.png',
    xs: [215, 423, 703, 910],
    ys: [145, 376, 793, 1185],
  };
  const annotation = {
    type: 'area',
    x: P.xs[col], y: P.ys[row],
    width: P.xs[col + 1] - P.xs[col],
    height: P.ys[row + 1] - P.ys[row],
    rx: 8,
  };
  const DW = 320, DH = Math.round(DW * P.h / P.w);
  return (
    <div style={{ position: 'relative', width: DW, height: DH, margin: '0 auto' }}>
      <img src={P.src} alt="Abdominopelvic organs with nine-region grid" style={{ width: DW, height: DH, display: 'block', borderRadius: 12 }} />
      <svg viewBox={`0 0 ${P.w} ${P.h}`} style={{ position: 'absolute', inset: 0, width: DW, height: DH, pointerEvents: 'none' }}>
        <AnnotationOverlay annotation={annotation} w={P.w} h={P.h} />
      </svg>
    </div>
  );
}

// Original schematic used for the foundational body planes activity.
// The active plane is a whole translucent surface rather than a tiny dot.
function BodyPlanesDiagram({ activeName }) {
  const is = (name) => activeName === name;
  return (
    <svg viewBox="0 0 280 300" width="270" height="289" className="mx-auto" aria-label="Body planes and sections">
      <ellipse cx="140" cy="38" rx="24" ry="27" fill="#F3E5D3" stroke="#D9C4A8" strokeWidth="2" />
      <path d="M117,66 Q96,79 91,111 L97,177 Q101,219 110,267 L170,267 Q179,219 183,177 L189,111 Q184,79 163,66 Z" fill="#F3E5D3" stroke="#D9C4A8" strokeWidth="2" />
      <path d="M91,92 Q67,105 65,145 L69,213" fill="none" stroke="#D9C4A8" strokeWidth="12" strokeLinecap="round" />
      <path d="M189,92 Q213,105 215,145 L211,213" fill="none" stroke="#D9C4A8" strokeWidth="12" strokeLinecap="round" />
      <path d="M121,266 L112,294 M159,266 L168,294" stroke="#D9C4A8" strokeWidth="13" strokeLinecap="round" />

      {is('Median (midsagittal) plane') && <polygon points="136,5 144,5 144,294 136,294" fill="rgba(15,110,86,0.24)" stroke="#0F6E56" strokeWidth="2" />}
      {is('Parasagittal (sagittal) plane') && <polygon points="151,9 160,10 158,291 149,290" fill="rgba(15,110,86,0.24)" stroke="#0F6E56" strokeWidth="2" />}
      {is('Frontal (coronal) plane') && <polygon points="74,45 206,45 190,283 90,283" fill="rgba(15,110,86,0.18)" stroke="#0F6E56" strokeWidth="2" />}
      {is('Transverse (horizontal) plane') && <polygon points="76,150 204,150 190,174 90,174" fill="rgba(15,110,86,0.24)" stroke="#0F6E56" strokeWidth="2" />}
      {is('Oblique plane') && <polygon points="91,102 103,94 190,214 178,222" fill="rgba(15,110,86,0.24)" stroke="#0F6E56" strokeWidth="2" />}
    </svg>
  );
}







// ============================================================
// FOUNDATION PLATES — accepted high-resolution assets generated for Aceapp.
// Text remains in the app; quiz images are clean and the overlay is dynamic.
// ============================================================
const FOUNDATION = {
  core: { w: 1536, h: 1152, src: PLATE_BASE + 'foundations/core-directions.png' },
  proximal: { w: 1536, h: 1404, src: PLATE_BASE + 'foundations/proximal-distal.png' },
  depth: { w: 1536, h: 1024, src: PLATE_BASE + 'foundations/superficial-deep.png' },
  relations: { w: 1536, h: 1024, src: PLATE_BASE + 'foundations/relationships.png' },
  positions: { w: 1536, h: 1404, src: PLATE_BASE + 'foundations/supine-prone.png' },
  footTerms: { w: 1536, h: 1404, src: PLATE_BASE + 'foundations/foot-surfaces.png' },
};

function makeStaticDiagram(src, w, h) {
  return function StaticDiagram() {
    const DW = 320, DH = Math.round(DW * h / w);
    return <img src={src} alt="Aceapp anatomy teaching plate" style={{ width: DW, height: DH, objectFit: 'contain', borderRadius: 12 }} />;
  };
}

function makeAnnotatedFoundationDiagram(key, annotations) {
  return function FoundationDiagram({ activeName }) {
    const P = FOUNDATION[key];
    const a = annotations[activeName];
    const DW = 320, DH = Math.round(DW * P.h / P.w);
    return (
      <div style={{ position: 'relative', width: DW, height: DH, margin: '0 auto' }}>
        <img src={P.src} alt="Anatomical reference model" style={{ width: DW, height: DH, objectFit: 'contain', display: 'block', borderRadius: 12 }} />
        {a && <svg viewBox={`0 0 ${P.w} ${P.h}`} style={{ position: 'absolute', inset: 0, width: DW, height: DH, pointerEvents: 'none' }}>
          <AnnotationOverlay annotation={a} w={P.w} h={P.h} />
        </svg>}
      </div>
    );
  };
}

const AnatomicalPositionDiagram = makeAnnotatedFoundationDiagram('core', {
  'Standing upright': { type: 'area', x: 275, y: 20, width: 500, height: 1080, rx: 45 },
  'Head and eyes facing forward': { type: 'ellipse', cx: 515, cy: 105, rx: 100, ry: 105 },
  'Arms at the sides': { type: 'multi', items: [
    { type: 'area', x: 265, y: 235, width: 135, height: 560, rx: 45 },
    { type: 'area', x: 640, y: 235, width: 135, height: 560, rx: 45 },
  ]},
  'Palms facing forward': { type: 'multi', items: [
    { type: 'ellipse', cx: 300, cy: 770, rx: 70, ry: 110 },
    { type: 'ellipse', cx: 745, cy: 770, rx: 70, ry: 110 },
  ]},
  'Thumbs pointing laterally': { type: 'multi', items: [
    { type: 'point', x: 248, y: 760 },
    { type: 'point', x: 797, y: 760 },
  ]},
  'Feet pointing forward': { type: 'multi', items: [
    { type: 'ellipse', cx: 435, cy: 1060, rx: 80, ry: 55 },
    { type: 'ellipse', cx: 600, cy: 1060, rx: 80, ry: 55 },
  ]},
});

const DirectionalDiagramV2 = makeAnnotatedFoundationDiagram('core', {
  'Superior': { type: 'arrow', x1: 170, y1: 600, x2: 170, y2: 115 },
  'Inferior': { type: 'arrow', x1: 170, y1: 490, x2: 170, y2: 1040 },
  'Medial': { type: 'multi', items: [
    { type: 'arrow', x1: 260, y1: 480, x2: 495, y2: 480 },
    { type: 'arrow', x1: 780, y1: 480, x2: 545, y2: 480 },
  ]},
  'Lateral': { type: 'multi', items: [
    { type: 'arrow', x1: 495, y1: 540, x2: 260, y2: 540 },
    { type: 'arrow', x1: 545, y1: 540, x2: 780, y2: 540 },
  ]},
  'Anterior': { type: 'arrow', x1: 1115, y1: 515, x2: 1325, y2: 515 },
  'Posterior': { type: 'arrow', x1: 1115, y1: 610, x2: 900, y2: 610 },
});

const ProximalDistalDiagram = makeAnnotatedFoundationDiagram('proximal', {
  'Proximal': { type: 'multi', items: [
    { type: 'arrow', x1: 355, y1: 1000, x2: 375, y2: 250 },
    { type: 'arrow', x1: 1160, y1: 1080, x2: 1125, y2: 260 },
  ]},
  'Distal': { type: 'multi', items: [
    { type: 'arrow', x1: 375, y1: 315, x2: 340, y2: 1240 },
    { type: 'arrow', x1: 1125, y1: 315, x2: 1175, y2: 1270 },
  ]},
});

const SuperficialDeepDiagram = makeAnnotatedFoundationDiagram('depth', {
  'Superficial': { type: 'area', x: 45, y: 70, width: 1120, height: 155, rx: 12 },
  'Deep': { type: 'polygon', points: [[475,410],[1320,245],[1460,320],[1440,900],[1010,910],[610,825]] },
});

const RelationshipTermsDiagram = makeAnnotatedFoundationDiagram('relations', {
  'Ipsilateral': { type: 'multi', items: [
    { type: 'area', x: 40, y: 250, width: 105, height: 350, rx: 30 },
    { type: 'area', x: 125, y: 570, width: 105, height: 390, rx: 30 },
  ]},
  'Contralateral': { type: 'multi', items: [
    { type: 'area', x: 365, y: 250, width: 105, height: 350, rx: 30 },
    { type: 'area', x: 525, y: 570, width: 105, height: 390, rx: 30 },
  ]},
  'Bilateral': { type: 'multi', items: [
    { type: 'ellipse', cx: 875, cy: 330, rx: 95, ry: 145 },
    { type: 'ellipse', cx: 1080, cy: 330, rx: 95, ry: 145 },
  ]},
  'Unilateral': { type: 'ellipse', cx: 1350, cy: 330, rx: 100, ry: 150 },
});

const BodyPositionsDiagram = makeAnnotatedFoundationDiagram('positions', {
  'Supine': { type: 'area', x: 15, y: 70, width: 1500, height: 570, rx: 45 },
  'Prone': { type: 'area', x: 15, y: 725, width: 1500, height: 575, rx: 45 },
});

const FootSurfaceTermsDiagram = makeAnnotatedFoundationDiagram('footTerms', {
  'Dorsal surface of foot': { type: 'area', x: 165, y: 70, width: 535, height: 1270, rx: 65 },
  'Plantar surface of foot': { type: 'area', x: 835, y: 70, width: 535, height: 1270, rx: 65 },
  'Tibial (medial) side of foot': { type: 'area', x: 520, y: 160, width: 115, height: 1060, rx: 40 },
  'Fibular (lateral) side of foot': { type: 'area', x: 165, y: 160, width: 115, height: 1060, rx: 40 },
});

const PlaneTeachMidsagittal = makeStaticDiagram(PLATE_BASE + 'foundations/plane-midsagittal-learn.png', 1122, 1402);
const PlaneTeachParasagittal = makeStaticDiagram(PLATE_BASE + 'foundations/plane-parasagittal-learn.png', 1202, 1308);
const PlaneTeachFrontal = makeStaticDiagram(PLATE_BASE + 'foundations/plane-frontal-learn.png', 1468, 1536);
const PlaneTeachTransverse = makeStaticDiagram(PLATE_BASE + 'foundations/plane-transverse-learn.png', 1468, 1536);
const PlaneTeachOblique = makeStaticDiagram(PLATE_BASE + 'foundations/plane-oblique-learn.png', 1468, 1536);

// ============================================================
// FACIAL MUSCLE PLATE — a real medical illustration, with our
// own pointer coordinates layered on top. Nothing is drawn by
// hand: the plate is the art, POINTS is the data.
//
// Coordinates are in the plate's own 558x683 space, so they
// stay valid at any display size. To swap in a different plate,
// replace PLATE_SRC and re-measure the points.
// ============================================================
// Two views of the same anatomy. Each carries its own plate and its
// own pointer coordinates, in that plate's native pixel space, so the
// two are independent — a muscle absent from one view simply has no
// entry there and the diagram says so.
const PLATES = {
  anterior: {
    label: 'Anterior', w: 485, h: 656,
    src: PLATE_BASE + 'plates-anterior.jpg',
    points: {
      'Frontal belly of occipitofrontalis': [175, 130], 'Temporalis': [95, 230], 'Corrugator supercilii': [212, 248],
      'Procerus': [245, 270], 'Orbicularis oculi': [175, 300], 'Nasalis': [228, 370],
      'Levator labii superioris': [197, 390], 'Zygomaticus minor': [175, 385], 'Zygomaticus major': [150, 402],
      'Masseter': [115, 420], 'Buccinator': [168, 440], 'Risorius': [155, 462],
      'Orbicularis oris': [225, 480], 'Depressor anguli oris': [190, 510], 'Depressor labii inferioris': [218, 522],
      'Mentalis': [242, 560], 'Sternocleidomastoid': [180, 600], 'Platysma': [140, 628],
    },
  },
  lateral: {
    label: 'Lateral', w: 491, h: 650,
    src: PLATE_BASE + 'plates-lateral.jpg',
    points: {
      'Frontal belly of occipitofrontalis': [115, 150], 'Temporalis': [235, 205], 'Orbicularis oculi': [105, 290],
      'Procerus': [68, 318], 'Corrugator supercilii': [95, 268], 'Nasalis': [40, 382],
      'Levator labii superioris': [92, 405], 'Zygomaticus minor': [120, 400],
      'Zygomaticus major': [152, 398], 'Masseter': [235, 405], 'Buccinator': [163, 448],
      'Orbicularis oris': [62, 455], 'Risorius': [132, 468],
      'Depressor anguli oris': [100, 505], 'Mentalis': [68, 520],
      'Platysma': [245, 570], 'Sternocleidomastoid': [312, 505],
    },
  },
  oblique: {
    label: '3/4 view', w: 447, h: 640,
    src: PLATE_BASE + 'plates-oblique.jpg',
    points: {
      'Frontal belly of occipitofrontalis': [230, 100], 'Temporalis': [150, 200], 'Corrugator supercilii': [340, 250],
      'Procerus': [368, 288], 'Orbicularis oculi': [252, 290], 'Nasalis': [345, 352],
      'Levator labii superioris': [312, 362], 'Zygomaticus minor': [285, 372],
      'Zygomaticus major': [255, 382], 'Masseter': [160, 400], 'Buccinator': [240, 420],
      'Orbicularis oris': [332, 430], 'Risorius': [250, 442],
      'Depressor anguli oris': [295, 470], 'Depressor labii inferioris': [325, 482],
      'Mentalis': [340, 496], 'Platysma': [180, 540], 'Sternocleidomastoid': [130, 500],
    },
  },
};

// Posterior head and neck is a different muscle set entirely, so it is
// its own diagram rather than a fourth view of the facial plates.
const POSTERIOR = {
  w: 501, h: 665,
  src: PLATE_BASE + 'posterior.jpg',
  points: {
    'Occipital belly of occipitofrontalis': [160, 200], 'Sternocleidomastoid': [88, 400],
    'Splenius capitis': [160, 410], 'Semispinalis capitis': [218, 400],
    'Trapezius': [250, 530],
  },
};

function PosteriorDiagram({ activeName }) {
  const P = POSTERIOR;
  const p = P.points[activeName];
  const DW = 320, DH = Math.round(DW * P.h / P.w);
  return (
    <div style={{ position: 'relative', width: DW, height: DH, margin: '0 auto' }}>
      <img src={P.src} alt="Posterior head and neck plate" style={{ width: DW, height: DH, display: 'block', borderRadius: 12 }} />
      {p && <svg viewBox={`0 0 ${P.w} ${P.h}`} style={{ position: 'absolute', inset: 0, width: DW, height: DH, pointerEvents: 'none' }}><AnnotationOverlay annotation={p} w={P.w} h={P.h} /></svg>}
    </div>
  );
}

// Torso: two views sharing one muscle list. A muscle absent from a
// view simply has no entry there and the diagram says so.
const TORSO = {
  anterior: {
    label: 'Anterior', w: 531, h: 648,
    src: PLATE_BASE + 'torso-anterior.jpg',
    points: {
      'Sternocleidomastoid': [238, 75], 'Trapezius': [175, 95], 'Deltoid': [110, 190],
      'Pectoralis major': [195, 215], 'Serratus anterior': [158, 335],
      'Rectus abdominis': [230, 400], 'External oblique': [175, 430],
      'Linea alba': [265, 435], 'Tendinous intersection': [230, 355],
      'Biceps brachii': [60, 300], 'Brachioradialis': [40, 430],
    },
  },
  posterior: {
    label: 'Posterior', w: 523, h: 648,
    src: PLATE_BASE + 'torso-posterior.jpg',
    points: {
      // Large superficial structures are highlighted as areas instead of pretending a single dot defines them.
      'Trapezius': { type: 'polygon', points: [[262,42],[400,132],[378,210],[337,304],[294,405],[262,436],[228,405],[185,304],[145,210],[125,132]] },
      'Deltoid': { type: 'ellipse', cx: 74, cy: 184, rx: 45, ry: 63 },
      'Infraspinatus': { type: 'ellipse', cx: 160, cy: 244, rx: 44, ry: 37 },
      'Teres major': { type: 'ellipse', cx: 181, cy: 290, rx: 39, ry: 23 },
      'Latissimus dorsi': { type: 'polygon', points: [[132,275],[225,298],[260,410],[224,480],[145,480],[112,405],[116,330]] },
      'Thoracolumbar fascia': { type: 'polygon', points: [[231,355],[294,355],[322,494],[262,568],[202,494]] },
      'Triceps brachii': { type: 'ellipse', cx: 71, cy: 304, rx: 35, ry: 90 },
      // External oblique is not reliably exposed posteriorly on this plate; TorsoDiagram falls back to the anterior view.
      'Gluteus medius': [150, 570],
    },
  },
};

function TorsoDiagram({ activeName, view = 'anterior', onView }) {
  const shown = (TORSO[view] && TORSO[view].points[activeName])
    ? view
    : (Object.keys(TORSO).find((k) => TORSO[k].points[activeName]) || view);
  const P = TORSO[shown] || TORSO.anterior;
  const p = P.points[activeName];
  const DW = 320, DH = Math.round(DW * P.h / P.w);
  return (
    <div style={{ width: DW, margin: '0 auto' }}>
      <div className="flex gap-1 justify-center mb-2">
        {Object.keys(TORSO).map((k) => (
          <button key={k} onClick={() => onView && onView(k)}
            className={`px-3 py-1 rounded-full text-xs font-medium border ${shown === k ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-gray-500 border-gray-200'}`}>
            {TORSO[k].label}
          </button>
        ))}
      </div>
      <div style={{ position: 'relative', width: DW, height: DH }}>
        <img src={P.src} alt={`${P.label} torso plate`} style={{ width: DW, height: DH, display: 'block', borderRadius: 12 }} />
        {p && <svg viewBox={`0 0 ${P.w} ${P.h}`} style={{ position: 'absolute', inset: 0, width: DW, height: DH, pointerEvents: 'none' }}><AnnotationOverlay annotation={p} w={P.w} h={P.h} /></svg>}
      </div>
      {!p && <p className="text-xs text-gray-400 text-center mt-2">Not shown on any view of this plate.</p>}
    </div>
  );
}


function BackSuperficialDiagram({ activeName }) {
  const P = TORSO.posterior;
  const p = P.points[activeName];
  const DW = 320, DH = Math.round(DW * P.h / P.w);
  return (
    <div style={{ position: 'relative', width: DW, height: DH, margin: '0 auto' }}>
      <img src={P.src} alt="Posterior superficial back and shoulder plate" style={{ width: DW, height: DH, display: 'block', borderRadius: 12 }} />
      {p && <svg viewBox={`0 0 ${P.w} ${P.h}`} style={{ position: 'absolute', inset: 0, width: DW, height: DH, pointerEvents: 'none' }}><AnnotationOverlay annotation={p} w={P.w} h={P.h} /></svg>}
    </div>
  );
}

// Integumentary plates. Each is a single figure with its own pointer
// coordinates in that plate's native pixel space — same pattern as
// the muscle plates, minus the view toggle.
const SKIN_SRC = PLATE_BASE + 'skin.jpg';
const HAIR_SRC = PLATE_BASE + 'hair.jpg';
const NAIL_SRC = PLATE_BASE + 'nail.jpg';
const PLATE_FIGURES = {
  skin: {
    w: 1536, h: 1024, src: PLATE_BASE + 'skin-v2.png',
    points: {
      // layers are spans, not points, so they get depth brackets
      'Epidermis': { t: 'v', x: 154, y0: 87, y1: 261 },
      'Papillary dermis': { t: 'v', x: 154, y0: 275, y1: 366 },
      'Reticular dermis': { t: 'v', x: 154, y0: 371, y1: 778 },
      'Hypodermis (subcutaneous tissue)': { t: 'v', x: 154, y0: 789, y1: 997 },
      'Dermal papillae': [665, 284],
      'Hair shaft': [938, 50],
      'Hair follicle': [713, 567],
      'Sebaceous gland': [990, 438],
      'Apocrine sweat gland': [416, 641],
      'Eccrine sweat gland': [1277, 641],
    },
  },
  hair: {
    w: 1229, h: 1536, src: PLATE_BASE + 'hair-v2.png',
    points: {
      'Hair medulla': [556, 760], 'Hair cortex': [646, 760], 
      'Dermal root sheath': [792, 800], 'Hair matrix': [544, 1090],
      'Hair papilla': [544, 1190], 'Sebaceous gland': [996, 520],
    },
  },
  nail: {
    w: 1491, h: 793, src: NAIL_SRC,
    points: {
      'Nail plate': { t: 'h', y: 210, x0: 560, x1: 1420 },
      'Nail bed': { t: 'h', y: 305, x0: 560, x1: 1150 },
      'Nail matrix': [407, 267],
      'Lunula': [580, 187],
      'Eponychium': [453, 120],
      'Distal phalanx': [700, 490],
    },
  },
};

function makeFigureDiagram(key) {
  return function FigureDiagram({ activeName }) {
    const P = PLATE_FIGURES[key];
    const p = P.points[activeName];
    const DW = 320, DH = Math.round(DW * P.h / P.w);
    return (
      <div style={{ position: 'relative', width: DW, height: DH, margin: '0 auto' }}>
        <img src={P.src} alt="Anatomy plate" style={{ width: DW, height: DH, display: 'block', borderRadius: 12 }} />
        {p && <svg viewBox={`0 0 ${P.w} ${P.h}`} style={{ position: 'absolute', inset: 0, width: DW, height: DH, pointerEvents: 'none' }}><AnnotationOverlay annotation={p} w={P.w} h={P.h} /></svg>}
      </div>
    );
  };
}
const SkinDiagram = makeFigureDiagram('skin');
const HairDiagram = makeFigureDiagram('hair');
const NailDiagram = makeFigureDiagram('nail');

// Skeletal plates. Same figure pattern as the integumentary ones.
const SKEL = {
  skullAnt: { w: 1280, h: 1536, src: PLATE_BASE + 'skel-skullant-v2.png',
    points: {
      'Frontal bone': [640, 291], 'Superciliary arch': [414, 501],
      'Orbit': [352, 606], 'Superior orbital fissure': [390, 643],
      'Greater wing of sphenoid': [314, 699], 'Nasal bone': [614, 571],
      'Anterior nasal aperture': [617, 804], 'Inferior nasal conchae': [552, 886],
      'Vomer': [640, 868], 'Infraorbital foramen': [372, 845],
      'Zygomatic bone': [255, 804], 'Maxilla': [483, 1095], 'Body of mandible': [640, 1375],
    } },
  skullLat: { w: 1536, h: 1404, src: PLATE_BASE + 'skel-skulllat-v2.png',
    points: {
      'Frontal bone': [455, 397], 'Parietal bone': [882, 331], 'Temporal bone': [1089, 689],
      'Occipital bone': [1393, 742], 'Sphenoid bone': [539, 603],
      'Coronal suture': [627, 331], 'Squamous suture': [1103, 503], 'Lambdoid suture': [1406, 530],
      'Mastoid process of temporal bone': [916, 868], 'Styloid process of temporal bone': [783, 980], 'Zygomatic arch': [717, 808],
      'Alveolar process of maxilla': [345, 1046], 'Anterior nasal spine': [241, 927],
      'Mental foramen': [188, 1252], 'Ramus of mandible': [648, 1086],
      'Angle of mandible': [689, 1172], 'Condylar process of mandible': [772, 775],
    } },
  skullInf: { w: 1280, h: 1536, src: PLATE_BASE + 'skel-skullinf-v2.png',
    points: {
      'Foramen magnum': [640, 1036], 'Occipital condyle': [430, 918],
      'External occipital protuberance': [640, 1401],
      'Horizontal plate of palatine bone': [640, 471],
      'Palatine process of maxilla': [640, 294], 'Incisive foramen': [640, 171],
      'Choana (posterior nasal aperture)': [592, 494], 'Zygomatic arch': [242, 494],
    } },
  cervical: { w: 1459, h: 488, src: PLATE_BASE + 'skel-cervical.jpg',
    points: {
      'Vertebral foramen': [242, 155], 'Transverse foramen': [77, 282],
      'Vertebral body': [265, 400], 'Anterior arch of atlas': [758, 73],
      'Dens of axis': [1234, 65], 'Superior articular facet': [1129, 177],
      'Typical cervical vertebrae': [330, 200], 'Atlas': [740, 370], 'Axis': [1180, 410],
    } },
  scapulaAnt: { w: 620, h: 499, src: PLATE_BASE + 'skel-scapula-ant.jpg',
    points: {
      'Coracoid process': [124, 58], 'Scapular notch': [242, 79], 'Superior angle': [435, 22],
      'Glenoid cavity': [188, 133], 'Neck of the scapula': [193, 186], 'Subscapular fossa': [333, 244],
      'Inferior angle': [319, 437],
    } },
  scapulaPost: { w: 620, h: 497, src: PLATE_BASE + 'skel-scapula-post.jpg',
    points: {
      'Superior angle': [115, 24], 'Acromion process': [425, 49], 'Spine of the scapula': [243, 126],
      'Infraspinous fossa': [230, 266], 'Inferior angle': [217, 434],
    } },
  femur: { w: 620, h: 496, src: PLATE_BASE + 'skel-femur.jpg',
    points: {
      'Head of femur': [203, 27], 'Neck of femur': [179, 60], 'Greater trochanter': [142, 46],
      'Lesser trochanter': [182, 87], 'Lateral condyle of femur': [159, 453], 'Lateral epicondyle of femur': [165, 421],
      'Medial epicondyle of femur': [219, 425], 'Linea aspera': [393, 212], 'Intercondylar fossa': [407, 455],
    } },
  tibfib: { w: 560, h: 672, src: PLATE_BASE + 'skel-tibfib.jpg',
    points: {
      'Head of fibula': [208, 61], 'Tibial tuberosity': [274, 95], 'Medial condyle of tibia': [284, 37],
      'Medial malleolus': [317, 611], 'Lateral malleolus': [227, 636],
    } },
  thorax: { w: 620, h: 496, src: PLATE_BASE + 'skel-thorax.jpg',
    points: {
      'Manubrium sterni': [310, 80], 'Body of the sternum': [310, 190], 'Xiphoid process': [310, 290],
      'Vertebrosternal (true) ribs (1–7)': [177, 124], 'Vertebrochondral ribs (8–10)': [190, 389], 'Floating ribs (11–12)': [175, 446],
    } },
  ulnarad: { w: 560, h: 840, src: PLATE_BASE + 'skel-ulnarad.jpg',
    points: {
      'Olecranon process': [306, 25], 'Trochlear notch': [306, 52], 'Coronoid process': [273, 79],
      'Head of radius': [224, 101], 'Head of ulna': [300, 774], 'Radial styloid process': [219, 796],
    } },
  foot: { w: 560, h: 672, src: PLATE_BASE + 'skel-foot.jpg',
    points: {
      'Calcaneus': [284, 49], 'Talus': [293, 122], 'Navicular': [337, 196],
      'Cuboid': [242, 205], 'Lateral cuneiform': [279, 245], 'Intermediate cuneiform': [313, 242],
      'Medial cuneiform': [350, 249], 'Metatarsals': [274, 391], 'Proximal phalanx': [342, 489],
      'Distal phalanx': [352, 562],
    } },
  pelvis: { w: 620, h: 319, src: PLATE_BASE + 'skel-pelvis.jpg',
    points: {
      'Iliac crest': [146, 20], 'Anterior superior iliac spine': [120, 91],
      'Anterior inferior iliac spine': [182, 152], 'Sacral promontory': [287, 70],
      'Pubic symphysis': [291, 260], 'Pubic tubercle': [325, 240],
      'Obturator foramen': [366, 266], 'Ischium': [240, 295],
    } },
  hipLat: { w: 520, h: 662, src: PLATE_BASE + 'skel-hip-lat.jpg',
    points: {
      'Acetabulum': [340, 396], 'Posterior superior iliac spine': [35, 248],
      'Posterior inferior iliac spine': [77, 307], 'Greater sciatic notch': [186, 353],
      'Ischial spine': [171, 446], 'Lesser sciatic notch': [186, 480],
      'Ischial tuberosity': [186, 582],
    } },
  wrist: { w: 520, h: 584, src: PLATE_BASE + 'skel-wrist.jpg',
    points: {
      'Scaphoid': [313, 186], 'Lunate': [233, 186], 'Triquetrum': [154, 200],
      'Pisiform': [143, 252], 'Hamate': [143, 296], 'Capitate': [236, 280],
      'Trapezoid': [296, 274], 'Trapezium': [342, 258],
    } },
  hand: { w: 440, h: 939, src: PLATE_BASE + 'skel-hand.jpg',
    points: {
      'Metacarpals': [211, 367], 'Proximal phalanx': [220, 541], 'Distal phalanx': [229, 779],
    } },
  clavicle: { w: 620, h: 496, src: PLATE_BASE + 'skel-clavicle.jpg',
    points: {
      'Sternal end of clavicle': [53, 146], 'Acromial end of clavicle': [553, 122],
    } },
  humerus: { w: 620, h: 496, src: PLATE_BASE + 'skel-humerus.jpg',
    points: {
      'Head of humerus': [212, 24], 'Anatomical neck': [223, 62], 'Greater tubercle': [161, 46], 'Lesser tubercle': [195, 51],
      'Surgical neck': [195, 88], 'Capitulum': [179, 451], 'Trochlea': [214, 453],
      'Lateral epicondyle of humerus': [155, 430], 'Medial epicondyle of humerus': [239, 433], 'Olecranon fossa': [409, 425],
    } },
  column: { w: 768, h: 1536, src: PLATE_BASE + 'skel-column-v2.png',
    points: {
      'Cervical curvature': { t: 'v', x: 105, y0: 14, y1: 185 },
      'Thoracic curvature': { t: 'v', x: 105, y0: 199, y1: 834 },
      'Lumbar curvature': { t: 'v', x: 105, y0: 852, y1: 1186 },
      'Sacrum': [393, 1316], 'Coccyx': [341, 1473], 'Intervertebral disc': [498, 741],
    } },
};

function makeSkelDiagram(key) {
  return function SkelDiagram({ activeName }) {
    const P = SKEL[key];
    const p = P.points[activeName];
    const DW = 320, DH = Math.round(DW * P.h / P.w);
    return (
      <div style={{ position: 'relative', width: DW, height: DH, margin: '0 auto' }}>
        <img src={P.src} alt="Skeletal plate" style={{ width: DW, height: DH, display: 'block', borderRadius: 12 }} />
        {p && <svg viewBox={`0 0 ${P.w} ${P.h}`} style={{ position: 'absolute', inset: 0, width: DW, height: DH, pointerEvents: 'none' }}><AnnotationOverlay annotation={p} w={P.w} h={P.h} /></svg>}
      </div>
    );
  };
}
const SkullAntDiagram = makeSkelDiagram('skullAnt');
const SkullLatDiagram = makeSkelDiagram('skullLat');
const SkullInfDiagram = makeSkelDiagram('skullInf');
const CervicalDiagram = makeSkelDiagram('cervical');
const HumerusDiagram = makeSkelDiagram('humerus');
const FemurDiagram = makeSkelDiagram('femur');
const TibFibDiagram = makeSkelDiagram('tibfib');
const ThoraxDiagram = makeSkelDiagram('thorax');
const UlnaRadDiagram = makeSkelDiagram('ulnarad');
const FootDiagram = makeSkelDiagram('foot');
const PelvisDiagram = makeSkelDiagram('pelvis');
const HipLatDiagram = makeSkelDiagram('hipLat');
const WristDiagram = makeSkelDiagram('wrist');
const HandDiagram = makeSkelDiagram('hand');
const ClavicleDiagram = makeSkelDiagram('clavicle');
const ScapulaAntDiagram = makeSkelDiagram('scapulaAnt');
const ScapulaPostDiagram = makeSkelDiagram('scapulaPost');
const ColumnDiagram = makeSkelDiagram('column');

const MUSC2 = {
  headneck: { w: 954, h: 1505, src: PLATE_BASE + 'musc2-headneck.jpg',
    points: {
      'Frontal belly of occipitofrontalis': [700, 250], 'Epicranial aponeurosis (galea aponeurotica)': [245, 255],
      'Occipital belly of occipitofrontalis': [250, 350], 'Temporalis': [480, 300],
      'Orbicularis oculi': [790, 400], 'Orbicularis oris': [830, 690], 'Nasalis': [860, 560],
      'Levator labii superioris': [800, 600], 'Zygomaticus major': [700, 640],
      'Masseter': [600, 640], 'Depressor anguli oris': [770, 780], 'Mentalis': [840, 810],
      'Platysma': [600, 950], 'Sternocleidomastoid': [450, 900],
      'Trapezius': [280, 1050], 'Levator scapulae': [400, 1000],
    } },
  torsoDeep: { w: 1024, h: 1536, src: PLATE_BASE + 'musc2-torsodeep.jpg',
    points: {
      'Pectoralis major': [300, 260], 'Pectoralis minor': [630, 290],
      'Serratus anterior': [690, 560], 'External intercostals': [600, 420],
      'Rib': [660, 350], 'Rectus abdominis': [430, 580], 'Linea alba': [487, 560],
      'External oblique': [286, 667], 'Deltoid': [790, 240], 'Biceps brachii': [850, 520],
    } },
};
function makeMusc2(key) {
  return function M2({ activeName }) {
    const P = MUSC2[key]; const p = P.points[activeName];
    const DW = 320, DH = Math.round(DW * P.h / P.w);
    return (
      <div style={{ position: 'relative', width: DW, height: DH, margin: '0 auto' }}>
        <img src={P.src} alt="Muscle plate" style={{ width: DW, height: DH, display: 'block', borderRadius: 12 }} />
        {p && <svg viewBox={`0 0 ${P.w} ${P.h}`} style={{ position: 'absolute', inset: 0, width: DW, height: DH, pointerEvents: 'none' }}><AnnotationOverlay annotation={p} w={P.w} h={P.h} /></svg>}
      </div>
    );
  };
}
const HeadNeckDiagram = makeMusc2('headneck');
const TorsoDeepDiagram = makeMusc2('torsoDeep');

// One pointer-overlay factory shared by every raster plate set.
// Coordinates live in each plate's own pixel space, so they stay
// valid at any display size.
function makePlateDiagram(SET, key) {
  return function PlateDiagram({ activeName }) {
    const P = SET[key];
    const p = P.points[activeName];
    const DW = 320, DH = Math.round(DW * P.h / P.w);
    return (
      <div style={{ position: 'relative', width: DW, height: DH, margin: '0 auto' }}>
        <img src={P.src} alt="Anatomical plate" style={{ width: DW, height: DH, display: 'block', borderRadius: 12 }} />
        {p && <svg viewBox={`0 0 ${P.w} ${P.h}`} style={{ position: 'absolute', inset: 0, width: DW, height: DH, pointerEvents: 'none' }}><AnnotationOverlay annotation={p} w={P.w} h={P.h} /></svg>}
      </div>
    );
  };
}
// Limb muscle plates.
const MUSCLIMB = {
  thigh: { w: 620, h: 567, src: PLATE_BASE + 'musc-thigh.jpg',
    points: {
      'Iliopsoas': [128, 106], 'Pectineus': [111, 135], 'Adductor longus': [85, 175],
      'Gracilis': [28, 293], 'Sartorius': [121, 246], 'Rectus femoris': [151, 236],
      'Vastus lateralis': [175, 293], 'Vastus medialis': [83, 385], 'Tensor fasciae latae': [345, 76],
      'Iliotibial tract': [317, 284], 'Gluteus maximus': [520, 142], 'Biceps femoris': [567, 284],
      'Semitendinosus': [520, 284], 'Semimembranosus': [477, 293],
    } },
  abwall: { w: 620, h: 567, src: PLATE_BASE + 'musc-abwall.jpg',
    points: {
      'External oblique': [132, 189], 'Rectus abdominis': [331, 236], 'Transversus abdominis': [411, 236],
      'Internal oblique': [520, 189],
    } },
  cuff: { w: 620, h: 567, src: PLATE_BASE + 'musc-cuff.jpg',
    points: {
      'Supraspinatus': [246, 109], 'Infraspinatus': [246, 227], 'Teres minor': [246, 307],
      'Teres major': [246, 378],
    } },
  triceps: { w: 560, h: 840, src: PLATE_BASE + 'musc-triceps.jpg',
    points: {
      'Long head of triceps brachii': [175, 273], 'Lateral head of triceps brachii': [339, 219], 'Medial head of triceps brachii': [262, 372],
    } },
  leg: { w: 620, h: 567, src: PLATE_BASE + 'musc-leg.jpg',
    points: {
      'Fibularis longus': [109, 189], 'Tibialis anterior': [300, 189], 'Extensor digitorum longus': [269, 260],
      'Gastrocnemius': [510, 151], 'Soleus': [572, 293],
    } },
};
const LegDiagram = makePlateDiagram(MUSCLIMB, 'leg');
const ThighDiagram = makePlateDiagram(MUSCLIMB, 'thigh');
const AbWallDiagram = makePlateDiagram(MUSCLIMB, 'abwall');
const CuffDiagram = makePlateDiagram(MUSCLIMB, 'cuff');
const TricepsDiagram = makePlateDiagram(MUSCLIMB, 'triceps');


// Orientation and cell plates, replacing the earlier hand-drawn SVG figures.
const BASICS = {
  directional: { w: 560, h: 840, src: PLATE_BASE + 'terms-directional.jpg',
    points: {
      'Superior': [280, 33], 'Inferior': [273, 793],
      'Medial': [280, 383], 'Lateral': [219, 383],
      'Proximal': [211, 213], 'Distal': [178, 459],
    } },
  cavities: { w: 560, h: 840, src: PLATE_BASE + 'terms-cavities.jpg',
    points: {
      'Cranial cavity': { type: 'ellipse', cx: 270, cy: 72, rx: 88, ry: 57 },
      'Vertebral canal': { type: 'area', x: 246, y: 105, width: 28, height: 160, rx: 12 },
      // Thoracic cavity means the whole chest compartment, not just one pleural side.
      'Thoracic cavity': { type: 'area', x: 145, y: 238, width: 270, height: 174, rx: 42 },
      'Mediastinum': { type: 'polygon', points: [[236,235],[311,235],[326,362],[222,362]] },
      'Diaphragm': { type: 'polygon', points: [[145,373],[205,359],[280,355],[355,359],[415,373],[398,414],[162,414]] },
      'Abdominal cavity': { type: 'area', x: 164, y: 414, width: 230, height: 188, rx: 45 },
      'Pelvic cavity': { type: 'ellipse', cx: 279, cy: 635, rx: 84, ry: 66 },
    } },
  cell: { w: 620, h: 620, src: PLATE_BASE + 'cell-structure.jpg',
    points: {
      'Nucleus': { type: 'ellipse', cx: 258, cy: 250, rx: 105, ry: 101 },
      'Mitochondrion': { type: 'ellipse', cx: 187, cy: 105, rx: 51, ry: 28 },
      'Plasma membrane (cell membrane)': [32, 307],
      'Cytosol': [356, 517],
      'Ribosomes': [386, 307],
    } },
};

const CavitiesDiagram = makePlateDiagram(BASICS, 'cavities');
const CellDiagram = makePlateDiagram(BASICS, 'cell');


// Nervous system plates.
const NERVOUS = {
  cranial: { w: 1536, h: 1404, src: PLATE_BASE + 'nervous-cranial-v2.png',
    points: {
      'Olfactory tract': [647, 213], 'Optic nerve': [627, 406], 'Optic chiasm': [743, 509],
      'Oculomotor nerve': [686, 611], 'Trigeminal nerve': [538, 712], 'Abducens nerve': [709, 839],
    } },
  brainMid: {
    w: 620, h: 520,
    src: PLATE_BASE + 'nervous-brainmid.jpg',
    points: {
      "Cerebral cortex": [113, 68],
      "Corpus callosum": [226, 127],
      "Lateral ventricle": [199, 181],
      "Fornix": [258, 162],
      "Thalamus": [267, 192],
      "Hypothalamus": [231, 238],
      "Optic chiasm": [198, 260],
      "Pituitary gland": [201, 298],
      "Midbrain": [290, 240],
      "Pons": [272, 292],
      "Medulla oblongata": [322, 383],
      "Cerebellum": [469, 312],
      "Arbor vitae": [399, 283],
      "Fourth ventricle": [363, 305],
      "Pineal gland": [338, 212],
      "Spinal cord": [337, 476],
    },
  },
  cordSection: {
    w: 600, h: 537,
    src: PLATE_BASE + 'nervous-cordsection.jpg',
    points: {
      "Posterior (dorsal) horn": [383, 128],
      "Anterior (ventral) horn": [387, 304],
      "Grey matter": [235, 217],
      "White matter": [129, 217],
      "Central canal": [299, 212],
      "Posterior median sulcus": [299, 63],
      "Anterior median fissure": [299, 349],
      "Dorsal root ganglion": [514, 166],
      "Dorsal (posterior) root": [403, 96],
      "Ventral (anterior) root": [407, 312],
      "Spinal nerve": [534, 226],
    },
  },
};

function makeNervousDiagram(key) { return makePlateDiagram(NERVOUS, key); }
const BrainMidDiagram = makeNervousDiagram('brainMid');
const CordSectionDiagram = makeNervousDiagram('cordSection');
const CranialDiagram = makePlateDiagram(NERVOUS, 'cranial');

// Special senses. Same plate-plus-pointer pattern.
const SENSES = {
  eye: {
    w: 600, h: 533,
    src: PLATE_BASE + 'senses-eye.jpg',
    points: {
      "Cornea": [270, 28],
      "Iris": [212, 72],
      "Pupil": [286, 79],
      "Lens": [289, 119],
      "Ciliary body": [156, 106],
      "Zonular fibers (suspensory ligament of lens)": [196, 122],
      "Sclera": [88, 156],
      "Choroid": [85, 225],
      "Retina": [492, 225],
      "Fovea centralis": [431, 330],
      "Optic disc": [279, 407],
      "Central retinal artery and vein": [270, 455],
      "Optic nerve": [270, 500],
    },
  },
  ear: {
    w: 620, h: 413,
    src: PLATE_BASE + 'senses-ear.jpg',
    points: {
      "Auricle (pinna)": [44, 161],
      "External acoustic meatus": [190, 198],
      "Tympanic membrane": [301, 224],
      "Malleus": [302, 136],
      "Incus": [334, 174],
      "Stapes": [376, 186],
      "Semicircular canals": [418, 54],
      "Vestibule": [412, 141],
      "Cochlea": [482, 215],
      "Vestibulocochlear nerve": [521, 143],
      "Temporal bone": [210, 93],
    },
  },
};

function makeSenseDiagram(key) { return makePlateDiagram(SENSES, key); }
const EyeDiagram = makeSenseDiagram('eye');
const EarDiagram = makeSenseDiagram('ear');

// Cardiovascular plates.
const CARDIO = {
  section: { w: 620, h: 678, src: PLATE_BASE + 'cardio-section.jpg',
    points: {
      'Superior vena cava': [140, 67], 'Inferior vena cava': [127, 595], 'Aorta': [321, 67],
      'Pulmonary trunk': [409, 155], 'Pulmonary veins': [522, 207],
      'Right atrium': { type: 'ellipse', cx: 154, cy: 228, rx: 82, ry: 82 },
      'Left atrium': { type: 'ellipse', cx: 486, cy: 226, rx: 82, ry: 72 },
      'Tricuspid valve': [160, 336], 'Mitral valve': [393, 331],
      'Aortic semilunar valve': [280, 203], 'Pulmonary semilunar valve': [385, 194],
      'Right ventricle': { type: 'polygon', points: [[90,310],[210,292],[277,337],[274,505],[220,548],[125,522],[82,445]] },
      'Left ventricle': { type: 'polygon', points: [[365,300],[500,302],[555,388],[536,535],[462,585],[375,548],[340,432]] },
      'Interventricular septum': { type: 'polygon', points: [[289,304],[340,304],[369,500],[340,583],[293,530],[276,382]] },
      'Chordae tendineae': [176, 377], 'Papillary muscle': [191, 429],
    } },
  heartExt: {
    w: 620, h: 703,
    src: PLATE_BASE + 'cardio-heartext.jpg',
    points: {
      "Superior vena cava": [126, 158],
      "Inferior vena cava": [132, 605],
      "Aortic arch": [274, 79],
      "Ascending aorta": [247, 184],
      "Pulmonary trunk": [326, 263],
      "Right pulmonary artery": [416, 168],
      "Pulmonary veins": [516, 263],
      "Right auricle": [179, 279],
      "Left auricle": [437, 274],
      "Right ventricle": [226, 447],
      "Left ventricle": [432, 474],
      "Anterior interventricular sulcus": [339, 500],
      "Right coronary artery": [153, 379],
      "Apex of the heart": [368, 650],
    },
  },
};
const HeartSectionDiagram = makePlateDiagram(CARDIO, 'section');
const HeartExtDiagram = makePlateDiagram(CARDIO, 'heartExt');

// Digestive plates.
const DIGEST = {
  tract: {
    w: 560, h: 840,
    src: PLATE_BASE + 'digest-tract.jpg',
    points: {
      "Parotid gland": [223, 60],
      "Esophagus": [249, 246],
      "Liver": [186, 361],
      "Gallbladder": [211, 440],
      "Stomach": [339, 432],
      "Duodenum": [276, 462],
      "Pancreas": [249, 492],
      "Transverse colon": [202, 487],
      "Small intestine": [262, 580],
      "Ascending colon": [156, 552],
      "Descending colon": [358, 591],
      "Cecum": [175, 632],
      "Vermiform appendix": [207, 667],
      "Sigmoid colon": [306, 664],
      "Rectum": [278, 727],
    },
  },
  stomach: {
    w: 620, h: 567,
    src: PLATE_BASE + 'digest-stomach.jpg',
    points: {
      "Esophagus": [295, 47],
      "Cardia of stomach": [326, 111],
      "Fundus of stomach": [425, 71],
      "Body of stomach": [449, 213],
      "Lesser curvature": [312, 213],
      "Greater curvature": [574, 236],
      "Pyloric antrum": [203, 373],
      "Pyloric sphincter": [147, 341],
      "Duodenum": [71, 449],
    },
  },
};
const DigestiveTractDiagram = makePlateDiagram(DIGEST, 'tract');
const StomachDiagram = makePlateDiagram(DIGEST, 'stomach');

// Respiratory plates.
const RESPIR = {
  tract: {
    // Cropped from the original upper-airway plate so the known two-lobed
    // right-lung drawing is never used to teach lung anatomy. The original
    // file remains preserved in the asset pack for provenance.
    w: 300, h: 320,
    src: PLATE_BASE + 'respir-upperairway.jpg',
    points: {
      "Nasal cavity": [90, 60],
      "Oral cavity": [105, 112],
      "Pharynx": [160, 102],
      "Epiglottis": [175, 147],
      "Larynx": [185, 197],
      "Trachea": [190, 260],
    },
  },
  lungs: { w: 560, h: 613, src: PLATE_BASE + 'respir-lungs.jpg',
    points: {
      'Larynx': [276, 56], 'Trachea': [280, 163], 'Carina': [290, 243],
      'Right main bronchus': [243, 259], 'Left main bronchus': [336, 264], 'Bronchial tree': [397, 327],
      'Right superior lobe': [140, 210], 'Right middle lobe': [163, 327], 'Right inferior lobe': [93, 397],
      'Diaphragm': [280, 523],
    } },
  alveoli: {
    w: 620, h: 511,
    src: PLATE_BASE + 'respir-alveoli.jpg',
    points: {
      "Bronchiole": [233, 81],
      "Alveolar duct": [346, 180],
      "Alveolus": [119, 240],
      "Alveolar wall (interalveolar septum)": [180, 314],
      "Alveolar sac": [404, 350],
      "Alveolar capillary network": [485, 224],
      "Pulmonary arteriole": [103, 117],
      "Pulmonary venule": [43, 117],
    },
  },
};
const RespiratoryTractDiagram = makePlateDiagram(RESPIR, 'tract');
const AlveoliDiagram = makePlateDiagram(RESPIR, 'alveoli');
const LungsDiagram = makePlateDiagram(RESPIR, 'lungs');

// Endocrine plates.
const ENDO = {
  glands: {
    w: 560, h: 840,
    src: PLATE_BASE + 'endo-glands.jpg',
    points: {
      "Pituitary gland": [264, 65],
      "Thyroid gland": [268, 137],
      "Thymus": [275, 178],
      "Adrenal gland": [250, 273],
      "Pancreas": [284, 301],
      "Ovary": [305, 395],
    },
  },
};
const EndocrineDiagram = makePlateDiagram(ENDO, 'glands');

// Reproductive plates. This one is a single panel cropped out of a
// multi-panel source image, so its coordinate space is the panel's own.
const REPRO = {
  femaleInternal: {
    w: 600, h: 435,
    src: PLATE_BASE + 'repro-femaleinternal.jpg',
    points: {
      "Uterine tube": [230, 78],
      "Fimbriae": [135, 132],
      "Ovary": [192, 165],
      "Fundus of uterus": [380, 65],
      "Uterine cavity": [382, 160],
      "Myometrium": [420, 180],
      "Cervix": [375, 290],
      "Vagina": [365, 380],
    },
  },
  maleInternal: {
    w: 445, h: 457,
    src: PLATE_BASE + 'repro-maleinternal.jpg',
    points: {
      "Urinary bladder": [255, 92],
      "Seminal vesicle": [175, 142],
      "Prostate gland": [255, 207],
      "Ductus deferens": [95, 232],
      "Epididymis": [100, 322],
      "Testis": [121, 372],
      "Urethra": [256, 332],
      "Corpus cavernosum": [290, 302],
    },
  },
};
const FemaleReproDiagram = makePlateDiagram(REPRO, 'femaleInternal');
const MaleReproDiagram = makePlateDiagram(REPRO, 'maleInternal');

// Histology plates. Cropped panels from a multi-panel source image,
// so each carries its own coordinate space.
function FaceDiagram({ activeName, view = 'anterior', onView }) {
  const shown = (PLATES[view] && PLATES[view].points[activeName])
    ? view
    : (Object.keys(PLATES).find((k) => PLATES[k].points[activeName]) || view);
  const P = PLATES[shown] || PLATES.anterior;
  const p = P.points[activeName];
  const DW = 320, DH = Math.round(DW * P.h / P.w);
  return (
    <div style={{ width: DW, margin: '0 auto' }}>
      <div className="flex gap-1 justify-center mb-2">
        {Object.keys(PLATES).map((k) => (
          <button key={k} onClick={() => onView && onView(k)}
            className={`px-3 py-1 rounded-full text-xs font-medium border ${shown === k ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-gray-500 border-gray-200'}`}>
            {PLATES[k].label}
          </button>
        ))}
      </div>
      <div style={{ position: 'relative', width: DW, height: DH }}>
        <img src={P.src} alt={`${P.label} facial muscle plate`} style={{ width: DW, height: DH, display: 'block', borderRadius: 12 }} />
        {p && <svg viewBox={`0 0 ${P.w} ${P.h}`} style={{ position: 'absolute', inset: 0, width: DW, height: DH, pointerEvents: 'none' }}><AnnotationOverlay annotation={p} w={P.w} h={P.h} /></svg>}
      </div>
      {!p && <p className="text-xs text-gray-400 text-center mt-2">Not shown on any view of this plate.</p>}
    </div>
  );
}

// ============================================================
// LESSON CONTENT// ============================================================
// LESSON CONTENT// ============================================================
// LESSON CONTENT — edit this array to add or change lessons.
// Metaphors are adapted from real teaching sources (contraction:
// a "bookcase and rope" analogy traced to Jacob Krans, CCSU;
// fiber types: the standard sprinter/marathoner comparison),
// rewritten in original wording — not copied from any textbook.
// ============================================================
function BackDiagram({ activeIdx }) {
  const hi = (n, base) => (activeIdx === n ? '#1D9E75' : base);
  const op = (n) => (activeIdx === n ? 0.92 : 0.42);
  return (
    <svg viewBox="0 0 220 300" width="165" height="225" className="mx-auto">
      <ellipse cx="110" cy="26" rx="24" ry="24" fill="#F3E5D3" stroke="#D9C4A8" strokeWidth="1.5" />
      <path d="M96,46 L96,62 Q110,68 124,62 L124,46 Z" fill="#F0DCC4" stroke="#D9C4A8" strokeWidth="1.5" />
      <path d="M110,58 Q70,62 48,80 Q34,96 34,120 Q34,168 44,206 Q52,246 60,282 L160,282 Q168,246 176,206 Q186,168 186,120 Q186,96 172,80 Q150,62 110,58 Z" fill="#F3E5D3" stroke="#D9C4A8" strokeWidth="1.5" />
      <path d="M48,80 Q30,88 24,112 Q18,140 20,168 L36,168 Q36,138 40,114 Q44,92 54,86 Z" fill="#F0DCC4" stroke="#D9C4A8" strokeWidth="1.5" />
      <path d="M172,80 Q190,88 196,112 Q202,140 200,168 L184,168 Q184,138 180,114 Q176,92 166,86 Z" fill="#F0DCC4" stroke="#D9C4A8" strokeWidth="1.5" />
      {Array.from({ length: 16 }).map((_, i) => (
        <ellipse key={i} cx="110" cy={68 + i * 12} rx="4.5" ry="4" fill="#DCC7AB" stroke="#C9B398" strokeWidth="0.8" />
      ))}
      <path d="M72,92 L96,100 L88,142 Q74,138 68,120 Z" fill="none" stroke="#C9B398" strokeWidth="1.5" opacity="0.85" />
      <path d="M148,92 L124,100 L132,142 Q146,138 152,120 Z" fill="none" stroke="#C9B398" strokeWidth="1.5" opacity="0.85" />
      <path d="M52,236 Q110,252 168,236" fill="none" stroke="#C9B398" strokeWidth="1.5" opacity="0.7" />
      <path d="M110,56 L74,80 Q62,90 66,102 L96,108 L110,178 L124,108 L154,102 Q158,90 146,80 Z" fill={hi(0, '#C9A882')} opacity={op(0)} />
      <path d="M110,178 L110,264 Q76,270 54,256 Q42,232 46,200 Q50,172 60,150 L34,120 L34,168 Q36,190 44,212 Q54,244 74,262 Z" fill={hi(1, '#C9A882')} opacity={op(1)} />
      <path d="M110,264 L110,178 Q144,270 166,256 Q178,232 174,200 Q170,172 160,150 L186,120 L186,168 Q184,190 176,212 Q166,244 146,262 Z" fill={hi(1, '#C9A882')} opacity={op(1)} />
      <path d="M110,122 L132,132 L138,158 L110,148 Z" fill={hi(2, '#B8956C')} opacity={op(2)} />
      <path d="M110,122 L88,132 L82,158 L110,148 Z" fill={hi(2, '#B8956C')} opacity={op(2)} />
      <path d="M110,104 L130,112 L132,128 L110,120 Z" fill={hi(3, '#A8855C')} opacity={op(3)} />
      <path d="M110,104 L90,112 L88,128 L110,120 Z" fill={hi(3, '#A8855C')} opacity={op(3)} />
      <path d="M100,58 L96,66 L86,98 L94,102 L104,68 Z" fill={hi(4, '#9A7A52')} opacity={op(4)} />
      <path d="M120,58 L124,66 L134,98 L126,102 L116,68 Z" fill={hi(4, '#9A7A52')} opacity={op(4)} />
    </svg>
  );
}

// Planes and cavities are schematic geometry rather than detailed
// anatomy, so they are drawn directly: a body in anatomical position
// with the active plane shown as a translucent slice in perspective.




function labelOptionsFor(regions, idx) {
  const correct = regions[idx].name;
  const others = regions.filter((_, i) => i !== idx).map((r) => r.name);
  const picks = shuffle(others).slice(0, Math.min(3, others.length));
  return shuffle([...picks, correct]);
}

const LABEL_CATEGORIES = [
  {
    id: 'terms', title: 'Foundations & Anatomical Terms', icon: Compass,
    activities: [
      {
        id: 'anatomical-position', title: 'Anatomical Position', Diagram: AnatomicalPositionDiagram,
        quizPrompt: 'Which feature of standard anatomical position is highlighted?',
        regions: [
          { name: 'Standing upright', teach: 'Anatomy uses one agreed reference pose so every direction means the same thing, no matter how the patient is actually positioned.', mnemonic: 'Anatomy starts from one standard pose.' },
          { name: 'Head and eyes facing forward', teach: 'The head is upright with the face and eyes directed straight ahead.' },
          { name: 'Arms at the sides', teach: 'The upper limbs hang beside the trunk with the elbows extended.' },
          { name: 'Palms facing forward', teach: 'The forearms are supinated so the palms face anteriorly.', mnemonic: 'Palms forward = anatomical position.' },
          { name: 'Thumbs pointing laterally', teach: 'With the palms forward, the thumbs point away from the body midline.' },
          { name: 'Feet pointing forward', teach: 'The lower limbs are together or slightly apart, with the toes directed forward.' },
        ],
      },
      {
        id: 'directional', title: 'Core Directional Terms', Diagram: DirectionalDiagramV2,
        quizPrompt: 'Which directional term is shown?',
        regions: [
          { name: 'Superior', teach: 'Toward the head or upper part of a structure. The heart is superior to the stomach.', mnemonic: 'Superior = up.' },
          { name: 'Inferior', teach: 'Toward the feet or lower part of a structure. The stomach is inferior to the heart.', mnemonic: 'Inferior = down.' },
          { name: 'Anterior', teach: 'Toward the front of the body. The sternum is anterior to the heart.', mnemonic: 'Anterior = front.' },
          { name: 'Posterior', teach: 'Toward the back of the body. The vertebral column is posterior to the sternum.', mnemonic: 'Posterior = back.' },
          { name: 'Medial', teach: "Toward the body's midline. The nose is medial to the eyes.", mnemonic: 'MEDial → MEDdle.' },
          { name: 'Lateral', teach: 'Away from the midline, toward the side. The ears are lateral to the eyes.', mnemonic: 'Lateral = toward the side.' },
        ],
      },
      {
        id: 'planes', title: 'Body Planes & Sections', Diagram: BodyPlanesDiagram,
        quizPrompt: 'Which anatomical plane is highlighted?',
        regions: [
          { name: 'Median (midsagittal) plane', TeachDiagram: PlaneTeachMidsagittal, teach: 'A vertical plane exactly through the midline, dividing the body into equal right and left halves. A section is the view you get after cutting along the plane.', mnemonic: 'MID = middle — like slicing a sandwich exactly down the center.' },
          { name: 'Parasagittal (sagittal) plane', TeachDiagram: PlaneTeachParasagittal, teach: 'A vertical plane parallel to the median plane that divides the body into right and left portions. A parasagittal cut is off-center and therefore produces unequal portions.', mnemonic: 'Same direction as midsagittal, just moved to one side.' },
          { name: 'Frontal (coronal) plane', TeachDiagram: PlaneTeachFrontal, teach: 'A vertical plane dividing the body into anterior (front) and posterior (back) portions.', mnemonic: 'Frontal = front/back. Think of separating the front and back of a book.' },
          { name: 'Transverse (horizontal) plane', TeachDiagram: PlaneTeachTransverse, teach: 'A horizontal plane dividing the body into superior and inferior portions. The resulting view is a cross-section.', mnemonic: 'Transverse = across — like slicing an apple across.' },
          { name: 'Oblique plane', TeachDiagram: PlaneTeachOblique, teach: 'A plane passing through the body at an angle rather than following the standard sagittal, frontal or transverse orientations.', mnemonic: 'Oblique = angled — like cutting a cake diagonally.' },
        ],
      },
      {
        id: 'cavities', title: 'Body Cavities', Diagram: CavitiesDiagram,
        regions: [
          { name: 'Cranial cavity', teach: 'Enclosed by the skull, holding the brain. Part of the dorsal cavity.' },
          { name: 'Vertebral canal', teach: 'Runs down the spine holding the spinal cord — continuous with the cranial cavity.', mnemonic: 'Cranial + vertebral together form the dorsal cavity.' },
          { name: 'Thoracic cavity', teach: 'The chest cavity above the diaphragm, holding the lungs, heart and great vessels.' },
          { name: 'Mediastinum', teach: 'The central region of the thoracic cavity between the lungs — contains the heart, trachea and esophagus.', mnemonic: '"Media" = middle. The middle of the chest.' },
          { name: 'Diaphragm', teach: 'The dome-shaped muscle separating the thoracic cavity above from the abdominal cavity below.', mnemonic: 'The dividing line of the ventral cavity.' },
          { name: 'Abdominal cavity', teach: 'Below the diaphragm and continuous inferiorly with the pelvic cavity. Most digestive organs lie intraperitoneally; the kidneys lie posteriorly in the retroperitoneum.' },
          { name: 'Pelvic cavity', teach: 'The lowest part, cradled by the hip bones — holds the bladder, rectum and reproductive organs.', mnemonic: 'Abdominal + pelvic are continuous, hence "abdominopelvic".' },
        ],
      },
      {
        id: 'abdominopelvic', title: 'Nine Abdominopelvic Regions', Diagram: AbdominopelvicDiagram,
        quizPrompt: 'Which abdominopelvic region is highlighted?',
        regions: [
          { name: 'Right hypochondriac region', teach: "The patient's upper-right region, under the costal cartilages. It commonly contains part of the liver and gallbladder.", mnemonic: '"Hypo" = under + "chondro" = cartilage.' },
          { name: 'Epigastric region', teach: 'The upper-middle region. The stomach, part of the liver, pancreas and duodenum commonly project here.', mnemonic: '"Epi" = above + "gastric" = stomach.' },
          { name: 'Left hypochondriac region', teach: "The patient's upper-left region under the ribs, containing much of the spleen and part of the stomach." },
          { name: 'Right lumbar region', teach: "The patient's middle-right region, lateral to the umbilical region.", mnemonic: 'Lumbar = waist area.' },
          { name: 'Umbilical region', teach: 'The center region surrounding the umbilicus; loops of small intestine commonly occupy it.', mnemonic: 'Umbilical = belly button.' },
          { name: 'Left lumbar region', teach: "The patient's middle-left region, lateral to the umbilical region." },
          { name: 'Right iliac (inguinal) region', teach: "The patient's lower-right region near the ilium. The cecum and appendix are commonly located here.", mnemonic: 'Iliac = near the ilium, the hip bone.' },
          { name: 'Hypogastric (pubic) region', teach: 'The lower-middle region. The urinary bladder may project here when filled.', mnemonic: '"Hypo" = below + "gastric" = stomach.' },
          { name: 'Left iliac (inguinal) region', teach: "The patient's lower-left region near the ilium; the sigmoid colon commonly lies here." },
        ],
      },
      {
        id: 'proximal-distal', title: 'Proximal & Distal', Diagram: ProximalDistalDiagram,
        quizPrompt: 'Which limb relationship is shown?',
        regions: [
          { name: 'Proximal', teach: 'Closer to the point where a limb attaches to the trunk. The elbow is proximal to the wrist.', mnemonic: 'Proximal → proximity → closer.' },
          { name: 'Distal', teach: 'Farther from the point where a limb attaches to the trunk. The fingers are distal to the elbow.', mnemonic: 'Distal → distant → farther away.' },
        ],
      },
      {
        id: 'superficial-deep', title: 'Superficial & Deep', Diagram: SuperficialDeepDiagram,
        quizPrompt: 'Which depth relationship is highlighted?',
        regions: [
          { name: 'Superficial', teach: 'Closer to or at the body surface. The skin is superficial to skeletal muscle.', mnemonic: 'Superficial = surface.' },
          { name: 'Deep', teach: 'Farther from the body surface. Bone is deep to skin and subcutaneous tissue.' },
        ],
      },
      {
        id: 'relationship-terms', title: 'Relationship Terms', Diagram: RelationshipTermsDiagram,
        quizPrompt: 'Which anatomical relationship is highlighted?',
        regions: [
          { name: 'Ipsilateral', teach: 'On the same side of the body. The right arm and right leg are ipsilateral.', mnemonic: 'Ipsi = same side.' },
          { name: 'Contralateral', teach: 'On opposite sides of the body. The right arm and left leg are contralateral.', mnemonic: 'Contra = opposite.' },
          { name: 'Bilateral', teach: 'Present on both sides. The normal kidneys are bilateral.' },
          { name: 'Unilateral', teach: 'Present on only one side.', mnemonic: 'Uni = one.' },
        ],
      },
      {
        id: 'body-positions', title: 'Supine & Prone', Diagram: BodyPositionsDiagram,
        quizPrompt: 'Which body position is highlighted?',
        regions: [
          { name: 'Supine', teach: 'Lying on the back with the face upward.', mnemonic: 'Supine → face UP.' },
          { name: 'Prone', teach: 'Lying on the abdomen with the face downward.' },
        ],
      },
      {
        id: 'foot-surface-terms', title: 'Foot Surface & Side Terms', Diagram: FootSurfaceTermsDiagram,
        quizPrompt: 'Which foot surface or side is highlighted?',
        regions: [
          { name: 'Dorsal surface of foot', teach: 'The superior/top surface of the foot.' },
          { name: 'Plantar surface of foot', teach: 'The sole of the foot.', mnemonic: 'Plantar = the surface you plant on the ground.' },
          { name: 'Tibial (medial) side of foot', teach: 'The side toward the tibia and body midline.' },
          { name: 'Fibular (lateral) side of foot', teach: 'The side toward the fibula, away from the body midline.' },
        ],
      },
      {
        id: 'hand-surface-terms', title: 'Hand Surface & Side Terms', qualityHold: true,
        quizPrompt: 'Which hand surface or side is highlighted?',
        regions: [
          { name: 'Palmar surface', teach: 'The palm surface of the hand.' },
          { name: 'Dorsal surface of hand', teach: 'The back surface of the hand.' },
          { name: 'Radial side', teach: 'The thumb side of the forearm and hand.', mnemonic: 'Radius = thumb side.' },
          { name: 'Ulnar side', teach: 'The little-finger side of the forearm and hand.', mnemonic: 'Ulna = pinky side.' },
        ],
      },
    ],
  },
  {
    id: 'skeletal', title: 'Skeletal System', icon: Atom,
    activities: [
      { id: 'skull-ant', title: 'Skull, Anterior', Diagram: SkullAntDiagram, regions: [
        { name: 'Frontal bone', teach: 'Forms the forehead and the roof of each orbit.' },
        { name: 'Superciliary arch', teach: 'The brow ridge above each orbit.', mnemonic: '"Supercilium" = eyebrow.' },
        { name: 'Orbit', teach: 'The bony socket housing the eye \u2014 built from seven different bones.' },
        { name: 'Superior orbital fissure', teach: 'The slit between the greater and lesser sphenoid wings, carrying cranial nerves III, IV, V1 and VI.' },
        { name: 'Greater wing of sphenoid', teach: 'Forms the posterolateral wall of the orbit.' },
        { name: 'Nasal bone', teach: 'The paired bones forming the bridge of the nose.' },
        { name: 'Anterior nasal aperture', teach: 'The pear-shaped opening of the nasal cavity, also called the piriform aperture.' },
        { name: 'Inferior nasal conchae', teach: 'The scroll-shaped bones on the lateral nasal wall that warm and humidify air.', mnemonic: '"Concha" = shell.' },
        { name: 'Vomer', teach: 'The midline plate forming the lower nasal septum.', mnemonic: 'Latin for ploughshare, which it resembles.' },
        { name: 'Infraorbital foramen', teach: 'The opening below the orbit transmitting the infraorbital nerve and vessels.' },
        { name: 'Zygomatic bone', teach: 'The cheekbone, forming the lateral orbital rim.' },
        { name: 'Maxilla', teach: 'The upper jaw, carrying the upper teeth and forming most of the hard palate.' },
        { name: 'Body of mandible', teach: 'The horizontal part of the lower jaw, carrying the lower teeth.' },
      ] },
      { id: 'skull-lat', title: 'Skull, Lateral', Diagram: SkullLatDiagram, regions: [
        { name: 'Frontal bone', teach: 'The forehead, meeting the parietal bone at the coronal suture.' },
        { name: 'Parietal bone', teach: 'Forms the side and roof of the cranium.' },
        { name: 'Temporal bone', teach: 'Houses the ear and carries the mastoid and styloid processes.' },
        { name: 'Occipital bone', teach: 'The back and base of the skull, containing the foramen magnum.' },
        { name: 'Sphenoid bone', teach: 'The butterfly-shaped bone at the skull base \u2014 its greater wing shows here.' },
        { name: 'Coronal suture', teach: 'Between frontal and parietal bones.', mnemonic: 'Runs like a crown across the head.' },
        { name: 'Squamous suture', teach: 'Between the temporal and parietal bones.', mnemonic: '"Squamous" = scale-like, from the overlapping edge.' },
        { name: 'Lambdoid suture', teach: 'Between the parietal and occipital bones.', mnemonic: 'Shaped like the Greek letter lambda.' },
        { name: 'Mastoid process of temporal bone', teach: 'The bony bump behind the ear \u2014 the sternocleidomastoid attaches here.' },
        { name: 'Styloid process of temporal bone', teach: 'The thin spike below the ear, anchoring several tongue and pharynx muscles.', mnemonic: '"Stylus" = pen, from its shape.' },
        { name: 'Zygomatic arch', teach: 'The bridge formed by the temporal and zygomatic bones \u2014 the masseter attaches beneath it.' },
        { name: 'Alveolar process of maxilla', teach: 'The tooth-bearing ridge of the upper jaw.' },
        { name: 'Anterior nasal spine', teach: 'The small midline projection at the base of the nasal aperture.' },
        { name: 'Mental foramen', teach: 'The opening on the mandible transmitting the mental nerve.', mnemonic: '"Mentum" = chin.' },
        { name: 'Ramus of mandible', teach: 'The vertical part of the lower jaw, rising to the joint.' },
        { name: 'Angle of mandible', teach: 'Where the ramus meets the body \u2014 a common fracture site.' },
        { name: 'Condylar process of mandible', teach: 'The posterior superior process of the mandibular ramus; its head articulates with the mandibular fossa and articular disc at the temporomandibular joint.' },
      ] },
      { id: 'skull-inf', title: 'Skull, Inferior', Diagram: SkullInfDiagram, regions: [
        { name: 'Foramen magnum', teach: 'The large opening where the brainstem becomes the spinal cord.', mnemonic: 'Latin for "great hole".' },
        { name: 'Occipital condyle', teach: 'The paired rockers that articulate with the atlas, allowing the nodding "yes" motion.' },
        { name: 'External occipital protuberance', teach: 'The midline bump at the back of the skull \u2014 the nuchal ligament attaches here.' },
        { name: 'Horizontal plate of palatine bone', teach: 'Forms the posterior third of the hard palate.' },
        { name: 'Palatine process of maxilla', teach: 'Forms the anterior two-thirds of the hard palate.' },
        { name: 'Incisive foramen', teach: 'The midline depression just behind the incisors, transmitting the nasopalatine nerve.' },
        { name: 'Choana (posterior nasal aperture)', teach: 'One of the paired posterior openings of the nasal cavity into the nasopharynx; together they are the choanae.' },
        { name: 'Zygomatic arch', teach: 'Seen from below, the arch stands clear of the skull wall.' },
      ] },
      { id: 'thorax', title: 'Thoracic Cage', Diagram: ThoraxDiagram, regions: [
        { name: 'Manubrium sterni', teach: 'The wide upper part of the sternum, articulating with the clavicles and the first ribs.', mnemonic: 'Manubrium means \u201chandle\u201d \u2014 the sternum is shaped like a sword.' },
        { name: 'Body of the sternum', teach: 'The long middle section. Ribs 2 to 7 attach along its edges.' },
        { name: 'Xiphoid process', teach: 'The small pointed tip at the bottom, cartilaginous in youth and ossifying with age.', mnemonic: 'Handle, blade, tip \u2014 manubrium, body, xiphoid.' },
        { name: 'Vertebrosternal (true) ribs (1–7)', teach: 'Ribs 1–7 attach directly to the sternum through their own costal cartilages.', mnemonic: 'True ribs reach the sternum on their own.' },
        { name: 'Vertebrochondral ribs (8–10)', teach: 'Ribs 8–10 attach indirectly to the sternum because their costal cartilages join the cartilage of the rib above, contributing to the costal margin.' },
        { name: 'Floating ribs (11–12)', teach: 'Ribs 11 and 12 have no anterior attachment to the sternum or costal margin; their anterior ends terminate in the posterior abdominal wall musculature. They are a subset of the false ribs.' },
      ] },
      { id: 'clavicle', title: 'Clavicle', Diagram: ClavicleDiagram, regions: [
        { name: 'Sternal end of clavicle', teach: 'The bulkier, roughly triangular medial end articulating with the manubrium. Its underside carries a rough impression for the costoclavicular ligament.' },
        { name: 'Acromial end of clavicle', teach: 'The flattened lateral end meeting the acromion of the scapula.', mnemonic: 'Bulky and rounded to the sternum; flat and paddle-like to the acromion.' },
      ] },
      { id: 'scapula-ant', title: 'Scapula, Anterior', Diagram: ScapulaAntDiagram, regions: [
        { name: 'Coracoid process', teach: 'The hook-shaped projection reaching forward under the clavicle. Pectoralis minor and the short head of biceps attach here.', mnemonic: 'Coracoid means \u201craven-like\u201d \u2014 it curves like a beak.' },
        { name: 'Scapular notch', teach: 'The U-shaped indentation on the superior border, bridged in life by a ligament. The suprascapular nerve passes through it.' },
        { name: 'Superior angle', teach: 'The corner where the superior and medial borders meet. Levator scapulae inserts here.' },
        { name: 'Glenoid cavity', teach: 'The shallow oval socket receiving the head of the humerus. Its shallowness allows huge range of movement \u2014 and easy dislocation.' },
        { name: 'Neck of the scapula', teach: 'The slight constriction just medial to the glenoid cavity.' },
        { name: 'Subscapular fossa', teach: 'The broad concave surface facing the ribs, filled by the subscapularis muscle.', mnemonic: 'Sub- = under. It faces the ribcage.' },
        { name: 'Inferior angle', teach: 'The lowest point of the scapula, easily felt through the skin and used as a landmark for counting ribs.' },
      ] },
      { id: 'scapula-post', title: 'Scapula, Posterior', Diagram: ScapulaPostDiagram, regions: [
        { name: 'Spine of the scapula', teach: 'The prominent ridge crossing the back of the blade, dividing supraspinous from infraspinous fossa.' },
        { name: 'Acromion process', teach: 'The flat lateral end of the spine, forming the point of the shoulder and articulating with the clavicle.' },
        { name: 'Infraspinous fossa', teach: 'The large hollow below the spine, occupied by infraspinatus.' },
        { name: 'Superior angle', teach: 'The upper medial corner, seen here from behind.' },
        { name: 'Inferior angle', teach: 'The lowest point, seen here from behind.' },
      ] },
      { id: 'hand', title: 'Hand', Diagram: HandDiagram, regions: [
        { name: 'Metacarpals', teach: 'The five long bones of the palm, numbered one to five from the thumb.' },
        { name: 'Proximal phalanx', teach: 'The first bone of a digit. The thumb has only two phalanges; the other four fingers have three.' },
        { name: 'Distal phalanx', teach: 'The tip bone of a digit, supporting the nail bed.', mnemonic: 'Proximal, middle, distal \u2014 except the thumb, which skips the middle.' },
      ] },
      { id: 'wrist', title: 'Carpal Bones', Diagram: WristDiagram, regions: [
        { name: 'Scaphoid', teach: 'The boat-shaped bone on the thumb side of the proximal row. The most commonly fractured carpal, and slow to heal because of its blood supply.' },
        { name: 'Lunate', teach: 'The crescent-shaped bone beside the scaphoid. The most commonly dislocated carpal.', mnemonic: 'Luna \u2014 moon-shaped.' },
        { name: 'Triquetrum', teach: 'The three-cornered bone on the little-finger side of the proximal row.' },
        { name: 'Pisiform', teach: 'A pea-sized bone sitting on the front of the triquetrum. It is a sesamoid, formed inside a tendon.', mnemonic: 'Pisum \u2014 a pea.' },
        { name: 'Trapezium', teach: 'The distal-row bone under the thumb, with a saddle joint that gives the thumb its opposition.' },
        { name: 'Trapezoid', teach: 'The small wedge beside the trapezium, in line with the index finger.', mnemonic: 'TrapeziUM is by the thUMb; trapezoid is next door.' },
        { name: 'Capitate', teach: 'The largest carpal, sitting in the centre of the wrist with a rounded head.', mnemonic: 'Caput \u2014 head.' },
        { name: 'Hamate', teach: 'The distal-row bone on the little-finger side, carrying a hook on its palmar surface.', mnemonic: 'Hamulus \u2014 a little hook.' },
      ] },
      { id: 'hip-lat', title: 'Hip Bone, Lateral', Diagram: HipLatDiagram, regions: [
        { name: 'Acetabulum', teach: 'The deep cup receiving the head of the femur. Its depth is why the hip dislocates far less readily than the shoulder.', mnemonic: 'Latin for \u201cvinegar cup\u201d.' },
        { name: 'Posterior superior iliac spine', teach: 'The projection at the back end of the iliac crest, marked on the skin by a dimple.' },
        { name: 'Posterior inferior iliac spine', teach: 'A smaller projection just below the PSIS, forming the upper edge of the greater sciatic notch.' },
        { name: 'Greater sciatic notch', teach: 'The large concavity below the PIIS. The sciatic nerve leaves the pelvis through it.' },
        { name: 'Ischial spine', teach: 'The pointed projection separating the greater notch above from the lesser notch below.', mnemonic: 'The spine is the divider between greater and lesser notches.' },
        { name: 'Lesser sciatic notch', teach: 'The smaller concavity beneath the ischial spine.' },
        { name: 'Ischial tuberosity', teach: 'The thick roughened mass at the bottom, bearing your weight when seated and giving origin to the hamstrings.' },
      ] },
      { id: 'pelvis', title: 'Pelvis, Anterior', Diagram: PelvisDiagram, regions: [
        { name: 'Iliac crest', teach: 'The curved upper rim of the ilium, easily felt as the top of the hip. A common site for bone marrow aspiration.' },
        { name: 'Anterior superior iliac spine', teach: 'The blunt projection at the front end of the iliac crest. The inguinal ligament and sartorius attach here.', mnemonic: 'Usually shortened to ASIS \u2014 a key surface landmark.' },
        { name: 'Anterior inferior iliac spine', teach: 'A smaller projection below the ASIS, giving origin to rectus femoris.' },
        { name: 'Sacral promontory', teach: 'The forward-jutting upper lip of the first sacral vertebra, marking the entrance to the true pelvis.' },
        { name: 'Pubic symphysis', teach: 'The midline cartilaginous joint uniting the two pubic bones. It softens in late pregnancy.' },
        { name: 'Pubic tubercle', teach: 'A small bump on the superior pubic ramus just lateral to the symphysis, marking the medial end of the inguinal ligament.' },
        { name: 'Obturator foramen', teach: 'The large opening bounded by the pubis and ischium, closed in life by a membrane. Vessels and a nerve pass through its upper corner.' },
        { name: 'Ischium', teach: 'The lower posterior part of the hip bone. Its tuberosity is what you sit on.', mnemonic: 'Three fused bones make the hip: ilium above, pubis in front, ischium below.' },
      ] },
      { id: 'foot', title: 'Foot', Diagram: FootDiagram, regions: [
        { name: 'Calcaneus', teach: 'The heel bone \u2014 the largest tarsal, taking the impact of every step.' },
        { name: 'Talus', teach: 'Sits on top of the calcaneus and forms the ankle joint with the tibia and fibula. No muscle attaches to it.' },
        { name: 'Navicular', teach: 'The boat-shaped bone on the medial side, between the talus and the cuneiforms.', mnemonic: 'Navicular from navis, a ship.' },
        { name: 'Cuboid', teach: 'The lateral tarsal, sitting in front of the calcaneus and behind the fourth and fifth metatarsals.' },
        { name: 'Medial cuneiform', teach: 'The largest of the three wedge-shaped bones, articulating with the first metatarsal.' },
        { name: 'Intermediate cuneiform', teach: 'The smallest cuneiform, between the medial and lateral, in front of the second metatarsal.' },
        { name: 'Lateral cuneiform', teach: 'The most lateral of the three, sitting beside the cuboid.', mnemonic: 'Three cuneiforms in a row: medial, intermediate, lateral \u2014 big toe side outward.' },
        { name: 'Metatarsals', teach: 'The five long bones of the sole, numbered one to five from the big toe.' },
        { name: 'Proximal phalanx', teach: 'The first bone of a toe. The great toe has only two phalanges; the others have three.' },
        { name: 'Distal phalanx', teach: 'The tip bone of a toe, carrying the nail bed.' },
      ] },
      { id: 'tibfib', title: 'Tibia and Fibula', Diagram: TibFibDiagram, regions: [
        { name: 'Medial condyle of tibia', teach: 'The medial articular condyle at the proximal tibia, receiving the medial femoral condyle.' },
        { name: 'Tibial tuberosity', teach: 'The raised bump on the front of the tibia just below the condyles, where the patellar ligament attaches.', mnemonic: 'The bump you feel below your kneecap.' },
        { name: 'Head of fibula', teach: 'The knob at the top of the fibula. It takes no weight \u2014 the fibula is for muscle attachment and ankle stability.' },
        { name: 'Medial malleolus', teach: 'The tibia\u2019s downward projection forming the bump on the inner ankle.' },
        { name: 'Lateral malleolus', teach: 'The fibula\u2019s lower end, forming the outer ankle bump. It sits lower than the medial malleolus.', mnemonic: 'Two ankle bumps, two different bones \u2014 tibia inside, fibula outside.' },
      ] },
      { id: 'ulnarad', title: 'Ulna and Radius', Diagram: UlnaRadDiagram, regions: [
        { name: 'Olecranon process', teach: 'The beak at the top of the ulna forming the point of the elbow. It swings into the olecranon fossa of the humerus when the arm straightens.' },
        { name: 'Trochlear notch', teach: 'The deep C-shaped hollow of the ulna that grips the trochlea of the humerus, making the elbow a stable hinge.' },
        { name: 'Coronoid process', teach: 'The lower lip of the trochlear notch, projecting forward.', mnemonic: 'Olecranon above, coronoid below \u2014 the two jaws of the notch.' },
        { name: 'Head of radius', teach: 'The disc at the top of the radius. It spins against the capitulum, which is what lets you turn your palm over.' },
        { name: 'Head of ulna', teach: 'The small rounded distal end of the ulna, at the little-finger side of the wrist.', mnemonic: 'The radius has its head at the elbow; the ulna has its head at the wrist \u2014 opposite ends.' },
        { name: 'Radial styloid process', teach: 'The pointed projection at the lower end of the radius, on the thumb side. It reaches further down than the ulnar side.' },
      ] },
      { id: 'femur', title: 'Femur', Diagram: FemurDiagram, regions: [
        { name: 'Head of femur', teach: 'The ball at the top, fitting deep into the acetabulum. Unlike the shoulder, this socket is deep \u2014 stable, but far less mobile.' },
        { name: 'Neck of femur', teach: 'The angled bar joining head to shaft. It is the classic site of a \u201chip fracture\u201d in the elderly.' },
        { name: 'Greater trochanter', teach: 'The large lateral prominence you can feel at the side of the hip. The gluteal muscles attach here.' },
        { name: 'Lesser trochanter', teach: 'The smaller medial bump below the neck, where iliopsoas inserts.', mnemonic: 'Greater is lateral and big; lesser is medial and small.' },
        { name: 'Linea aspera', teach: 'The rough vertical ridge down the back of the shaft, giving attachment to the adductors. Only visible from behind.', mnemonic: 'Latin for \u201crough line\u201d.' },
        { name: 'Lateral condyle of femur', teach: 'The lateral of the two rounded articular condyles at the distal femur.' },
        { name: 'Lateral epicondyle of femur', teach: 'The bony prominence just superior to the lateral condyle of the femur.' },
        { name: 'Medial epicondyle of femur', teach: 'The bony prominence just superior to the medial condyle of the femur.', mnemonic: 'Epi- = upon. The epicondyle sits above the condyle.' },
        { name: 'Intercondylar fossa', teach: 'The deep depression between the medial and lateral femoral condyles on the posterior distal femur; the cruciate ligaments attach within this region.' },
      ] },
      { id: 'humerus', title: 'Humerus', Diagram: HumerusDiagram, regions: [
        { name: 'Head of humerus', teach: 'The smooth proximal articular surface of the humerus, facing medially and slightly superiorly to articulate with the glenoid cavity of the scapula.' },
        { name: 'Anatomical neck', teach: 'The shallow groove marking the old growth plate, running just below the rim of the head.', mnemonic: 'Anatomical neck is the true edge of the head; surgical neck is where it actually breaks.' },
        { name: 'Greater tubercle', teach: 'The lateral prominence below the head, the attachment for three of the four rotator cuff muscles.' },
        { name: 'Lesser tubercle', teach: 'The smaller medial prominence. The intertubercular groove between the two carries the biceps tendon.' },
        { name: 'Surgical neck', teach: 'The narrowing below the tubercles \u2014 a common fracture site, and the axillary nerve wraps around it.' },
        { name: 'Capitulum', teach: 'The rounded lateral articular knob that receives the head of the radius.', mnemonic: 'Capitulum is a little head \u2014 it meets the head of the radius.' },
        { name: 'Trochlea', teach: 'The medial spool-shaped surface that grips the trochlear notch of the ulna. It extends further down than the capitulum.' },
        { name: 'Lateral epicondyle of humerus', teach: 'The bony bump above the capitulum, giving origin to the forearm extensor muscles.' },
        { name: 'Medial epicondyle of humerus', teach: 'The larger, more projecting bump above the trochlea. The ulnar nerve runs behind it \u2014 the \u201cfunny bone\u201d.' },
        { name: 'Olecranon fossa', teach: 'The hollow on the back that receives the olecranon of the ulna when the elbow straightens.' },
      ] },
      { id: 'cervical', title: 'Cervical Vertebrae', Diagram: CervicalDiagram, regions: [
        { name: 'Vertebral foramen', teach: 'The central opening the spinal cord passes through \u2014 large and triangular in the cervical spine.' },
        { name: 'Transverse foramen', teach: 'The paired holes in the transverse processes carrying the vertebral arteries \u2014 unique to cervical vertebrae.', mnemonic: 'If it has transverse foramina, it is cervical.' },
        { name: 'Vertebral body', teach: 'The weight-bearing block at the front; small in the cervical region.' },
        { name: 'Anterior arch of atlas', teach: 'C1 has no body \u2014 just anterior and posterior arches forming a ring.' },
        { name: 'Dens of axis', teach: 'The peg of C2 projecting up into the atlas, the pivot for shaking the head "no".', mnemonic: 'Also called the odontoid process \u2014 "tooth-like".' },
        { name: 'Superior articular facet', teach: 'The surface where one vertebra articulates with the one above.' },
        { name: 'Typical cervical vertebrae', teach: 'A representative mid-cervical vertebra \u2014 small body, bifid spinous process, transverse foramen each side.', mnemonic: 'Only cervical vertebrae have transverse foramina.' },
        { name: 'Atlas', teach: 'C1 \u2014 no body and no spinous process, just a ring. It carries the skull.', mnemonic: 'Atlas held up the world; C1 holds up the head.' },
        { name: 'Axis', teach: 'C2 \u2014 its dens projects up into the ring of the atlas, forming the pivot the head rotates on.', mnemonic: 'The head turns on the axis, saying \u201cno\u201d.' },
      ] },
      { id: 'column', title: 'Vertebral Column, Lateral', Diagram: ColumnDiagram, regions: [
        { name: 'Cervical curvature', teach: 'The forward (lordotic) curve of the neck \u2014 seven vertebrae. Develops when a baby lifts its head.' },
        { name: 'Thoracic curvature', teach: 'The backward (kyphotic) curve of the chest \u2014 twelve vertebrae, present from birth.' },
        { name: 'Lumbar curvature', teach: 'The forward curve of the lower back \u2014 five vertebrae. Develops when a child starts walking.' },
        { name: 'Sacrum', teach: 'Five fused vertebrae forming the back of the pelvis.' },
        { name: 'Coccyx', teach: 'The tailbone \u2014 three to five fused rudimentary vertebrae.' },
        { name: 'Intervertebral disc', teach: 'The fibrocartilage cushion between adjacent vertebral bodies.' },
      ] },
    ],
  },
  {
    id: 'integumentary', title: 'Integumentary System', icon: Layers,
    activities: [
      {
        id: 'skin-section', title: 'Skin, Section', Diagram: SkinDiagram,
        regions: [
          { name: 'Epidermis', teach: 'The outermost layer \u2014 stratified squamous epithelium, with no blood supply of its own.', mnemonic: '"Epi" = upon. It sits upon the dermis.' },
          { name: 'Dermal papillae', teach: 'The wavy peg-like projections where dermis interlocks with epidermis \u2014 they anchor the two together and form fingerprints.' },
          { name: 'Papillary dermis', teach: 'The thin upper dermal layer of loose connective tissue, carrying the capillaries that feed the epidermis.' },
          { name: 'Reticular dermis', teach: 'The thick deeper layer of dense irregular connective tissue \u2014 gives skin its strength and elasticity.', mnemonic: '"Reticular" = net-like, from its woven collagen.' },
          { name: 'Hypodermis (subcutaneous tissue)', teach: 'The fatty hypodermis beneath the dermis \u2014 insulates, cushions, and anchors skin to underlying tissue.', mnemonic: 'Not technically part of the skin, but always shown with it.' },
          { name: 'Hair shaft', teach: 'The visible part of the hair, above the skin surface \u2014 dead keratinised cells.' },
          { name: 'Hair follicle', teach: 'The tube of epidermis that extends down into the dermis, surrounding the hair root.' },
          { name: 'Sebaceous gland', teach: 'Opens into the hair follicle and secretes sebum, oiling hair and skin.', mnemonic: '"Sebum" = grease. Blocked sebaceous glands cause acne.' },
          { name: 'Apocrine sweat gland', teach: 'Larger, opens into hair follicles in the axilla and groin \u2014 active from puberty, and the source of body odour.' },
          { name: 'Eccrine sweat gland', teach: 'A simple coiled tubular sweat gland whose duct opens directly onto the skin surface; eccrine secretion is the principal mechanism for evaporative thermoregulation.', mnemonic: 'Eccrine ducts open to the skin surface; apocrine ducts usually open into hair follicles.' },
        ],
      },
      {
        id: 'hair-follicle', title: 'Hair Follicle, Longitudinal Section', Diagram: HairDiagram,
        regions: [
          { name: 'Hair medulla', teach: 'The soft core at the centre of the hair shaft.', mnemonic: 'Medulla = middle, everywhere it appears in anatomy.' },
          { name: 'Hair cortex', teach: 'The thick keratinised layer surrounding the medulla \u2014 the bulk of the hair, and where pigment sits.' },
          { name: 'Dermal root sheath', teach: 'The connective tissue layer wrapping the follicle, continuous with the surrounding dermis.' },
          { name: 'Hair matrix', teach: 'The actively dividing cell layer at the base \u2014 all hair growth happens here.', mnemonic: 'Matrix = where it is made.' },
          { name: 'Hair papilla', teach: 'The small connective-tissue peg at the very bottom, carrying the blood supply that feeds the matrix.' },
          { name: 'Sebaceous gland', teach: 'Opens into the follicle partway up, oiling the emerging hair.' },
        ],
      },
      {
        id: 'nail-sagittal', title: 'Nail, Sagittal Section', Diagram: NailDiagram,
        regions: [
          { name: 'Nail plate', teach: 'The hard visible nail itself \u2014 tightly packed keratinised cells.' },
          { name: 'Nail bed', teach: 'The vascular epithelium under the plate \u2014 its blood supply is what makes nails look pink.' },
          { name: 'Nail matrix', teach: 'The growth zone at the proximal end \u2014 all nail growth originates here.', mnemonic: 'Same idea as the hair matrix: matrix = where it is made.' },
          { name: 'Lunula', teach: 'The pale crescent near the base, where thickened matrix hides the vessels beneath.', mnemonic: 'Latin for "little moon".' },
          { name: 'Eponychium', teach: 'The cuticle \u2014 the fold of skin overlapping the proximal nail.', mnemonic: '"Epi" = upon, "onych" = nail.' },
          { name: 'Distal phalanx', teach: 'The fingertip bone the whole nail apparatus sits on.' },
        ],
      },
    ],
  },
  {
    id: 'cellular', title: 'Cellular Level', icon: Microscope,
    activities: [
      {
        id: 'cell', title: 'Cell Structure', Diagram: CellDiagram,
        regions: [
          { name: 'Nucleus', teach: "The cell's control center, holding DNA \u2014 usually the most visible structure, near the middle." },
          { name: 'Mitochondria', teach: "The cell's power plants, generating ATP \u2014 cells with high energy needs pack in more of these." },
          { name: 'Plasma membrane (cell membrane)', teach: 'The outer boundary, controlling what enters and exits \u2014 a flexible, selective barrier, not a rigid wall.' },
          { name: 'Cytosol', teach: 'The intracellular fluid surrounding the organelles. Cytosol is the fluid component of the cytoplasm; cytoplasm includes cytosol, organelles and inclusions.' },
          { name: 'Ribosomes', teach: 'Tiny structures dotted through the cytoplasm, where proteins get built from genetic instructions.' },
        ],
      },
    ],
  },
  {
    id: 'muscular', title: 'Muscular System', icon: Dumbbell,
    activities: [
      { id: 'headneck-lat', title: 'Head & Neck, Lateral', Diagram: HeadNeckDiagram, regions: [
        { name: 'Frontal belly of occipitofrontalis', teach: 'The forehead belly \u2014 raises the eyebrows.', mnemonic: 'Frontalis and occipitalis are two bellies of one muscle.' },
        { name: 'Epicranial aponeurosis (galea aponeurotica)', teach: 'The broad tendinous sheet connecting the frontal and occipital bellies of occipitofrontalis across the scalp.', mnemonic: 'Galea means helmet; epicranial aponeurosis is the formal descriptive term.' },
        { name: 'Occipital belly of occipitofrontalis', teach: 'The rear belly, anchored to the occipital bone \u2014 pulls the scalp backward.' },
        { name: 'Temporalis', teach: 'The fan filling the temporal fossa, closing the jaw.' },
        { name: 'Orbicularis oculi', teach: 'The sphincter ring around the eye.' },
        { name: 'Orbicularis oris', teach: 'The sphincter ring around the mouth.' },
        { name: 'Nasalis', teach: 'Compresses the bridge and flares the nostrils.' },
        { name: 'Levator labii superioris', teach: 'Lifts the upper lip.' },
        { name: 'Zygomaticus major', teach: 'Cheekbone to mouth corner \u2014 the smiling muscle.' },
        { name: 'Masseter', teach: 'The thick chewing muscle over the mandibular ramus.' },
        { name: 'Depressor anguli oris', teach: 'Pulls the mouth corner down.' },
        { name: 'Mentalis', teach: 'The chin muscle, pushing the lower lip up.' },
        { name: 'Platysma', teach: 'The broad thin sheet fanning down the neck.' },
        { name: 'Sternocleidomastoid', teach: 'The diagonal strap from mastoid to sternum and clavicle \u2014 turns and tilts the head.' },
        { name: 'Trapezius', teach: 'Its upper fibers form the back of the neck contour.' },
        { name: 'Levator scapulae', teach: 'Runs from the cervical transverse processes to the scapula \u2014 lifts the shoulder blade.' },
      ] },
      { id: 'abwall', title: 'Abdominal Wall, Layers', Diagram: AbWallDiagram, regions: [
        { name: 'External oblique', teach: 'The outermost layer, its fibres running down and forward \u2014 the direction your hands go into your pockets.' },
        { name: 'Internal oblique', teach: 'The middle layer, fibres running up and forward, at right angles to external oblique.', mnemonic: 'The three layers cross like plywood \u2014 that is what makes the wall strong.' },
        { name: 'Transversus abdominis', teach: 'The deepest of the three flat muscles, its fibres running horizontally across the abdomen.' },
        { name: 'Rectus abdominis', teach: 'The vertical strap either side of the midline, divided by tendinous intersections and enclosed in a sheath formed by the other three.' },
      ] },
      { id: 'cuff', title: 'Posterior Rotator Cuff & Teres Major', Diagram: CuffDiagram, regions: [
        { name: 'Supraspinatus', teach: 'Lies above the scapular spine and starts abduction of the arm. The most commonly torn cuff muscle.' },
        { name: 'Infraspinatus', teach: 'Fills the fossa below the spine and laterally rotates the arm.' },
        { name: 'Teres minor', teach: 'A narrow band below infraspinatus, also laterally rotating the arm. It is a rotator cuff muscle; teres major is not.', mnemonic: 'SITS: Supraspinatus, Infraspinatus, Teres minor, Subscapularis.' },
        { name: 'Teres major', teach: 'The thicker band below teres minor. Despite the name it is not part of the cuff \u2014 it medially rotates and adducts.' },
      ] },
      { id: 'triceps', title: 'Triceps Brachii', Diagram: TricepsDiagram, regions: [
        { name: 'Long head of triceps brachii', teach: 'Arises from the scapula, so it is the only head crossing the shoulder as well as the elbow.' },
        { name: 'Lateral head of triceps brachii', teach: 'Arises from the posterior humerus above the radial groove, lateral to the long head.' },
        { name: 'Medial head of triceps brachii', teach: 'The deepest head, lying beneath the other two and arising from the humerus below the radial groove.', mnemonic: 'Three heads, one tendon, one job \u2014 extending the elbow.' },
      ] },
      { id: 'thigh', title: 'Thigh', Diagram: ThighDiagram, regions: [
        { name: 'Rectus femoris', teach: 'The central quadriceps head, and the only one crossing the hip as well as the knee.' },
        { name: 'Vastus lateralis', teach: 'The large lateral quadriceps head, and a common intramuscular injection site.' },
        { name: 'Vastus medialis', teach: 'The medial quadriceps head, forming the teardrop bulge just above the knee.' },
        { name: 'Sartorius', teach: 'The long strap crossing the thigh from hip to medial knee \u2014 the longest muscle in the body.', mnemonic: 'Sartor = tailor: it makes the cross-legged tailor\u2019s posture.' },
        { name: 'Iliopsoas', teach: 'The main hip flexor, passing over the pelvic brim to the lesser trochanter.' },
        { name: 'Pectineus', teach: 'A short flat muscle from the pubis to the femur, flexing and adducting the hip.' },
        { name: 'Adductor longus', teach: 'The most anterior of the adductor group, running from pubis to the linea aspera.' },
        { name: 'Gracilis', teach: 'The most medial and superficial thigh muscle, a long thin strap crossing both hip and knee.', mnemonic: 'Gracilis = slender.' },
        { name: 'Tensor fasciae latae', teach: 'A short muscle at the front of the hip that tightens the iliotibial tract.' },
        { name: 'Iliotibial tract', teach: 'The thick fibrous band running down the lateral thigh from hip to tibia, stabilising the knee.' },
        { name: 'Gluteus maximus', teach: 'The largest and most superficial gluteal muscle, extending the hip when climbing or rising from sitting.' },
        { name: 'Biceps femoris', teach: 'The lateral hamstring. Its tendon can be felt on the outer side behind the knee.' },
        { name: 'Semitendinosus', teach: 'The middle of the three hamstrings, with a long cord-like tendon medially.' },
        { name: 'Semimembranosus', teach: 'The most medial hamstring, lying deep to semitendinosus.', mnemonic: 'Three hamstrings: biceps femoris lateral, semitendinosus and semimembranosus medial.' },
      ] },
      { id: 'leg', title: 'Leg', Diagram: LegDiagram, regions: [
        { name: 'Gastrocnemius', teach: 'The superficial calf muscle with two heads, crossing both knee and ankle. It gives the calf its bulge.', mnemonic: 'Gastro- belly, kneme- leg: the belly of the leg.' },
        { name: 'Soleus', teach: 'Lies deep to gastrocnemius and emerges on both sides of it. It crosses only the ankle, so it works whether the knee is bent or straight.', mnemonic: 'Named for its flat sole-fish shape.' },
        { name: 'Tibialis anterior', teach: 'Runs alongside the tibial crest and dorsiflexes the foot. Weakness here causes foot drop.' },
        { name: 'Extensor digitorum longus', teach: 'Lateral to tibialis anterior, extending the toes and helping dorsiflex the ankle.' },
        { name: 'Fibularis longus', teach: 'On the lateral side, arising from the fibula. It everts the foot and supports the transverse arch.', mnemonic: 'Also called peroneus longus \u2014 same muscle, older name.' },
      ] },
      { id: 'torso-deep', title: 'Torso, Deep Layer', Diagram: TorsoDeepDiagram, regions: [
        { name: 'Pectoralis major', teach: 'Intact on one side \u2014 compare it with the cutaway side to see what lies beneath.' },
        { name: 'Pectoralis minor', teach: 'The small fan deep to pectoralis major, running from ribs 3\u20135 to the coracoid process \u2014 pulls the scapula forward and down.', mnemonic: 'Only visible once pec major is removed.' },
        { name: 'Serratus anterior', teach: 'The saw-toothed slips on the lateral ribs, holding the scapula against the chest wall.', mnemonic: 'Paralysis causes winged scapula.' },
        { name: 'External intercostals', teach: 'Fill the spaces between ribs, fibers running down-and-forward \u2014 they elevate the ribs during inspiration.', mnemonic: 'Same direction as external oblique: hands-in-pockets.' },
        { name: 'Rib', teach: 'The bony arches of the thoracic cage, seen here with the overlying muscle removed.' },
        { name: 'Rectus abdominis', teach: 'The vertical strap flexing the trunk.' },
        { name: 'Linea alba', teach: 'The pale midline seam of fused aponeuroses.' },
        { name: 'External oblique', teach: 'The outermost lateral abdominal sheet.' },
        { name: 'Deltoid', teach: 'Caps the shoulder, raising the arm.' },
        { name: 'Biceps brachii', teach: 'The front of the upper arm, flexing the elbow.' },
      ] },
      {
        id: 'torso-1', title: 'Torso I \u2014 Chest, Shoulder & Arm', Diagram: TorsoDiagram,
        regions: [
          { name: 'Pectoralis major', teach: 'The broad fan across the chest, pulling the arm forward and across the body.', mnemonic: 'The "hugging" muscle \u2014 it brings the arms together in front.' },
          { name: 'Deltoid', teach: 'Caps the shoulder like a shoulder pad, raising the arm out to the side.', mnemonic: 'Named for its triangular delta shape.' },
          { name: 'Trapezius', teach: 'Spans neck to mid-back; here you see its upper fibers running to the collarbone.' },
          { name: 'Sternocleidomastoid', teach: 'The prominent neck strap from behind the ear to the sternum and clavicle.' },
          { name: 'Biceps brachii', teach: 'The front of the upper arm \u2014 flexes the elbow and supinates the forearm.', mnemonic: '"Bi-ceps" = two heads, both crossing the shoulder.' },
          { name: 'Brachioradialis', teach: 'Runs along the thumb side of the forearm, flexing the elbow in mid-position.', mnemonic: 'From the brachium (arm) to the radius \u2014 the name is the route.' },
          { name: 'Triceps brachii', teach: 'The back of the upper arm \u2014 extends the elbow. Best seen from behind.', mnemonic: 'Three heads, and it does the opposite of biceps.' },
        ],
      },
      {
        id: 'torso-2', title: 'Torso II \u2014 Abdomen & Back', Diagram: TorsoDiagram,
        regions: [
          { name: 'Rectus abdominis', teach: 'The paired vertical strap down the front of the abdomen \u2014 flexes the trunk.', mnemonic: 'The "six-pack". "Rectus" = straight, because the fibers run vertically.' },
          { name: 'Linea alba', teach: 'The pale midline seam where the abdominal aponeuroses meet.', mnemonic: 'Latin for "white line" \u2014 it is tendon, not muscle.' },
          { name: 'Tendinous intersection', teach: 'The horizontal bands crossing rectus abdominis \u2014 they create the six-pack segments.' },
          { name: 'External oblique', teach: 'The outermost lateral abdominal sheet, fibers running down-and-forward.', mnemonic: 'Hands-in-pockets direction.' },
          { name: 'Serratus anterior', teach: 'Finger-like slips on the lateral ribcage, pulling the scapula forward around the chest.', mnemonic: '"Serrated" \u2014 the slips look like saw teeth.' },
          { name: 'Latissimus dorsi', teach: 'The widest back muscle, pulling the arm down and back. Seen from behind.', mnemonic: '"Latissimus" = widest, "dorsi" = of the back.' },
          { name: 'Infraspinatus', teach: 'A rotator cuff muscle below the scapular spine, rotating the arm outward.', mnemonic: '"Infra" = below, "spinatus" = the scapular spine.' },
          { name: 'Teres major', teach: 'Runs from the scapula\u2019s lower border to the humerus, assisting latissimus dorsi.', mnemonic: 'Nicknamed "lat\u2019s little helper".' },
          { name: 'Thoracolumbar fascia', teach: 'A broad multilayered fascial complex of the posterior trunk that invests the deep back muscles and provides important attachments for trunk musculature.' },
          { name: 'Gluteus medius', teach: 'On the upper outer hip, steadying the pelvis when standing on one leg.' },
        ],
      },
      {
        id: 'facial-1', title: 'Facial Muscles I \u2014 Scalp, Eye & Nose', Diagram: FaceDiagram,
        regions: [
          { name: 'Frontal belly of occipitofrontalis', teach: 'A broad sheet over the forehead with vertical fibers \u2014 raises the eyebrows and wrinkles the forehead.', mnemonic: 'The "surprised" muscle. "Front" = forehead.' },
          { name: 'Temporalis', teach: 'A wide fan over the temple, converging down to the jaw \u2014 closes the jaw.', mnemonic: 'Clench your teeth and feel it bulge above your ear.' },
          { name: 'Corrugator supercilii', teach: 'Small and deep, running between the eyebrows \u2014 pulls them into a vertical frown line.', mnemonic: '"Corrugate" = to wrinkle. The worry muscle.' },
          { name: 'Procerus', teach: 'A short vertical strip over the bridge of the nose \u2014 wrinkles the nose.', mnemonic: 'The "disgust" muscle.' },
          { name: 'Orbicularis oculi', teach: 'A sphincter of concentric rings encircling each eye \u2014 closes the lid and squints.', mnemonic: '"Orbicularis" = circular, "oculi" = eye.' },
          { name: 'Nasalis', teach: 'Sits across the nose, compressing the bridge and flaring the nostrils.', mnemonic: 'Flare your nostrils \u2014 that\u2019s nasalis.' },
        ],
      },
      {
        id: 'facial-2', title: 'Facial Muscles II \u2014 Mouth & Cheek', Diagram: FaceDiagram,
        regions: [
          { name: 'Orbicularis oris', teach: 'The circular sphincter surrounding the mouth \u2014 closes and purses the lips.', mnemonic: '"Oris" = mouth. Same root as "oral."' },
          { name: 'Levator labii superioris', teach: 'Runs from below the eye down to the upper lip, lifting it.', mnemonic: 'Reads as a sentence: "lifter of the upper lip."' },
          { name: 'Zygomaticus major', teach: 'The longer, angled strap from cheekbone to mouth corner \u2014 the smiling muscle.', mnemonic: 'Both zygomaticus muscles anchor to the zygomatic (cheek) bone.' },
          { name: 'Zygomaticus minor', teach: 'The shorter, more vertical twin just medial to the major, lifting the upper lip.' },
          { name: 'Risorius', teach: 'A thin horizontal strap pulling the mouth corner straight out sideways.', mnemonic: 'From "risus," Latin for laughter.' },
          { name: 'Buccinator', teach: 'The deep quadrilateral cheek muscle \u2014 presses the cheek against the teeth while chewing.', mnemonic: 'From "buccina," Latin for trumpet \u2014 the trumpeter\u2019s muscle.' },
          { name: 'Depressor anguli oris', teach: 'A triangle running from the jawline up to the mouth corner, pulling it down.', mnemonic: 'Reads literally: "depresses the angle of the mouth." The frown.' },
        ],
      },
      {
        id: 'facial-3', title: 'Facial Muscles III \u2014 Jaw & Neck', Diagram: FaceDiagram,
        regions: [
          { name: 'Masseter', teach: 'A thick rectangle over the jaw angle \u2014 the main chewing muscle.', mnemonic: 'From Greek "masasthai," to chew. Clench and feel it pop out.' },
          { name: 'Mentalis', teach: 'A small paired muscle on the chin \u2014 pushes the lower lip up and outward.', mnemonic: '"Mentum" = chin. The pouting muscle.' },
          { name: 'Depressor labii inferioris', teach: 'Runs from the mandible up to the lower lip, pulling it down and out.' },
          { name: 'Platysma', teach: 'A broad, thin sheet fanning from the jaw down across the neck to the collarbone.', mnemonic: 'Greek for "flat plate" \u2014 describes its thin, sheet-like shape.' },
          { name: 'Sternocleidomastoid', teach: 'A prominent strap running diagonally from behind the ear down to the sternum.', mnemonic: 'Its name lists its three attachments: sternum, clavicle (cleido), mastoid process.' },
        ],
      },
      {
        id: 'posterior', title: 'Posterior Head & Neck', Diagram: PosteriorDiagram,
        regions: [
          { name: 'Occipital belly of occipitofrontalis', teach: 'The rear belly of occipitofrontalis, anchored to the occipital bone \u2014 pulls the scalp backward.', mnemonic: 'Same muscle sheet as frontalis, joined across the skull by the galea aponeurotica.' },
          { name: 'Splenius capitis', teach: 'A broad strap running up from the upper spine to the mastoid \u2014 extends and rotates the head.', mnemonic: '"Splenius" = bandage; it wraps the deeper neck muscles like one.' },
          { name: 'Semispinalis capitis', teach: 'Sits deep beside the midline, running vertically \u2014 the main head extensor.', mnemonic: 'Runs semi-along the spine, hence the name.' },
          { name: 'Sternocleidomastoid', teach: 'Seen from behind it appears at the sides, passing forward to the sternum and clavicle.', mnemonic: 'Its three attachments are in the name: sternum, clavicle, mastoid.' },
          { name: 'Trapezius', teach: 'The large diamond spanning neck to mid-back \u2014 here you see its upper fibers.', mnemonic: 'Named for its trapezoid shape.' },
        ],
      },
      {
        id: 'back', title: 'Superficial Back & Posterior Shoulder', Diagram: BackSuperficialDiagram,
        regions: [
          { name: 'Trapezius', teach: 'The broad superficial muscle spanning the posterior neck and upper back. Its fibers elevate, retract and upwardly rotate the scapula.', mnemonic: 'Its paired outline forms a broad trapezoid over the upper back.' },
          { name: 'Deltoid', teach: 'The rounded shoulder cap. Its posterior fibers extend and externally rotate the arm while the middle fibers abduct it.' },
          { name: 'Infraspinatus', teach: 'A rotator-cuff muscle occupying the infraspinous fossa below the scapular spine; it externally rotates the humerus.' },
          { name: 'Teres major', teach: 'A thick muscle inferior to teres minor that adducts and internally rotates the humerus. It is not part of the rotator cuff.' },
          { name: 'Latissimus dorsi', teach: 'A broad superficial lower-back muscle that extends, adducts and internally rotates the humerus.', mnemonic: '"Latissimus" = widest, "dorsi" = of the back.' },
          { name: 'Thoracolumbar fascia', teach: 'The strong connective-tissue sheet over the lower back that provides attachment and force transmission for trunk muscles.' },
          { name: 'Triceps brachii', teach: 'The large posterior arm muscle responsible primarily for elbow extension.' },
        ],
      },

    ],
  },
  {
    id: 'nervous', title: 'Nervous System', icon: Brain,
    activities: [
      {
        id: 'cranial', title: 'Cranial Nerves', Diagram: CranialDiagram,
        regions: [
          { name: 'Olfactory tract', teach: 'Carries second-order olfactory axons posteriorly from the olfactory bulb. The olfactory nerve proper (CN I) consists of small fila that pass from the nasal mucosa through the cribriform plate to the bulb.' },
          { name: 'Optic nerve', teach: 'Cranial nerve II. Carries vision from the retina to the optic chiasm.' },
          { name: 'Optic chiasm', teach: 'The partial crossing of optic nerve fibers where axons from the nasal retina decussate. Compression here classically produces bitemporal hemianopia.' },
          { name: 'Oculomotor nerve', teach: 'Cranial nerve III. Emerges from the midbrain and moves four of the six eye muscles, plus the eyelid and pupil.' },
          { name: 'Trigeminal nerve', teach: 'Cranial nerve V. The largest, emerging from the side of the pons. Sensation to the face and the muscles of chewing.', mnemonic: 'Tri- = three divisions: ophthalmic, maxillary, mandibular.' },
          { name: 'Abducens nerve', teach: 'Cranial nerve VI. Emerges near the midline at the pontomedullary junction and abducts the eye.' },
        ],
      },
      {
        id: 'brain-mid', title: 'Brain, Midsagittal', Diagram: BrainMidDiagram,
        regions: [
          { name: 'Cerebral cortex', teach: 'The folded outer sheet of grey matter \u2014 where conscious thought, sensation and voluntary movement are processed. The folds pack far more surface area into the skull.' },
          { name: 'Corpus callosum', teach: 'The thick band of white matter arching over the ventricles, carrying signals between the left and right hemispheres.', mnemonic: 'Latin for \u201ctough body\u201d \u2014 the bridge between the halves.' },
          { name: 'Fornix', teach: 'A slimmer arched fibre tract just beneath the corpus callosum, running from the hippocampus to the hypothalamus \u2014 a memory pathway.', mnemonic: 'Fornix = \u201carch\u201d. Two arches stacked: corpus callosum on top, fornix below.' },
          { name: 'Lateral ventricle', teach: 'One of the fluid-filled cavities inside each hemisphere, sitting in the dark space between the corpus callosum and the thalamus.' },
          { name: 'Thalamus', teach: 'The large egg-shaped mass at the centre \u2014 nearly every sensory signal except smell relays here before reaching the cortex.', mnemonic: 'The switchboard. Everything routes through it on the way up.' },
          { name: 'Hypothalamus', teach: 'Sits below the thalamus and runs the body\u2019s housekeeping \u2014 temperature, hunger, thirst, sleep \u2014 and drives the pituitary.', mnemonic: '\u201cHypo\u201d = under. Under the thalamus, literally.' },
          { name: 'Pituitary gland', teach: 'An endocrine gland connected to the hypothalamus by the infundibulum. It regulates several endocrine axes, while its activity is itself controlled by hypothalamic signals.' },
          { name: 'Optic chiasm', teach: 'The X-shaped crossing point of the optic nerves, just anterior to the pituitary stalk.', mnemonic: 'Named for the Greek letter chi (X) \u2014 the shape of the crossing.' },
          { name: 'Pineal gland', teach: 'The small body behind the thalamus that secretes melatonin and sets the sleep\u2013wake rhythm.', mnemonic: 'Named for its pine-cone shape.' },
          { name: 'Midbrain', teach: 'The uppermost part of the brainstem, between the thalamus above and the pons below \u2014 handles visual and auditory reflexes.' },
          { name: 'Pons', teach: 'The bulging middle section of the brainstem, relaying between cerebrum and cerebellum and helping drive breathing.', mnemonic: 'Latin for \u201cbridge\u201d \u2014 and it looks like one.' },
          { name: 'Medulla oblongata', teach: 'The lowest brainstem segment, continuous with the spinal cord \u2014 controls heart rate, breathing and blood pressure.', mnemonic: 'Brainstem top to bottom: Midbrain, Pons, Medulla \u2014 \u201cMy Pretty Man\u201d.' },
          { name: 'Cerebellum', teach: 'The tightly folded mass at the back and below \u2014 coordinates balance, posture and smooth movement.', mnemonic: '\u201cLittle brain\u201d. It does not decide to move; it makes the movement neat.' },
          { name: 'Arbor vitae', teach: 'The branching white matter inside the cerebellum, named for its tree-like cut surface.', mnemonic: 'Latin for \u201ctree of life\u201d.' },
          { name: 'Fourth ventricle', teach: 'The fluid space between the brainstem in front and the cerebellum behind.' },
          { name: 'Spinal cord', teach: 'Continues down from the medulla, carrying signals between brain and body.' },
        ],
      },
      {
        id: 'cord-section', title: 'Spinal Cord, Cross Section', Diagram: CordSectionDiagram,
        regions: [
          { name: 'Grey matter', teach: 'The butterfly-shaped core of cell bodies and synapses.', mnemonic: 'In the cord, grey is inside and white is outside \u2014 the reverse of the brain.' },
          { name: 'White matter', teach: 'The pale outer region of myelinated axon tracts running up and down the cord.', mnemonic: 'White because myelin is fatty and pale.' },
          { name: 'Posterior (dorsal) horn', teach: 'The narrow, pointed rear projection of grey matter \u2014 receives incoming sensory signals.' },
          { name: 'Anterior (ventral) horn', teach: 'The broad, blunt front projection \u2014 holds the motor neuron cell bodies that drive skeletal muscle.', mnemonic: 'Posterior horns are pointy, anterior horns are fat.' },
          { name: 'Central canal', teach: 'The tiny opening at the very centre, filled with cerebrospinal fluid and continuous with the ventricles.' },
          { name: 'Posterior median sulcus', teach: 'The shallow groove marking the midline on the posterior surface.', mnemonic: 'Shallow sulcus at the back, deep fissure at the front.' },
          { name: 'Anterior median fissure', teach: 'The deep cleft marking the midline on the anterior surface.' },
          { name: 'Dorsal (posterior) root', teach: 'The bundle of rootlets entering the posterior horn \u2014 carries sensory fibres in.' },
          { name: 'Dorsal root ganglion', teach: 'The swelling on the dorsal root containing the cell bodies of the sensory neurons.', mnemonic: 'A ganglion is a cluster of cell bodies outside the central nervous system.' },
          { name: 'Ventral (anterior) root', teach: 'The rootlets leaving the anterior horn \u2014 carries motor fibres out.', mnemonic: 'SAME DAVE: Sensory Afferent, Motor Efferent \u2014 Dorsal Afferent, Ventral Efferent.' },
          { name: 'Spinal nerve', teach: 'Formed where the dorsal and ventral roots merge \u2014 mixed sensory and motor from this point on.' },
        ],
      },
    ],
  },
  {
    id: 'senses', title: 'Special Senses', icon: Eye,
    activities: [
      {
        id: 'eye-sagittal', title: 'Eye, Sagittal Section', Diagram: EyeDiagram,
        regions: [
          { name: 'Cornea', teach: 'The clear dome at the front. It is avascular and does most of the eye\u2019s light bending \u2014 more than the lens does.', mnemonic: 'The lens fine-tunes focus; the cornea does the heavy refraction.' },
          { name: 'Iris', teach: 'The pigmented muscular ring that changes the size of the pupil and gives the eye its colour.' },
          { name: 'Pupil', teach: 'Not a structure but the opening in the middle of the iris that light passes through.', mnemonic: 'A hole, not a thing \u2014 which is why it looks black.' },
          { name: 'Lens', teach: 'The transparent biconvex body behind the iris, changing shape to focus on near or far objects.' },
          { name: 'Ciliary body', teach: 'Contains the ciliary muscle and ciliary processes. Ciliary muscle contraction reduces zonular tension so the lens becomes more convex for near vision; the ciliary processes also produce aqueous humor.' },
          { name: 'Zonular fibers (suspensory ligament of lens)', teach: 'Fine fibers of the ciliary zonule extending from the ciliary body to the lens capsule; changes in their tension permit accommodation.', mnemonic: 'Also called zonular fibers or the ciliary zonule.' },
          { name: 'Sclera', teach: 'The tough white outer coat that keeps the eye\u2019s shape and gives muscles somewhere to attach.', mnemonic: 'Three coats, outside in: Sclera, Choroid, Retina \u2014 tough, vascular, nervous.' },
          { name: 'Choroid', teach: 'The dark vascular middle coat, feeding the outer retina and absorbing stray light so images stay sharp.' },
          { name: 'Retina', teach: 'The innermost nervous coat, holding the rods and cones that convert light into nerve signals.', mnemonic: 'Rods for dim light and movement; cones for colour and detail.' },
          { name: 'Fovea centralis', teach: 'The small central depression within the macula lutea, temporal to the optic disc. It has the highest cone density and provides the greatest visual acuity.' },
          { name: 'Optic disc', teach: 'Where the retinal vessels and nerve fibres leave the eye. It has no photoreceptors, so it is the blind spot.', mnemonic: 'Disc = blind spot. Fovea = sharpest spot.' },
          { name: 'Central retinal artery and vein', teach: 'The vessels running inside the optic nerve to supply and drain the inner retina.' },
          { name: 'Optic nerve', teach: 'Cranial nerve II, carrying visual signals from the retina back toward the brain.' },
        ],
      },
      {
        id: 'ear-section', title: 'Ear, Coronal Section', Diagram: EarDiagram,
        regions: [
          { name: 'Auricle (pinna)', teach: 'The visible flap of elastic cartilage and skin that collects sound and funnels it inward.' },
          { name: 'External acoustic meatus', teach: 'The canal running from the auricle to the eardrum. Its outer part is cartilage, its inner part bone.', mnemonic: 'Everything from here outward is the external ear.' },
          { name: 'Tympanic membrane', teach: 'The eardrum \u2014 the thin cone separating external from middle ear, vibrating when sound waves strike it.' },
          { name: 'Malleus', teach: 'The first and largest ossicle. Its handle is attached to the eardrum, so it moves whenever the drum does.', mnemonic: 'Malleus = hammer. It strikes the anvil.' },
          { name: 'Incus', teach: 'The middle ossicle, bridging malleus to stapes. Its long process reaches down toward the stapes.', mnemonic: 'Incus = anvil. Hammer, Anvil, Stirrup \u2014 in that order, outside in.' },
          { name: 'Stapes', teach: 'The stirrup-shaped third ossicle and the smallest bone in the body. Its footplate pushes on the oval window.' },
          { name: 'Semicircular canals', teach: 'Three fluid-filled loops set at right angles, detecting rotational movement of the head.', mnemonic: 'Three loops, three planes \u2014 balance, not hearing.' },
          { name: 'Vestibule', teach: 'The central chamber between the canals and the cochlea, sensing head position and linear acceleration.' },
          { name: 'Cochlea', teach: 'The bony spiral containing the organ of Corti, where fluid waves are converted into nerve signals.', mnemonic: 'Cochlea = snail shell. This is the hearing part; the canals and vestibule handle balance.' },
          { name: 'Vestibulocochlear nerve', teach: 'Cranial nerve VIII, carrying both hearing and balance information to the brain.', mnemonic: 'Its name gives away both jobs: vestibulo- for balance, cochlear for hearing.' },
          { name: 'Temporal bone', teach: 'The skull bone housing the middle and inner ear. Its air-filled spaces are the mastoid air cells.' },
        ],
      },
    ],
  },
  {
    id: 'cardio', title: 'Cardiovascular', icon: Heart,
    activities: [
      {
        id: 'heart-section', title: 'Heart, Coronal Section', Diagram: HeartSectionDiagram,
        regions: [
          { name: 'Right atrium', teach: 'Receives deoxygenated blood from the body through the venae cavae.' },
          { name: 'Right ventricle', teach: 'Pumps blood to the lungs. Its wall is thinner than the left because the pulmonary circuit is low-pressure.' },
          { name: 'Left atrium', teach: 'Receives oxygenated blood returning from the lungs through the pulmonary veins.' },
          { name: 'Left ventricle', teach: 'The thickest chamber, pumping blood to the whole body.', mnemonic: 'Thick wall, long journey.' },
          { name: 'Interventricular septum', teach: 'The partition between the right and left ventricles, composed mainly of a thick muscular part with a small membranous part superiorly.' },
          { name: 'Tricuspid valve', teach: 'The right atrioventricular valve, with three cusps.', mnemonic: 'Tri before you Bi \u2014 tricuspid on the right, bicuspid on the left.' },
          { name: 'Mitral valve', teach: 'The left atrioventricular valve, with two cusps. Also called the bicuspid valve.' },
          { name: 'Pulmonary semilunar valve', teach: 'Guards the outlet from the right ventricle into the pulmonary trunk, preventing backflow.' },
          { name: 'Aortic semilunar valve', teach: 'Guards the left ventricular outflow tract into the aorta and prevents blood from returning to the left ventricle during diastole.' },
          { name: 'Chordae tendineae', teach: 'Fibrous cords tethering the valve cusps, stopping them everting when the ventricle contracts.', mnemonic: 'The heartstrings.' },
          { name: 'Papillary muscle', teach: 'The muscular mounds anchoring the chordae tendineae to the ventricle wall.' },
          { name: 'Superior vena cava', teach: 'Returns deoxygenated blood from the head, neck and arms to the right atrium.' },
          { name: 'Inferior vena cava', teach: 'Returns deoxygenated blood from the trunk and legs to the right atrium.' },
          { name: 'Pulmonary trunk', teach: 'Carries deoxygenated blood from the right ventricle and divides into the right and left pulmonary arteries.' },
          { name: 'Pulmonary veins', teach: 'Return oxygenated blood from the lungs to the left atrium \u2014 veins carrying bright blood.' },
          { name: 'Aorta', teach: 'The great artery leaving the left ventricle to supply the entire body.' },
        ],
      },
      {
        id: 'heart-external', title: 'Heart, Anterior View', Diagram: HeartExtDiagram,
        regions: [
          { name: 'Superior vena cava', teach: 'Returns deoxygenated blood from the head, neck and arms into the right atrium.', mnemonic: 'Superior drains everything above the heart; inferior everything below.' },
          { name: 'Inferior vena cava', teach: 'Returns deoxygenated blood from the abdomen and legs into the right atrium.' },
          { name: 'Aortic arch', teach: 'The curve of the aorta above the heart, giving off the branches that supply the head and arms.' },
          { name: 'Ascending aorta', teach: 'The first stretch of the aorta, leaving the left ventricle and carrying oxygenated blood to the body.' },
          { name: 'Pulmonary trunk', teach: 'Leaves the right ventricle and divides into left and right pulmonary arteries.', mnemonic: 'The only arteries carrying deoxygenated blood \u2014 which is why they are drawn blue.' },
          { name: 'Right pulmonary artery', teach: 'Branches from the pulmonary trunk and carries deoxygenated blood to the right lung.' },
          { name: 'Pulmonary veins', teach: 'Return oxygenated blood from the lungs into the left atrium.', mnemonic: 'The only veins carrying oxygenated blood \u2014 drawn red.' },
          { name: 'Right auricle', teach: 'The ear-shaped flap on the right atrium that increases its capacity.', mnemonic: 'Auricle means \u201clittle ear\u201d.' },
          { name: 'Left auricle', teach: 'The matching flap on the left atrium.' },
          { name: 'Right ventricle', teach: 'Forms most of the front surface of the heart and pumps blood to the lungs.', mnemonic: 'Short trip to the lungs, so its wall is thin.' },
          { name: 'Left ventricle', teach: 'Pumps oxygenated blood into the aorta and around the whole body, so its wall is by far the thickest.' },
          { name: 'Anterior interventricular sulcus', teach: 'The groove on the front marking the septum between the ventricles, carrying the anterior interventricular artery in fat.' },
          { name: 'Right coronary artery', teach: 'Runs in the groove between right atrium and right ventricle, supplying the heart muscle itself.', mnemonic: 'The heart feeds itself first \u2014 the coronaries are the aorta\u2019s first branches.' },
          { name: 'Apex of the heart', teach: 'The blunt point at the bottom, formed by the left ventricle and directed down and to the left.' },
        ],
      },
    ],
  },
  {
    id: 'digestive', title: 'Digestive System', icon: Utensils,
    activities: [
      {
        id: 'digestive-tract', title: 'Digestive Tract', Diagram: DigestiveTractDiagram,
        regions: [
          { name: 'Parotid gland', teach: 'The largest salivary gland, sitting in front of and below the ear.' },
          { name: 'Esophagus', teach: 'The muscular tube carrying swallowed food from pharynx to stomach by peristalsis. No digestion happens here.' },
          { name: 'Liver', teach: 'The largest internal organ. It makes bile, processes absorbed nutrients and detoxifies the blood arriving from the gut.' },
          { name: 'Gallbladder', teach: 'The small green sac tucked under the liver that stores and concentrates bile, releasing it when fat arrives.', mnemonic: 'The liver makes bile; the gallbladder only stores it.' },
          { name: 'Stomach', teach: 'The muscular bag that churns food with acid and pepsin, turning it into chyme.' },
          { name: 'Duodenum', teach: 'The C-shaped first part of the small intestine, receiving chyme from the stomach plus bile and pancreatic juice.', mnemonic: 'Small intestine order: Duodenum, Jejunum, Ileum \u2014 \u201cDow Jones Industrial\u201d.' },
          { name: 'Pancreas', teach: 'Sits behind the stomach. Its exocrine part makes digestive enzymes; its islets make insulin and glucagon.', mnemonic: 'One organ, two jobs \u2014 exocrine into the duodenum, endocrine into the blood.' },
          { name: 'Small intestine', teach: 'The long coiled tube where most chemical digestion and nearly all nutrient absorption happen.' },
          { name: 'Cecum', teach: 'The blind pouch where the small intestine joins the large intestine.' },
          { name: 'Vermiform appendix', teach: 'The narrow, blind-ended tube arising from the cecum.' },
          { name: 'Ascending colon', teach: 'Runs up the right side of the abdomen from the cecum.', mnemonic: 'Colon path: up the right, across, down the left, then S-bend to rectum.' },
          { name: 'Transverse colon', teach: 'Crosses the abdomen from right to left beneath the stomach.' },
          { name: 'Descending colon', teach: 'Runs down the left side toward the pelvis.' },
          { name: 'Sigmoid colon', teach: 'The S-shaped final stretch of colon leading into the rectum.', mnemonic: 'Sigmoid = shaped like the Greek sigma.' },
          { name: 'Rectum', teach: 'The straight terminal section that stores faeces before defecation.' },
        ],
      },
      {
        id: 'stomach', title: 'Stomach', Diagram: StomachDiagram,
        regions: [
          { name: 'Esophagus', teach: 'Enters the stomach from above. Its lining is smooth, unlike the folded stomach mucosa below.' },
          { name: 'Cardia of stomach', teach: 'The short region immediately around the esophageal opening, named for its closeness to the heart.', mnemonic: 'Nothing to do with cardiac muscle \u2014 it just sits near the heart.' },
          { name: 'Fundus of stomach', teach: 'The dome bulging above the level of the esophageal opening. Swallowed air collects here.' },
          { name: 'Body of stomach', teach: 'The large central region where food is churned and mixed with gastric juice. Its mucosa is thrown into folds called rugae.', mnemonic: 'Rugae flatten out as the stomach fills, which is how it stretches.' },
          { name: 'Lesser curvature', teach: 'The shorter, concave right border running from the cardia to the pylorus.' },
          { name: 'Greater curvature', teach: 'The longer, convex left and lower border.', mnemonic: 'Greater is the long way round \u2014 it has more surface to cover.' },
          { name: 'Pyloric antrum', teach: 'The wider proximal portion of the pyloric part of the stomach, leading into the narrower pyloric canal and pylorus; antral contractions help grind gastric contents.' },
          { name: 'Pyloric sphincter', teach: 'The thick muscular ring controlling release of chyme into the duodenum, a little at a time.', mnemonic: 'Two gates: cardiac sphincter in at the top, pyloric sphincter out at the bottom.' },
          { name: 'Duodenum', teach: 'The first part of the small intestine, receiving chyme once the pyloric sphincter opens.' },
        ],
      },
    ],
  },
  {
    id: 'respiratory', title: 'Respiratory System', icon: Wind,
    activities: [
      {
        id: 'respiratory-tract', title: 'Upper Airway & Trachea', Diagram: RespiratoryTractDiagram,
        regions: [
          { name: 'Nasal cavity', teach: 'Warms, moistens and filters incoming air. Its conchae create turbulence so air contacts the respiratory mucosa.' },
          { name: 'Oral cavity', teach: 'An alternative route for airflow when nasal breathing is insufficient, but with less warming, humidification and filtration than the nasal route.' },
          { name: 'Pharynx', teach: 'The shared muscular passage behind the nose and mouth that conducts air toward the larynx and food toward the esophagus.' },
          { name: 'Epiglottis', teach: 'An elastic-cartilage flap that helps protect the laryngeal inlet during swallowing.', mnemonic: 'Think of it as part of the airway-protection mechanism, not a simple hinged lid.' },
          { name: 'Larynx', teach: 'The cartilaginous voice box between pharynx and trachea; it houses the vocal folds and protects the lower airway.' },
          { name: 'Trachea', teach: 'The windpipe, supported by C-shaped hyaline-cartilage rings that help keep the airway patent.' },
        ],
      },
      {
        id: 'lungs', title: 'Lungs and Bronchial Tree', Diagram: LungsDiagram,
        regions: [
          { name: 'Larynx', teach: 'The voice box, guarding the entrance to the trachea and housing the vocal folds.' },
          { name: 'Trachea', teach: 'Held open by C-shaped cartilage rings, incomplete behind so the oesophagus can expand.' },
          { name: 'Carina', teach: 'The ridge at the tracheal bifurcation. It is highly sensitive \u2014 touching it triggers the cough reflex.' },
          { name: 'Right main bronchus', teach: 'Wider, shorter and more vertical than the left, so inhaled objects usually end up here.', mnemonic: 'Things fall down the right.' },
          { name: 'Left main bronchus', teach: 'Narrower and more horizontal, passing beneath the aortic arch.' },
          { name: 'Bronchial tree', teach: 'The branching airways dividing about twenty-three times from main bronchus to alveolus.' },
          { name: 'Right superior lobe', teach: 'The uppermost lobe of the right lung, above the horizontal fissure.' },
          { name: 'Right middle lobe', teach: 'Lies between the horizontal and oblique fissures. Only the right lung has one.', mnemonic: 'Right lung three lobes, left lung two \u2014 the left gives up a lobe to make room for the heart.' },
          { name: 'Right inferior lobe', teach: 'The lowest and largest lobe, below the oblique fissure.' },
          { name: 'Diaphragm', teach: 'The dome-shaped muscle beneath the lungs. It flattens on contraction, drawing air in.' },
        ],
      },
      {
        id: 'alveoli', title: 'Alveoli and Gas Exchange', Diagram: AlveoliDiagram,
        regions: [
          { name: 'Bronchiole', teach: 'A small airway with no cartilage in its wall. Its smooth muscle can constrict or dilate to change airflow.', mnemonic: 'No cartilage is why bronchioles can close off in asthma.' },
          { name: 'Alveolar duct', teach: 'The final passage leading from the bronchiole into the alveolar sacs.' },
          { name: 'Alveolus', teach: 'A single thin-walled air pocket. Gas exchange happens across its wall, and there are millions of them.' },
          { name: 'Alveolar wall (interalveolar septum)', teach: 'The thin septum between adjacent alveoli. The air–blood barrier includes type I alveolar epithelium, fused or closely apposed basement membranes, and capillary endothelium.', mnemonic: 'Gas crosses an extremely thin epithelial–interstitial–endothelial barrier.' },
          { name: 'Alveolar sac', teach: 'A cluster of alveoli opening into a shared space, like a bunch of grapes.' },
          { name: 'Alveolar capillary network', teach: 'The dense mesh wrapped around each alveolus. Oxygen diffuses in and carbon dioxide diffuses out here.' },
          { name: 'Pulmonary arteriole', teach: 'Brings deoxygenated blood from the heart to the alveolar capillaries \u2014 drawn blue.', mnemonic: 'In the pulmonary circuit the arteries carry deoxygenated blood, the reverse of everywhere else.' },
          { name: 'Pulmonary venule', teach: 'Collects freshly oxygenated blood from the capillaries and carries it back toward the heart \u2014 drawn red.' },
        ],
      },
    ],
  },
  {
    id: 'endocrine', title: 'Endocrine System', icon: Sparkles,
    activities: [
      {
        id: 'endocrine-glands', title: 'Endocrine Glands', Diagram: EndocrineDiagram,
        regions: [
          { name: 'Pituitary gland', teach: 'Hangs from the hypothalamus on a stalk and directs several other endocrine glands.', mnemonic: 'Called the master gland \u2014 though the hypothalamus is really the one giving it orders.' },
          { name: 'Thyroid gland', teach: 'The butterfly-shaped gland across the front of the trachea. Its hormones set the body\u2019s metabolic rate.', mnemonic: 'Butterfly across the windpipe, two lobes joined by an isthmus.' },
          { name: 'Thymus', teach: 'Sits behind the sternum and matures T lymphocytes. It is large in childhood and shrinks after puberty.', mnemonic: 'T cells are named for the Thymus.' },
          { name: 'Adrenal gland', teach: 'The triangular cap on top of each kidney. Its cortex makes cortisol and aldosterone; its medulla makes adrenaline.', mnemonic: '\u201cAd-renal\u201d = on the kidney.' },
          { name: 'Pancreas', teach: 'Its islet cells release insulin and glucagon into the blood to control blood glucose.', mnemonic: 'Insulin lowers blood glucose, glucagon raises it.' },
          { name: 'Ovary', teach: 'Produces oestrogen and progesterone alongside releasing eggs, so it is both a gonad and an endocrine gland.' },
        ],
      },
    ],
  },
  {
    id: 'reproductive', title: 'Reproductive System', icon: Layers,
    activities: [
      {
        id: 'female-internal', title: 'Female Internal Organs', Diagram: FemaleReproDiagram,
        regions: [
          { name: 'Fundus of uterus', teach: 'The rounded upper part of the uterus, above the level where the tubes enter.' },
          { name: 'Uterine tube', teach: 'Transports the oocyte and, later, the early embryo toward the uterus. Fertilization most commonly occurs in the ampulla.', mnemonic: 'Also called the fallopian tube; its parts are infundibulum, ampulla, isthmus and uterine part.' },
          { name: 'Fimbriae', teach: 'The finger-like fringe at the open end of the tube that sweeps the released egg inward.', mnemonic: 'Fimbria is Latin for fringe.' },
          { name: 'Ovary', teach: 'Holds the follicles and releases an egg each cycle, while also producing oestrogen and progesterone.' },
          { name: 'Uterine cavity', teach: 'The narrow triangular space inside the uterus where an embryo implants.' },
          { name: 'Myometrium', teach: 'The thick smooth muscle wall of the uterus. It contracts during labour. Its inner lining, the endometrium, is the layer shed each period.', mnemonic: 'Myo- = muscle, endo- = inner lining.' },
          { name: 'Cervix', teach: 'The narrow neck of the uterus opening into the vagina.' },
          { name: 'Vagina', teach: 'The muscular canal running from the cervix to the exterior.' },
        ],
      },
      {
        id: 'male-internal', title: 'Male Internal Organs', Diagram: MaleReproDiagram,
        regions: [
          { name: 'Testis', teach: 'Produces sperm and testosterone. It sits outside the body cavity because sperm need a temperature slightly below core body temperature.' },
          { name: 'Epididymis', teach: 'The coiled tube capping the testis where sperm mature and are stored before ejaculation.', mnemonic: 'Epi- = upon, didymis = testis. It sits on top of the testis.' },
          { name: 'Ductus deferens', teach: 'The muscular tube carrying sperm from the epididymis up toward the urethra. Also called the vas deferens.', mnemonic: 'This is the tube cut in a vasectomy.' },
          { name: 'Seminal vesicle', teach: 'A lobulated sac behind the bladder contributing most of the fluid volume of semen, rich in fructose to fuel the sperm.' },
          { name: 'Prostate gland', teach: 'Sits below the bladder and surrounds the urethra, adding a milky alkaline fluid that neutralises vaginal acidity.', mnemonic: 'Because it wraps the urethra, prostate enlargement obstructs urine flow.' },
          { name: 'Urinary bladder', teach: 'Not a reproductive organ, but shown here because the urethra it drains is shared with the reproductive tract.' },
          { name: 'Urethra', teach: 'The shared channel carrying both urine and semen to the exterior \u2014 though never at the same time.' },
          { name: 'Corpus cavernosum', teach: 'One of the paired columns of erectile tissue that fill with blood during an erection.' },
        ],
      },
    ],
  },
  ];






// Anatomy is the first Aceapp module. For the website launch, keep the
// foundational flow deliberate and hide any plate marked qualityHold until
// its artwork is replaced/audited.
const CATEGORY_PRIORITY = ['terms', 'cellular', 'skeletal', 'integumentary', 'muscular', 'nervous', 'senses', 'cardio', 'respiratory', 'digestive', 'endocrine', 'reproductive'];
LABEL_CATEGORIES.sort((a, b) => {
  const ai = CATEGORY_PRIORITY.indexOf(a.id), bi = CATEGORY_PRIORITY.indexOf(b.id);
  return (ai < 0 ? 999 : ai) - (bi < 0 ? 999 : bi);
});

function activityAvailable(activity) { return !activity.qualityHold; }

const LEAD_ACTIVITY_ORDER = [
  'terms/anatomical-position',
  'terms/directional',
  'terms/planes',
  'cellular/cell',
  'terms/cavities',
  'terms/abdominopelvic',
  'terms/proximal-distal',
  'terms/superficial-deep',
  'terms/relationship-terms',
  'terms/body-positions',
  'terms/foot-surface-terms',
];

function curriculumActivities() {
  const flat = [];
  LABEL_CATEGORIES.forEach((cat, catIndex) => {
    cat.activities.filter(activityAvailable).forEach((activity, actIndex) => {
      flat.push({ catId: cat.id, catTitle: cat.title, activity, originalOrder: catIndex * 100 + actIndex });
    });
  });
  const leadRank = new Map(LEAD_ACTIVITY_ORDER.map((key, idx) => [key, idx]));
  return flat.sort((a, b) => {
    const ak = `${a.catId}/${a.activity.id}`, bk = `${b.catId}/${b.activity.id}`;
    const ar = leadRank.has(ak) ? leadRank.get(ak) : 1000 + a.originalOrder;
    const br = leadRank.has(bk) ? leadRank.get(bk) : 1000 + b.originalOrder;
    return ar - br;
  });
}

// Hooked (Nir Eyal): predictable rewards go invisible fast — an
// occasional small bonus keeps the payoff variable instead of flat.


// Donation checkout is intentionally hosted by the payment provider.
// Your backend endpoint should create a checkout session and return: { url: 'https://...' }.
// Keeping card collection out of this React app means sensitive card data never touches Aceapp.
const DONATION_CHECKOUT_ENDPOINT = '/api/create-donation-checkout';
const DONATION_CURRENCY = 'PHP';
const DONATION_PRESETS = [50, 100, 250, 500];
const PAYMENT_METHODS = [
  { id: 'google_pay', label: 'Google Pay', group: 'express' },
  { id: 'apple_pay', label: 'Apple Pay', group: 'express' },
  { id: 'card', label: 'Debit / credit card', group: 'card', detail: 'Visa · Mastercard · JCB' },
  { id: 'gcash', label: 'GCash', group: 'local' },
  { id: 'maya', label: 'Maya', group: 'local' },
  { id: 'paypal', label: 'PayPal', group: 'other' },
];

// Identification should measure anatomy knowledge, not punctuation or one
// textbook's preferred synonym. Keep aliases explicit so we do not become
// so fuzzy that a genuinely different structure is accidentally accepted.
const ANSWER_ALIASES = {
  'ductus deferens': ['vas deferens'],
  'uterine tube': ['fallopian tube', 'oviduct'],
  'auditory tube': ['eustachian tube', 'pharyngotympanic tube'],
  'patella': ['kneecap'],
  'clavicle': ['collarbone', 'collar bone'],
  'scapula': ['shoulder blade'],
  'sternum': ['breastbone', 'breast bone'],
  'coccyx': ['tailbone', 'tail bone'],
  'fovea centralis': ['fovea'],
  'epicranial aponeurosis galea aponeurotica': ['galea aponeurotica', 'galea', 'epicranial aponeurosis'],
  'condylar process of mandible': ['condylar process', 'condyloid process'],
  'plasma membrane cell membrane': ['cell membrane', 'plasma membrane'],
  'mitochondrion': ['mitochondria'],
  'aortic semilunar valve': ['aortic valve'],
  'hypodermis subcutaneous tissue': ['subcutaneous layer', 'hypodermis', 'subcutaneous tissue'],
  'vermiform appendix': ['appendix'],
  'pulmonary semilunar valve': ['pulmonary valve'],
  'incisive foramen': ['incisive fossa'],
  'mastoid process of temporal bone': ['mastoid process'],
  'styloid process of temporal bone': ['styloid process'],
  'sternal end of clavicle': ['sternal end'],
  'acromial end of clavicle': ['acromial end'],
  'lateral epicondyle of femur': ['lateral epicondyle'],
  'medial epicondyle of femur': ['medial epicondyle'],
  'lateral epicondyle of humerus': ['lateral epicondyle'],
  'medial epicondyle of humerus': ['medial epicondyle'],
  'lateral condyle of femur': ['lateral condyle'],
  'medial condyle of tibia': ['medial condyle'],
};

function normalizeAnswer(value) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/^the\s+/, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function isCorrectAnswer(answer, canonical) {
  const a = normalizeAnswer(answer);
  const c = normalizeAnswer(canonical);
  if (!a) return false;
  if (a === c) return true;
  return (ANSWER_ALIASES[c] || []).some((alias) => normalizeAnswer(alias) === a);
}

// ---------------------------------------------------------------------------
// Persistence. Wrapped so the app still runs where storage is unavailable.
// ---------------------------------------------------------------------------
const SAVE_KEY = 'aceapp.v4';

async function loadSave() {
  const blank = { xp: 0, streak: 0, lastDay: null, mastered: {}, misses: {}, seen: {}, reviews: {}, activityDays: [], confusions: {} };
  try {
    // Some prototype hosts expose window.storage. Prefer it when available,
    // but fall back to localStorage so progress survives in a normal browser.
    if (window.storage?.get) {
      const res = await window.storage.get(SAVE_KEY);
      return res ? { ...blank, ...JSON.parse(res.value) } : blank;
    }
    const raw = window.localStorage?.getItem(SAVE_KEY);
    return raw ? { ...blank, ...JSON.parse(raw) } : blank;
  } catch {
    return blank;
  }
}
async function putSave(next) {
  const raw = JSON.stringify(next);
  try {
    if (window.storage?.set) {
      await window.storage.set(SAVE_KEY, raw);
      return;
    }
    window.localStorage?.setItem(SAVE_KEY, raw);
  } catch {
    // Storage can be unavailable in private/embedded contexts. The session
    // still works; it simply cannot persist progress between reloads.
  }
}

function dayKey(date = new Date()) {
  // Local calendar date is what users expect a study streak to follow.
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function daysBetween(a, b) {
  if (!a || !b) return null;
  const [ay, am, ad] = a.split('-').map(Number);
  const [by, bm, bd] = b.split('-').map(Number);
  return Math.round((Date.UTC(by, bm - 1, bd) - Date.UTC(ay, am - 1, ad)) / 86400000);
}

function addDays(day, amount) {
  const [y, m, d] = day.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + amount));
  return dt.toISOString().slice(0, 10);
}

// Every labelled structure in the app, flattened. This is what Test mode draws from.
function allItems() {
  const out = [];
  for (const cat of LABEL_CATEGORIES) {
    for (const act of cat.activities.filter(activityAvailable)) {
      act.regions.forEach((r, i) => {
        out.push({ key: cat.id + '/' + act.id + '/' + r.name, catId: cat.id, catTitle: cat.title,
                   actId: act.id, actTitle: act.title, Diagram: act.Diagram, regions: act.regions,
                   idx: i, name: r.name, teach: r.teach, mnemonic: r.mnemonic });
      });
    }
  }
  return out;
}

function shuffle(a) {
  // Fisher-Yates gives an unbiased shuffle; Array.sort(Math.random) does not.
  const out = [...a];
  for (let i = out.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

// Distractors are drawn from the same plate first, so a wrong answer is a real
// confusion rather than an obvious mismatch from another body system.
function optionsFor(item) {
  const same = item.regions.filter((r) => r.name !== item.name).map((r) => r.name);
  return shuffle([...shuffle(same).slice(0, 3), item.name]);
}


const CONFIDENCE_LEVELS = [
  { min: 0, label: 'New', dots: 0 },
  { min: 1, label: 'Learning', dots: 1 },
  { min: 2, label: 'Familiar', dots: 2 },
  { min: 3, label: 'Strong', dots: 3 },
  { min: 4, label: 'Mastered', dots: 4 },
];

function confidenceFor(strength = 0) {
  return [...CONFIDENCE_LEVELS].reverse().find((x) => strength >= x.min) || CONFIDENCE_LEVELS[0];
}

function recognitionOptions(item, items) {
  const sameSystem = items
    .filter((x) => x.catId === item.catId && x.key !== item.key && x.actId !== item.actId && normalizeAnswer(x.name) !== normalizeAnswer(item.name))
    .map((x) => x.name);
  const backup = items.filter((x) => x.key !== item.key && normalizeAnswer(x.name) !== normalizeAnswer(item.name)).map((x) => x.name);
  const pool = sameSystem.length >= 3 ? sameSystem : backup;
  return shuffle([...shuffle([...new Set(pool)]).slice(0, 3), item.name]);
}

function confusionKey(a, b) {
  return [a, b].sort((x, y) => x.localeCompare(y)).join(' ↔ ');
}

function logEvent(name, payload = {}) {
  const event = { name, payload, at: new Date().toISOString() };
  try {
    const key = 'aceapp.analytics.v1';
    const prior = JSON.parse(window.localStorage?.getItem(key) || '[]');
    const next = [...prior.slice(-499), event];
    window.localStorage?.setItem(key, JSON.stringify(next));
  } catch {}
  try { window.gtag?.('event', name, payload); } catch {}
  try { window.plausible?.(name, { props: payload }); } catch {}
}


const ACE_THEME_CSS = `
.ace-shell{box-shadow:0 16px 50px rgba(15,23,42,.06)}
.ace-dark{background:#0b171d!important;border-color:#24343d!important;color:#e8eef1!important;box-shadow:0 18px 55px rgba(0,0,0,.28)}
.ace-dark .bg-white{background-color:#0d1b22!important}
.ace-dark .bg-gray-50{background-color:#101f26!important}
.ace-dark .bg-gray-100{background-color:#172830!important}
.ace-dark .bg-gray-200{background-color:#263841!important}
.ace-dark .border-gray-200{border-color:#263841!important}
.ace-dark .border-gray-300{border-color:#354a55!important}
.ace-dark .text-gray-900{color:#f5f8fa!important}
.ace-dark .text-gray-800{color:#dbe4e8!important}
.ace-dark .text-gray-700{color:#c5d0d5!important}
.ace-dark .text-gray-600{color:#a7b5bd!important}
.ace-dark .text-gray-500{color:#8c9ba4!important}
.ace-dark .text-gray-400{color:#71818a!important}
.ace-dark .bg-teal-50{background-color:#0e2a27!important}
.ace-dark .border-teal-100,.ace-dark .border-teal-200{border-color:#18564d!important}
.ace-dark .text-teal-900{color:#c9f7ee!important}
.ace-dark .text-teal-800{color:#9ee9da!important}
.ace-dark .text-teal-700{color:#6fd6c3!important}
.ace-dark .bg-amber-50{background-color:#302616!important}
.ace-dark .border-amber-100,.ace-dark .border-amber-200{border-color:#5c4823!important}
.ace-dark .text-amber-900,.ace-dark .text-amber-950{color:#ffe4a6!important}
.ace-dark .text-amber-800,.ace-dark .text-amber-700{color:#f4c96c!important}
.ace-dark .bg-rose-50,.ace-dark .bg-red-50{background-color:#321d23!important}
.ace-dark .border-rose-100,.ace-dark .border-rose-400,.ace-dark .border-red-100{border-color:#693341!important}
.ace-dark .text-rose-900,.ace-dark .text-red-700{color:#ffc1cd!important}
.ace-dark input,.ace-dark textarea{color:#f4f7f8!important}
.ace-dark input::placeholder,.ace-dark textarea::placeholder{color:#73848d!important}
.ace-dark .ace-hero{background:linear-gradient(145deg,#132b2a 0%,#111e28 100%)!important;border-color:#21433f!important}
.ace-dark .ace-soft-card{background:#101f26!important;border-color:#263841!important}
.ace-dark .ace-nav{background:#0b171d!important;border-color:#24343d!important}
.ace-dark .ace-pay-badge{background:#101f26!important;border-color:#314650!important;color:#dce6ea!important}
.ace-light .ace-hero{background:linear-gradient(145deg,#fffaf0 0%,#f0fdfa 100%)}
.ace-light .ace-soft-card{background:#fff;border-color:#e5e7eb}
.ace-light .ace-nav{background:#fff;border-color:#e5e7eb}
.ace-pay-badge{display:inline-flex;align-items:center;border:1px solid #e5e7eb;border-radius:999px;padding:6px 9px;font-size:11px;font-weight:600;color:#374151;background:#fff}
.ace-theme-button{width:36px;height:36px;border-radius:12px;display:flex;align-items:center;justify-content:center;border:1px solid #e5e7eb;background:#fff}
.ace-dark .ace-theme-button{background:#101f26;border-color:#2b3e48;color:#f4f8fa}
.ace-zoom-button{display:flex;align-items:center;justify-content:center;gap:6px;margin:8px auto 0;padding:6px 10px;border-radius:999px;font-size:11px;color:#64748b}
.ace-dark .ace-zoom-button{color:#93a4ad}
`;

export default function Aceapp() {
  const [screen, setScreen] = useState('home');
  const [loaded, setLoaded] = useState(false);
  const [xp, setXp] = useState(0);
  const [streak, setStreak] = useState(0);
  const [lastDay, setLastDay] = useState(null);
  const [mastered, setMastered] = useState({});   // key -> times correct in a row
  const [misses, setMisses] = useState({});       // key -> times wrong
  const [seen, setSeen] = useState({});           // key -> true
  const [reviews, setReviews] = useState({});     // key -> { due, interval, lastAnswered, lastResult }
  const [activityDays, setActivityDays] = useState([]);
  const [confusions, setConfusions] = useState({});
  const [rewardMessage, setRewardMessage] = useState('');
  const [shareStatus, setShareStatus] = useState('');
  const [installPrompt, setInstallPrompt] = useState(null);
  const [darkMode, setDarkMode] = useState(() => {
    try {
      const saved = window.localStorage?.getItem('aceapp.theme');
      if (saved) return saved === 'dark';
      return window.matchMedia?.('(prefers-color-scheme: dark)').matches || false;
    } catch { return false; }
  });
  const [zoomTarget, setZoomTarget] = useState(null);
  const [zoomLevel, setZoomLevel] = useState(1.65);

  // Learn mode
  const [catId, setCatId] = useState(null);
  const [actId, setActId] = useState(null);
  const [phase, setPhase] = useState('teach');
  const [teachIdx, setTeachIdx] = useState(0);
  const [queue, setQueue] = useState([]);
  const [qIdx, setQIdx] = useState(0);
  const [opts, setOpts] = useState([]);
  const [picked, setPicked] = useState(null);
  const [checked, setChecked] = useState(false);
  const [gotRight, setGotRight] = useState(0);
  const [faceView, setFaceView] = useState('anterior');

  // Test mode
  const [pickedCats, setPickedCats] = useState([]);
  const [qType, setQType] = useState('mixed');
  const [qCount, setQCount] = useState(15);
  const [test, setTest] = useState([]);
  const [tIdx, setTIdx] = useState(0);
  const [tOpts, setTOpts] = useState([]);
  const [tPicked, setTPicked] = useState(null);
  const [tChecked, setTChecked] = useState(false);
  const [tWrong, setTWrong] = useState([]);
  const [tRight, setTRight] = useState(0);
  const [typed, setTyped] = useState('');
  const [drillMode, setDrillMode] = useState(false);
  const [testMode, setTestMode] = useState('practice'); // practice | exam
  const [difficulty, setDifficulty] = useState('discrimination'); // recognition | discrimination | recall
  const [sessionAnswers, setSessionAnswers] = useState([]);

  // Donation portal
  const [donationAmount, setDonationAmount] = useState(100);
  const [customDonation, setCustomDonation] = useState('');
  const [donorNote, setDonorNote] = useState('');
  const [donationMethod, setDonationMethod] = useState('google_pay');
  const [donationLoading, setDonationLoading] = useState(false);
  const [donationError, setDonationError] = useState('');

  useEffect(() => {
    (async () => {
      const s = await loadSave();
      setXp(s.xp); setStreak(s.streak || 0); setLastDay(s.lastDay || null);
      setMastered(s.mastered || {}); setMisses(s.misses || {}); setSeen(s.seen || {}); setReviews(s.reviews || {});
      setActivityDays(s.activityDays || []); setConfusions(s.confusions || {});
      logEvent('landing_page_view', { returning: Boolean(Object.keys(s.seen || {}).length) });
      setLoaded(true);
    })();
  }, []);

  useEffect(() => {
    try { window.localStorage?.setItem('aceapp.theme', darkMode ? 'dark' : 'light'); } catch {}
    const bg = darkMode ? '#071219' : '#f4fbf9';
    document.documentElement.style.backgroundColor = bg;
    document.body.style.backgroundColor = bg;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', darkMode ? '#071219' : '#0F6E56');
  }, [darkMode]);

  useEffect(() => {
    const onInstall = (event) => { event.preventDefault(); setInstallPrompt(event); };
    window.addEventListener('beforeinstallprompt', onInstall);
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
    return () => window.removeEventListener('beforeinstallprompt', onInstall);
  }, []);

  useEffect(() => {
    if (!rewardMessage) return undefined;
    const timer = window.setTimeout(() => setRewardMessage(''), 4200);
    return () => window.clearTimeout(timer);
  }, [rewardMessage]);

  function persist(patch) {
    const next = { xp, streak, lastDay, mastered, misses, seen, reviews, activityDays, confusions, ...patch };
    putSave(next);
  }

  const cat = LABEL_CATEGORIES.find((c) => c.id === catId);
  const act = cat && cat.activities.find((a) => a.id === actId);
  const items = useMemo(() => allItems(), []);
  const curriculum = useMemo(() => curriculumActivities(), []);
  const curriculumIndex = curriculum.findIndex((entry) => entry.catId === catId && entry.activity.id === actId);
  const nextCurriculum = curriculumIndex >= 0 ? curriculum[curriculumIndex + 1] : null;
  const totalStructures = items.length;
  const validKeys = useMemo(() => new Set(items.map((i) => i.key)), [items]);
  const demonstratedCount = Object.keys(mastered).filter((k) => validKeys.has(k) && mastered[k] >= 1).length;
  const knownCount = Object.keys(mastered).filter((k) => validKeys.has(k) && mastered[k] >= 4).length;
  const masteryPct = Math.round((items.reduce((sum, i) => sum + Math.min(4, mastered[i.key] || 0), 0) / Math.max(1, totalStructures * 4)) * 100);
  const activeDays7 = activityDays.filter((d) => { const gap = daysBetween(d, dayKey()); return gap !== null && gap >= 0 && gap <= 6; }).length;

  // --- record an answer -----------------------------------------------------
  function record(key, right, selectedName = null) {
    const m = { ...mastered }, w = { ...misses }, s = { ...seen, [key]: true };
    const previousStrength = m[key] || 0;
    const hadMisses = (w[key] || 0) > 0;
    if (right) {
      m[key] = Math.min(6, previousStrength + 1);
      if (hadMisses) w[key] = Math.max(0, w[key] - 1);
    } else {
      // Forgetting should reduce confidence, not erase all evidence of learning.
      m[key] = Math.max(0, previousStrength - 1);
      w[key] = (w[key] || 0) + 1;
    }

    const today = dayKey();
    const gap = daysBetween(lastDay, today);
    let nextStreak = streak;
    if (lastDay !== today) {
      nextStreak = gap === 1 ? streak + 1 : 1;
      setStreak(nextStreak);
      setLastDay(today);
    }
    const nextActivityDays = [...new Set([...activityDays, today])].slice(-45);
    setActivityDays(nextActivityDays);

    const rv = { ...reviews };
    const priorReview = rv[key] || {};
    if (right) {
      const strength = m[key] || 1;
      const intervals = [1, 1, 3, 7, 14, 30, 45];
      const interval = intervals[Math.min(strength, intervals.length - 1)];
      rv[key] = { due: addDays(today, interval), interval, lastAnswered: today, lastResult: 'right' };
      if (priorReview.lastAnswered && daysBetween(priorReview.lastAnswered, today) >= 1) {
        logEvent('delayed_recall_success', { key, gapDays: daysBetween(priorReview.lastAnswered, today), strength });
      }
    } else {
      rv[key] = { due: today, interval: 0, lastAnswered: today, lastResult: 'wrong' };
    }

    let nextConfusions = confusions;
    if (!right && selectedName) {
      const current = items.find((i) => i.key === key);
      if (current && normalizeAnswer(selectedName) !== normalizeAnswer(current.name)) {
        const pair = confusionKey(current.name, selectedName);
        nextConfusions = { ...confusions, [pair]: (confusions[pair] || 0) + 1 };
        setConfusions(nextConfusions);
      }
    }

    setMastered(m); setMisses(w); setSeen(s); setReviews(rv);
    const gained = right ? (hadMisses ? 12 : 10) : 2;
    const nx = xp + gained;
    setXp(nx);

    const becameMastered = previousStrength < 4 && m[key] >= 4;
    if (becameMastered) setRewardMessage(`New strength discovered: ${items.find((i) => i.key === key)?.name || 'structure'} mastered.`);
    else if (right && hadMisses) setRewardMessage('Comeback: you recovered a structure that had been giving you trouble.');
    else if (right && Math.random() < 0.10) setRewardMessage('Recall strengthened. That answer will now return after a longer interval.');

    logEvent('question_answered', { key, right, strength: m[key], mode: testMode });
    if (!right) logEvent('wrong_answer', { key, selected: selectedName || 'typed' });
    persist({ xp: nx, streak: nextStreak, lastDay: today, mastered: m, misses: w, seen: s, reviews: rv, activityDays: nextActivityDays, confusions: nextConfusions });
  }

  // --- Learn ---------------------------------------------------------------
  function openActivityByRef(entry) {
    if (!entry) return;
    setCatId(entry.catId);
    setActId(entry.activity.id);
    setPhase('teach'); setTeachIdx(0); setQueue([]); setQIdx(0); setPicked(null); setChecked(false); setGotRight(0);
    logEvent('study_started', { source: 'learn_continue', activity: entry.activity.id, category: entry.catId });
    setScreen('learn');
  }
  function openActivity(a) { logEvent('study_started', { source: 'learn', activity: a.id }); setActId(a.id); setPhase('teach'); setTeachIdx(0); }
  function nextTeach() {
    if (teachIdx < act.regions.length - 1) setTeachIdx(teachIdx + 1);
    else startLearnQuiz();
  }
  function startLearnQuiz() {
    const order = shuffle([...Array(act.regions.length).keys()]);
    setQueue(order); setQIdx(0);
    setOpts(labelOptionsFor(act.regions, order[0]));
    setPicked(null); setChecked(false); setGotRight(0); setPhase('quiz');
  }
  function checkLearn() {
    if (!picked) return;
    setChecked(true);
    const r = act.regions[queue[qIdx]];
    const right = picked === r.name;
    if (right) setGotRight((c) => c + 1);
    record(cat.id + '/' + act.id + '/' + r.name, right, right ? null : picked);
  }
  function nextLearn() {
    if (qIdx < queue.length - 1) {
      const n = qIdx + 1; setQIdx(n);
      setOpts(labelOptionsFor(act.regions, queue[n]));
      setPicked(null); setChecked(false);
    } else setPhase('done');
  }

  // --- Test ----------------------------------------------------------------
  function toggleCat(id) {
    setPickedCats((p) => p.includes(id) ? p.filter((x) => x !== id) : [...p, id]);
  }
  function buildTest(fromMisses) {
    let pool = items;
    if (fromMisses) {
      pool = items.filter((i) => (misses[i.key] || 0) > 0)
                  .sort((a, b) => (misses[b.key] || 0) - (misses[a.key] || 0));
      if (!pool.length) return;
    } else {
      if (pickedCats.length) pool = pool.filter((i) => pickedCats.includes(i.catId));
      // weight toward things missed before, so a test is never purely random revision
      const weak = pool.filter((i) => (misses[i.key] || 0) > 0);
      pool = shuffle([...weak, ...shuffle(pool)]);
    }
    const uniq = []; const used = new Set();
    for (const i of pool) { if (!used.has(i.key)) { used.add(i.key); uniq.push(i); } }
    const chosen = uniq.slice(0, Math.min(qCount, uniq.length));
    if (!chosen.length) return;
    setTest(chosen); setTIdx(0); setTWrong([]); setTRight(0); setSessionAnswers([]);
    setTOpts(difficulty === 'recognition' ? recognitionOptions(chosen[0], items) : optionsFor(chosen[0])); setTPicked(null); setTChecked(false); setTyped('');
    setDrillMode(!!fromMisses);
    logEvent('study_started', { source: fromMisses ? 'miss_drill' : 'custom_test', count: chosen.length, testMode, difficulty });
    setScreen('test-run');
  }
  function buildTodaySession() {
    const today = dayKey();
    const due = items
      .filter((i) => reviews[i.key]?.due && reviews[i.key].due <= today)
      .sort((a, b) => (misses[b.key] || 0) - (misses[a.key] || 0));
    const weak = items
      .filter((i) => (misses[i.key] || 0) > 0 && !due.some((d) => d.key === i.key))
      .sort((a, b) => (misses[b.key] || 0) - (misses[a.key] || 0));
    const unseen = shuffle(items.filter((i) => !seen[i.key]));
    const developing = shuffle(items.filter((i) => seen[i.key] && (mastered[i.key] || 0) < 2));
    const combined = [...due, ...weak, ...developing, ...unseen];
    const chosen = [];
    const used = new Set();
    for (const item of combined) {
      if (!used.has(item.key)) { used.add(item.key); chosen.push(item); }
      if (chosen.length >= 10) break;
    }
    if (!chosen.length) return;
    setQType('mixed');
    setTest(chosen); setTIdx(0); setTWrong([]); setTRight(0); setSessionAnswers([]);
    setDifficulty('discrimination'); setTestMode('practice');
    setTOpts(optionsFor(chosen[0])); setTPicked(null); setTChecked(false); setTyped('');
    setDrillMode(false); logEvent('todays_10_started', { due: due.length, weak: weak.length }); setScreen('test-run');
  }

  function buildConfusionDrill(pair) {
    const [a, b] = pair.split(' ↔ ');
    const anchors = items.filter((i) => i.name === a || i.name === b);
    if (!anchors.length) return;
    const activityIds = new Set(anchors.map((i) => `${i.catId}/${i.actId}`));
    const context = items.filter((i) => activityIds.has(`${i.catId}/${i.actId}`) && i.name !== a && i.name !== b);
    const chosen = [...anchors, ...shuffle(context)].slice(0, 8);
    setTest(chosen); setTIdx(0); setTWrong([]); setTRight(0); setSessionAnswers([]);
    setTestMode('practice'); setDifficulty('discrimination'); setQType('mc');
    setTOpts(optionsFor(chosen[0])); setTPicked(null); setTChecked(false); setTyped('');
    setDrillMode(true); logEvent('study_started', { source: 'confusion_pair', pair, count: chosen.length }); setScreen('test-run');
  }

  const todayDueCount = items.filter((i) => reviews[i.key]?.due && reviews[i.key].due <= dayKey()).length;

  const cur = test[tIdx];
  const curType = !cur ? 'mc'
    : difficulty === 'recall' ? 'id'
    : qType === 'mixed' ? (tIdx % 3 === 2 ? 'id' : 'mc')
    : qType === 'identification' ? 'id' : 'mc';

  function answerNameForCurrent(answer) {
    if (curType !== 'id') return answer;
    const typedNorm = normalizeAnswer(answer);
    const match = cur.regions.find((r) => isCorrectAnswer(answer, r.name) || normalizeAnswer(r.name) === typedNorm);
    return match?.name || answer;
  }

  function advanceTest() {
    if (tIdx < test.length - 1) {
      const n = tIdx + 1;
      setTIdx(n);
      setTOpts(difficulty === 'recognition' ? recognitionOptions(test[n], items) : optionsFor(test[n]));
      setTPicked(null); setTChecked(false); setTyped('');
    } else {
      logEvent('study_completed', { count: test.length, right: tRight, mode: testMode });
      if (test.length === 10 && !drillMode) logEvent('todays_10_completed', { right: tRight });
      setScreen('test-results');
    }
  }

  function checkTest() {
    if (tChecked) return;
    const answer = curType === 'id' ? typed.trim() : tPicked;
    if (!answer) return;
    const right = isCorrectAnswer(answer, cur.name);
    const selectedName = right ? null : answerNameForCurrent(answer);
    const nextRight = tRight + (right ? 1 : 0);
    if (right) setTRight(nextRight); else setTWrong((w) => [...w, cur]);
    setSessionAnswers((a) => [...a, { key: cur.key, name: cur.name, right, selected: selectedName, catId: cur.catId }]);
    record(cur.key, right, selectedName);

    if (testMode === 'exam') {
      if (tIdx < test.length - 1) {
        const n = tIdx + 1;
        setTIdx(n);
        setTOpts(difficulty === 'recognition' ? recognitionOptions(test[n], items) : optionsFor(test[n]));
        setTPicked(null); setTChecked(false); setTyped('');
      } else {
        logEvent('study_completed', { count: test.length, right: nextRight, mode: testMode });
        setScreen('test-results');
      }
      return;
    }
    setTChecked(true);
  }
  function nextTest() { advanceTest(); }


  const missCount = Object.keys(misses).filter((k) => misses[k] > 0).length;
  const systemStats = LABEL_CATEGORIES.map((c) => {
    const catItems = items.filter((i) => i.catId === c.id);
    const score = catItems.reduce((sum, i) => sum + Math.min(4, mastered[i.key] || 0), 0);
    const pct = Math.round((score / Math.max(1, catItems.length * 4)) * 100);
    const weak = catItems.filter((i) => (misses[i.key] || 0) > 0).length;
    return { id: c.id, title: c.title.split('—')[0].trim(), pct, weak, total: catItems.length };
  });
  const weakestSystem = [...systemStats].sort((a, b) => a.pct - b.pct)[0];
  const topConfusions = Object.entries(confusions).sort((a, b) => b[1] - a[1]).slice(0, 5);

  async function shareText(text) {
    setShareStatus('');
    try {
      if (navigator.share) await navigator.share({ title: 'Aceapp', text });
      else { await navigator.clipboard.writeText(text); setShareStatus('Copied to clipboard'); }
      logEvent('share_result', { surface: navigator.share ? 'native' : 'clipboard' });
    } catch {}
  }

  async function installAceapp() {
    if (!installPrompt) return;
    installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    logEvent('pwa_install_prompt', { outcome: choice?.outcome || 'unknown' });
    setInstallPrompt(null);
  }

  if (!loaded) return <div className="flex items-center justify-center h-96 text-gray-400 text-sm">Loading…</div>;

  async function openDonationCheckout() {
    const amount = customDonation.trim() ? Number(customDonation) : donationAmount;

    if (!Number.isFinite(amount) || amount < 1) {
      setDonationError('Enter a donation amount of at least ₱1.');
      return;
    }

    setDonationLoading(true);
    setDonationError('');
    logEvent('checkout_started', { amount, currency: DONATION_CURRENCY, method: 'hosted_checkout' });
    try {
      const res = await fetch(DONATION_CHECKOUT_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount,
          currency: DONATION_CURRENCY,
          preferredMethod: 'auto',
          note: donorNote.trim().slice(0, 180),
          source: 'aceapp',
        }),
      });

      if (!res.ok) throw new Error('Checkout could not be created.');
      const data = await res.json();
      if (!data?.url) throw new Error('Checkout URL missing from server response.');

      window.location.assign(data.url);
    } catch (err) {
      setDonationError(
        'Secure checkout is not connected yet. Add the /api/create-donation-checkout backend endpoint before launch.'
      );
    } finally {
      setDonationLoading(false);
    }
  }

  const navVisible = ['home', 'dashboard', 'test-config'].includes(screen) || (screen === 'learn' && !act);

  const ThemeToggle = () => (
    <button type="button" className="ace-theme-button" onClick={() => setDarkMode((v) => !v)}
      aria-label={darkMode ? 'Use light mode' : 'Use dark mode'} title={darkMode ? 'Light mode' : 'Dark mode'}>
      {darkMode ? <Sun size={17} /> : <Moon size={17} />}
    </button>
  );

  const BottomNav = () => (
    <div className="ace-nav border border-gray-200" style={{ borderLeft: 0, borderRight: 0, borderBottom: 0, padding: '10px 12px 11px' }}>
      <div className="grid grid-cols-4 gap-2">
        {[
          { id: 'home', label: 'Home', Icon: Home, action: () => setScreen('home') },
          { id: 'practice', label: 'Practice', Icon: Target, action: buildTodaySession },
          { id: 'review', label: 'Review', Icon: RefreshCw, action: () => missCount ? buildTest(true) : setScreen('dashboard') },
          { id: 'progress', label: 'Progress', Icon: Sparkles, action: () => setScreen('dashboard') },
        ].map(({ id, label, Icon, action }) => {
          const active = (id === 'home' && screen === 'home') || (id === 'progress' && screen === 'dashboard');
          return (
            <button key={id} type="button" onClick={action} className="text-center" style={{ padding: '5px 2px' }}>
              <Icon size={18} className={active ? 'text-teal-700 mx-auto' : 'text-gray-400 mx-auto'} />
              <span className={active ? 'text-teal-700' : 'text-gray-500'} style={{ display: 'block', fontSize: 10, marginTop: 3, fontWeight: active ? 600 : 500 }}>{label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );

  const DiagramCard = ({ D, activeName, hideName = false, learnLabel = '', caption = '' }) => (
    <div className="rounded-2xl bg-gray-50 p-2 mb-4" style={{ position: 'relative' }}>
      {learnLabel && !hideName && (
        <span style={{
          position: 'absolute', top: 10, right: 10, zIndex: 3, padding: '5px 9px', borderRadius: 999,
          background: darkMode ? 'rgba(8,22,28,.92)' : 'rgba(255,255,255,.94)',
          border: darkMode ? '1px solid #29434d' : '1px solid #d1d5db',
          color: darkMode ? '#d9f7ef' : '#0F6E56', fontSize: 11, fontWeight: 700
        }}>{learnLabel}</span>
      )}
      <div className="flex justify-center">
        <D activeName={activeName} hideName={hideName} view={faceView} onView={setFaceView} />
      </div>
      <button type="button" className="ace-zoom-button"
        onClick={() => { setZoomLevel(1.65); setZoomTarget({ D, activeName, hideName, learnLabel, caption }); }}
        aria-label="Open larger anatomy image">
        <Eye size={13} /> Tap to inspect
      </button>
    </div>
  );

  const ZoomModal = () => {
    if (!zoomTarget) return null;
    const ZD = zoomTarget.D;
    return (
      <div role="dialog" aria-modal="true" aria-label="Anatomy image inspection"
        style={{ position: 'fixed', inset: 0, zIndex: 200, background: darkMode ? 'rgba(2,8,12,.97)' : 'rgba(248,250,252,.98)', overflow: 'auto' }}>
        <div style={{ position: 'sticky', top: 0, zIndex: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 14px',
          background: darkMode ? 'rgba(7,18,25,.95)' : 'rgba(255,255,255,.95)', borderBottom: darkMode ? '1px solid #24343d' : '1px solid #e5e7eb' }}>
          <div>
            <p className="text-sm font-semibold text-gray-900">{zoomTarget.learnLabel || zoomTarget.caption || 'Inspect anatomy'}</p>
            <p className="text-xs text-gray-500">Use + / −, then scroll around the enlarged plate.</p>
          </div>
          <div className="flex items-center gap-2">
            <button type="button" onClick={() => setZoomLevel((z) => Math.max(1, +(z - .35).toFixed(2)))} className="rounded-xl border border-gray-300 text-gray-700" style={{ width: 36, height: 36 }}>−</button>
            <span className="text-xs text-gray-500" style={{ width: 34, textAlign: 'center' }}>{zoomLevel.toFixed(1)}×</span>
            <button type="button" onClick={() => setZoomLevel((z) => Math.min(2.7, +(z + .35).toFixed(2)))} className="rounded-xl border border-gray-300 text-gray-700" style={{ width: 36, height: 36 }}>+</button>
            <button type="button" onClick={() => setZoomTarget(null)} className="rounded-xl bg-gray-900 text-white" style={{ width: 38, height: 36, marginLeft: 4 }} aria-label="Close zoom"><X size={17} style={{ margin: '0 auto' }} /></button>
          </div>
        </div>
        <div style={{ minWidth: Math.max(360, 340 * zoomLevel), minHeight: Math.max(620, 460 * zoomLevel), padding: '28px 20px 100px', overflow: 'visible' }}>
          <div style={{ width: 320, margin: '0 auto', transform: `scale(${zoomLevel})`, transformOrigin: 'top center' }}>
            <ZD activeName={zoomTarget.activeName} hideName={zoomTarget.hideName} view={faceView} onView={setFaceView} />
          </div>
        </div>
      </div>
    );
  };

  const Shell = ({ children }) => (
    <div className={`ace-shell ${darkMode ? 'ace-dark' : 'ace-light'} max-w-sm mx-auto bg-white rounded-3xl border border-gray-200 overflow-hidden font-sans min-h-[560px] relative`}>
      <style>{ACE_THEME_CSS}</style>
      {rewardMessage && (
        <div className="absolute z-50 left-3 right-3 top-3 rounded-2xl bg-gray-900 text-white px-4 py-3 shadow-lg text-sm">
          {rewardMessage}
        </div>
      )}
      {children}
      {navVisible && <BottomNav />}
      <ZoomModal />
    </div>
  );

  // ---------------------------------------------------------------- HOME ----
  if (screen === 'home') {
    const hour = new Date().getHours();
    const hello = hour < 12 ? 'Good morning!' : hour < 18 ? 'Good afternoon!' : 'Good evening!';
    return (
      <Shell>
        <div className="px-5 pt-5 pb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-xl font-semibold text-teal-700">Aceapp</p>
              <p className="text-xs text-gray-500">Ace your test ASAP.</p>
            </div>
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <div className="rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center" style={{ width: 36, height: 36 }}>
                <User size={17} className="text-teal-700" />
              </div>
            </div>
          </div>

          <h1 className="text-xl font-semibold text-gray-900">{hello}</h1>
          <p className="text-sm text-gray-500 mt-1 mb-4">Small sessions. Stronger recall.</p>

          <div className="rounded-2xl border border-gray-200 p-4 mb-4 ace-soft-card">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">Today&apos;s goal</p>
                <p className="text-sm font-semibold text-gray-900 mt-1">10 focused anatomy questions</p>
              </div>
              <span className="text-sm font-semibold text-teal-700">{masteryPct}%</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden mt-3">
              <div className="h-full bg-teal-600 rounded-full" style={{ width: `${Math.max(6, masteryPct)}%` }} />
            </div>
            <button onClick={buildTodaySession} className="w-full py-3 rounded-2xl bg-teal-600 text-white font-medium mt-3 active:bg-teal-700">
              Continue practice →
            </button>
            <p className="text-xs text-gray-500 mt-2">{todayDueCount > 0 ? `${todayDueCount} review item${todayDueCount === 1 ? '' : 's'} due now` : 'Aceapp will mix weak, due and new structures for you.'}</p>
          </div>

          <div className="ace-hero rounded-3xl border border-teal-100 p-4 mb-5">
            <div className="flex items-center gap-3">
              <div className="rounded-2xl bg-white border border-gray-200" style={{ width: 92, height: 112, overflow: 'hidden', flexShrink: 0 }}>
                <img src={PLATE_BASE + 'torso-anterior.jpg'} alt="Anterior muscular anatomy" style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'top' }} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-gray-900">Anatomy &amp; Physiology</p>
                <p className="text-sm text-gray-600 mt-2" style={{ lineHeight: 1.5 }}>Learn it.<br />Identify it.<br />Recall it.</p>
                <button onClick={() => { setScreen('learn'); setCatId(null); setActId(null); }}
                  className="rounded-xl bg-teal-600 text-white font-medium mt-3" style={{ padding: '9px 12px', fontSize: 12 }}>
                  Start practicing →
                </button>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-semibold text-gray-900">More subjects</p>
            <span className="text-xs text-gray-400">Coming soon</span>
          </div>
          <div className="grid grid-cols-3 gap-2 mb-5">
            {[
              { label: 'Biochemistry', Icon: FlaskConical },
              { label: 'Clinical Laboratory', Icon: Microscope },
              { label: 'Microbiology', Icon: Atom },
            ].map(({ label, Icon }) => (
              <div key={label} className="rounded-2xl border border-gray-200 text-center ace-soft-card" style={{ padding: '12px 6px', minHeight: 94 }}>
                <div className="rounded-xl bg-teal-50 flex items-center justify-center mx-auto" style={{ width: 34, height: 34 }}>
                  <Icon size={17} className="text-teal-700" />
                </div>
                <p className="text-xs font-medium text-gray-700 mt-2" style={{ lineHeight: 1.25 }}>{label}</p>
              </div>
            ))}
          </div>

          {missCount > 0 && (
            <button onClick={() => buildTest(true)}
              className="w-full text-left rounded-2xl bg-amber-50 border border-amber-200 p-3 mb-4">
              <div className="flex items-center gap-2 font-semibold text-amber-900"><RefreshCw size={16} />Quick recovery drill</div>
              <p className="text-xs text-amber-800 mt-1">{missCount} weak structure{missCount === 1 ? '' : 's'} ready for another try.</p>
            </button>
          )}

          <div className="rounded-2xl bg-gray-50 p-4">
            <p className="text-sm text-gray-700" style={{ lineHeight: 1.55 }}>“Replace passive scrolling with active recall.”</p>
            <p className="text-xs text-gray-500 mt-2">Aceapp is starting with Anatomy &amp; Physiology and will expand one medical subject at a time.</p>
            <div className="flex items-center justify-between mt-3">
              <button onClick={() => { logEvent('dashboard_opened'); setScreen('dashboard'); }} className="text-xs text-teal-700 font-medium">View my progress</button>
              <button onClick={() => setScreen('donate')} className="text-xs text-gray-500 underline underline-offset-2">Support Aceapp</button>
            </div>
          </div>
        </div>
      </Shell>
    );
  }

  // ------------------------------------------------------------ DASHBOARD ---
  if (screen === 'dashboard') {
    const confidenceCounts = CONFIDENCE_LEVELS.map((level, idx) => {
      const nextMin = CONFIDENCE_LEVELS[idx + 1]?.min ?? Infinity;
      const count = items.filter((i) => {
        const v = mastered[i.key] || 0;
        return v >= level.min && v < nextMin;
      }).length;
      return { ...level, count };
    });
    return (
      <Shell>
        <div className="px-5 py-5">
          <button onClick={() => setScreen('home')} className="text-sm text-gray-500 mb-4">← Back</button>
          <h2 className="text-xl font-semibold text-gray-900">Your anatomy profile</h2>
          <p className="text-sm text-gray-500 mt-1 mb-5">Capability first: what you can recall, what is developing, and what needs attention next.</p>

          <div className="rounded-2xl bg-teal-50 border border-teal-100 p-4 mb-5">
            <div className="flex items-end justify-between"><span className="text-sm text-teal-800">Overall mastery</span><span className="text-3xl font-semibold text-teal-900">{masteryPct}%</span></div>
            <p className="text-xs text-teal-800 mt-2">{demonstratedCount} structures demonstrated · {knownCount} mastered · {todayDueCount} due now</p>
          </div>

          <p className="text-sm font-semibold text-gray-900 mb-2">Confidence</p>
          <div className="grid grid-cols-2 gap-2 mb-5">
            {confidenceCounts.filter((x) => x.label !== 'New').map((x) => (
              <div key={x.label} className="rounded-xl border border-gray-200 p-3"><p className="text-xs text-gray-500">{x.label}</p><p className="text-lg font-semibold text-gray-900">{x.count}</p></div>
            ))}
          </div>

          <p className="text-sm font-semibold text-gray-900 mb-2">By system</p>
          <div className="space-y-3 mb-5">
            {systemStats.map((x) => (
              <div key={x.id}>
                <div className="flex justify-between text-xs mb-1"><span className="text-gray-700">{x.title}</span><span className="font-medium text-gray-900">{x.pct}%</span></div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden"><div className="h-full bg-teal-600" style={{ width: `${x.pct}%` }} /></div>
                {x.weak > 0 && <p className="text-[11px] text-amber-700 mt-1">{x.weak} currently weak</p>}
              </div>
            ))}
          </div>

          {topConfusions.length > 0 && (
            <>
              <p className="text-sm font-semibold text-gray-900 mb-2">You tend to mix these up</p>
              <div className="space-y-2 mb-5">
                {topConfusions.map(([pair, count]) => (
                  <button key={pair} onClick={() => buildConfusionDrill(pair)} className="w-full text-left rounded-xl bg-amber-50 border border-amber-100 px-3 py-2 active:bg-amber-100">
                    <div className="flex items-center justify-between gap-2"><p className="text-sm text-amber-950">{pair}</p><span className="text-[11px] font-medium text-amber-800">Drill</span></div>
                    <p className="text-[11px] text-amber-700">Confused {count} time{count === 1 ? '' : 's'} · tap for a focused comparison</p>
                  </button>
                ))}
              </div>
            </>
          )}

          {weakestSystem && <button onClick={() => { setPickedCats([weakestSystem.id]); setQCount(10); setDifficulty('discrimination'); setTestMode('practice'); setScreen('test-config'); }} className="w-full py-3 rounded-2xl bg-teal-600 text-white font-medium mb-3">Train {weakestSystem.title} next</button>}
          <button onClick={() => shareText(`My Aceapp anatomy mastery: ${masteryPct}% — ${knownCount} structures mastered. I’m building real recall, one review at a time.`)} className="w-full py-3 rounded-2xl border border-gray-300 text-gray-700 font-medium">Share my progress</button>
          {shareStatus && <p className="text-xs text-center text-gray-500 mt-2">{shareStatus}</p>}
        </div>
      </Shell>
    );
  }

  // --------------------------------------------------------------- DONATE ---
  if (screen === 'donate') {
    const selectedAmount = customDonation.trim() ? Number(customDonation) : donationAmount;
    return (
      <Shell>
        <div className="px-5 py-5">
          <div className="flex items-center justify-between mb-4">
            <button onClick={() => setScreen('home')} className="text-sm text-gray-500">← Back</button>
            <ThemeToggle />
          </div>

          <div className="rounded-3xl border border-gray-200 p-5 mb-4 ace-soft-card text-center">
            <div className="rounded-2xl bg-rose-50 border border-rose-100 flex items-center justify-center mx-auto mb-3" style={{ width: 48, height: 48 }}>
              <Heart size={23} className="text-rose-500" fill="currentColor" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900">Support Aceapp ❤️</h2>
            <p className="text-sm text-gray-600 mt-2 leading-6">
              Help keep Aceapp free and support my sister&apos;s tuition while I continue building new medical learning modules.
            </p>
            <p className="text-xs text-gray-400 mt-2">No pressure — sharing Aceapp helps too.</p>
          </div>

          <div className="rounded-3xl border border-gray-200 bg-white p-5 shadow-sm">
            <p className="text-sm font-medium text-gray-900 mb-3">Choose an amount</p>
            <div className="grid grid-cols-4 gap-2 mb-3">
              {DONATION_PRESETS.map((amount) => {
                const active = !customDonation && donationAmount === amount;
                return (
                  <button key={amount}
                    onClick={() => { setDonationAmount(amount); setCustomDonation(''); setDonationError(''); }}
                    className={`rounded-xl border py-3 text-sm font-semibold ${active ? 'border-teal-600 bg-teal-600 text-white' : 'border-gray-200 text-gray-700 bg-white'}`}>
                    ₱{amount}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center rounded-xl border border-gray-200 px-3 mb-4">
              <span className="text-sm font-medium text-gray-500 mr-2">₱</span>
              <input
                inputMode="decimal"
                value={customDonation}
                onChange={(e) => { setCustomDonation(e.target.value.replace(/[^0-9.]/g, '')); setDonationError(''); }}
                placeholder="Custom amount"
                className="w-full py-3 text-sm outline-none bg-transparent"
                aria-label="Custom support amount"
              />
            </div>

            <div className="flex flex-wrap gap-2 mb-4" aria-label="Accepted payment methods">
              {['Google Pay', 'Apple Pay', 'GCash', 'Maya', 'Visa', 'Mastercard'].map((m) => <span key={m} className="ace-pay-badge">{m}</span>)}
            </div>

            {donationError && (
              <div className="rounded-xl bg-red-50 border border-red-100 px-3 py-2.5 text-xs text-red-700 mb-3">
                {donationError}
              </div>
            )}

            <button
              onClick={openDonationCheckout}
              disabled={donationLoading || !Number.isFinite(selectedAmount) || selectedAmount < 1}
              className="w-full rounded-2xl bg-teal-600 text-white py-3 px-4 font-semibold flex items-center justify-center gap-2 disabled:opacity-40">
              {donationLoading ? <LoaderCircle size={18} className="animate-spin" /> : <ShieldCheck size={18} />}
              {donationLoading ? 'Opening secure checkout…' : `Continue to secure payment · ₱${Number.isFinite(selectedAmount) ? selectedAmount : 0}`}
            </button>

            <div className="flex items-start gap-2 mt-4 text-xs text-gray-500 leading-5">
              <ShieldCheck size={16} className="mt-0.5 shrink-0 text-emerald-600" />
              <span>The hosted checkout shows only payment methods available on the donor&apos;s device and account. Aceapp does not store card or wallet credentials.</span>
            </div>
          </div>

          <p className="text-center text-[11px] text-gray-400 mt-4 leading-4">
            Personal support, not a charitable or tax-deductible donation.
          </p>
        </div>
      </Shell>
    );
  }

  if (screen === 'test-config') return (
    <Shell>
      <div className="px-5 py-5">
        <button onClick={() => setScreen('home')} className="text-sm text-gray-500 mb-4">← Back</button>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Build your test</h2>

        <p className="text-sm font-medium text-gray-700 mb-2">Session</p>
        <div className="grid grid-cols-2 gap-2 mb-5">
          {[['practice', 'Practice', 'Immediate feedback'], ['exam', 'Exam', 'Results at the end']].map(([v, l, d]) => (
            <button key={v} onClick={() => setTestMode(v)} className={'rounded-xl border p-3 text-left ' + (testMode === v ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-gray-700 border-gray-300')}>
              <p className="text-sm font-medium">{l}</p><p className={'text-[11px] mt-1 ' + (testMode === v ? 'text-teal-50' : 'text-gray-400')}>{d}</p>
            </button>
          ))}
        </div>

        <p className="text-sm font-medium text-gray-700 mb-2">Difficulty</p>
        <div className="space-y-2 mb-5">
          {[['recognition', 'Recognition', 'Broader choices — easiest'], ['discrimination', 'Discrimination', 'Similar structures from the same plate'], ['recall', 'Recall', 'Type the structure with no choices']].map(([v, l, d]) => (
            <button key={v} onClick={() => setDifficulty(v)} className={'w-full rounded-xl border px-3 py-2 text-left ' + (difficulty === v ? 'bg-teal-50 border-teal-400' : 'bg-white border-gray-200')}>
              <p className="text-sm font-medium text-gray-900">{l}</p><p className="text-[11px] text-gray-500">{d}</p>
            </button>
          ))}
        </div>

        <p className="text-sm font-medium text-gray-700 mb-2">Systems</p>
        <div className="flex flex-wrap gap-2 mb-2">
          {LABEL_CATEGORIES.map((c) => (
            <button key={c.id} onClick={() => toggleCat(c.id)}
              className={'px-3 py-1.5 rounded-full text-sm border ' +
                (pickedCats.includes(c.id) ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-gray-700 border-gray-300')}>
              {c.title.split('—')[0].trim()}
            </button>
          ))}
        </div>
        <button onClick={() => setPickedCats([])} className="text-xs text-gray-500 underline mb-5">
          {pickedCats.length ? 'Clear — use everything' : 'All systems included'}
        </button>

        {difficulty !== 'recall' && <><p className="text-sm font-medium text-gray-700 mb-2 mt-2">Question type</p>
        <div className="flex gap-2 mb-5">
          {[['mc', 'Multiple choice'], ['identification', 'Identification'], ['mixed', 'Mixed']].map(([v, l]) => (
            <button key={v} onClick={() => setQType(v)}
              className={'flex-1 px-2 py-2 rounded-xl text-sm border ' +
                (qType === v ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-gray-700 border-gray-300')}>{l}</button>
          ))}
        </div></>}

        <p className="text-sm font-medium text-gray-700 mb-2">Length</p>
        <div className="flex gap-2 mb-6">
          {[10, 15, 25, 50].map((n) => (
            <button key={n} onClick={() => setQCount(n)}
              className={'flex-1 py-2 rounded-xl text-sm border ' +
                (qCount === n ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-gray-700 border-gray-300')}>{n}</button>
          ))}
        </div>

        <button onClick={() => buildTest(false)}
          className="w-full py-3 rounded-2xl bg-teal-600 text-white font-medium active:bg-teal-700">
          Start {testMode === 'exam' ? 'exam' : 'practice'}
        </button>
        <p className="text-xs text-gray-400 mt-3">
          Aceapp uses previous misses and spaced retrieval dates to personalize review. Your practice history changes what is worth testing next.
        </p>
      </div>
    </Shell>
  );

  // ------------------------------------------------------------- TEST RUN ---
  if (screen === 'test-run' && cur) {
    const D = cur.Diagram;
    const right = tChecked && (curType === 'id'
      ? isCorrectAnswer(typed, cur.name)
      : tPicked === cur.name);
    const selectedRegion = tChecked && !right && tPicked ? cur.regions.find((r) => r.name === tPicked) : null;
    return (
      <Shell>
        <div className="px-5 pt-5 pb-2 flex items-center justify-between">
          <button onClick={() => setScreen('home')} className="text-sm text-gray-500">Exit</button>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">{tIdx + 1} / {test.length}</span>
            <ThemeToggle />
          </div>
        </div>
        <div className="h-1 bg-gray-100 mx-5 rounded-full overflow-hidden mb-3">
          <div className="h-full bg-teal-600" style={{ width: (((tIdx + 1) / test.length) * 100) + '%' }} />
        </div>
        <div className="px-5 pb-5">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs text-gray-400">{cur.actTitle}</p>
            <span className="text-[11px] text-gray-400">{difficulty === 'recall' ? 'Recall' : difficulty === 'recognition' ? 'Recognition' : 'Discrimination'}</span>
          </div>

          <DiagramCard D={D} activeName={cur.name} hideName caption={cur.actTitle} />

          <p className="text-sm font-semibold text-gray-900 mb-3">{act.quizPrompt || "What structure is highlighted?"}</p>

          {curType === 'id' ? (
            <input value={typed} onChange={(e) => setTyped(e.target.value)} disabled={tChecked}
              placeholder="Type the structure…"
              className={'w-full px-4 py-3 rounded-xl border text-sm mb-3 bg-white ' +
                (tChecked ? (right ? 'border-teal-500 bg-teal-50' : 'border-rose-400 bg-rose-50') : 'border-gray-300')} />
          ) : (
            <div className="space-y-2 mb-3">
              {tOpts.map((o) => {
                let cls = 'border-gray-200 bg-white';
                if (tChecked && o === cur.name) cls = 'border-teal-500 bg-teal-50';
                else if (tChecked && o === tPicked) cls = 'border-rose-400 bg-rose-50';
                else if (!tChecked && o === tPicked) cls = 'border-teal-400 bg-teal-50';
                const selected = o === tPicked;
                return (
                  <button key={o} disabled={tChecked} onClick={() => setTPicked(o)}
                    className={'w-full text-left px-4 py-3 rounded-xl border text-sm flex items-center gap-2 ' + cls}>
                    <span style={{
                      width: 17, height: 17, borderRadius: 999, flexShrink: 0,
                      border: selected ? '2px solid #0F6E56' : '1.5px solid #cbd5e1',
                      background: selected && !tChecked ? '#dff8f2' : 'transparent',
                      display: 'inline-flex', alignItems: 'center', justifyContent: 'center'
                    }}>
                      {selected && <span style={{ width: 7, height: 7, borderRadius: 999, background: '#0F6E56' }} />}
                    </span>
                    <span>{o}</span>
                  </button>
                );
              })}
            </div>
          )}

          {tChecked && right && (
            <div className="rounded-2xl bg-teal-50 border border-teal-100 p-4 mb-3">
              <div className="flex items-start gap-2">
                <div className="rounded-full bg-teal-600 text-white flex items-center justify-center shrink-0" style={{ width: 28, height: 28 }}><Check size={17} /></div>
                <div>
                  <p className="text-sm font-semibold text-teal-900">Correct!</p>
                  <p className="text-sm font-semibold text-teal-900 mt-1">{cur.name}</p>
                  <p className="text-xs text-teal-800 mt-1 leading-5">{cur.teach}</p>
                  {cur.mnemonic && <p className="text-xs text-teal-800 mt-2"><span className="font-semibold">Tip:</span> {cur.mnemonic}</p>}
                </div>
              </div>
            </div>
          )}

          {tChecked && !right && (
            <div className="rounded-2xl bg-rose-50 border border-rose-100 p-4 mb-3">
              <div className="flex items-start gap-2">
                <div className="rounded-full text-white flex items-center justify-center shrink-0" style={{ width: 28, height: 28, background: '#e11d48' }}><X size={17} /></div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-rose-900">Not quite.</p>
                  {selectedRegion && <p className="text-xs text-rose-900 mt-1">You chose: <span className="font-semibold">{selectedRegion.name}</span></p>}
                  {curType === 'id' && typed.trim() && <p className="text-xs text-rose-900 mt-1">You entered: <span className="font-semibold">{typed.trim()}</span></p>}
                  <p className="text-xs text-rose-900 mt-1">Correct answer: <span className="font-semibold">{cur.name}</span></p>
                  <div className="rounded-xl bg-white p-3 mt-3">
                    <p className="text-xs text-gray-700 leading-5">{cur.teach}</p>
                    {selectedRegion && <p className="text-xs text-gray-500 mt-2">Compare it with <span className="font-semibold">{selectedRegion.name}</span>: {selectedRegion.teach}</p>}
                    {cur.mnemonic && <p className="text-xs text-gray-500 mt-2"><span className="font-semibold">Tip:</span> {cur.mnemonic}</p>}
                  </div>
                </div>
              </div>
            </div>
          )}

          <button onClick={tChecked ? nextTest : checkTest}
            disabled={!tChecked && !(curType === 'id' ? typed.trim() : tPicked)}
            className="w-full py-3 rounded-2xl bg-teal-600 text-white font-medium disabled:bg-gray-200 disabled:text-gray-400">
            {testMode === 'exam' ? (tIdx === test.length - 1 ? 'Submit exam' : 'Submit & next') : (tChecked ? (tIdx === test.length - 1 ? 'See results' : 'Next question') : 'Check answer')}
          </button>
        </div>
      </Shell>
    );
  }

  // --------------------------------------------------------- TEST RESULTS ---
  if (screen === 'test-results') {
    const pct = Math.round((tRight / Math.max(1, test.length)) * 100);
    const systemsTested = new Set(test.map((i) => i.catId)).size;
    const capabilityMessage = pct >= 90
      ? 'You can recognize this set reliably under recall.'
      : pct >= 70
        ? 'Your recognition is solid; a short weak-item drill should tighten the gaps.'
        : 'You found the exact structures worth practicing next — useful diagnostic data, not a dead end.';
    const nextFocus = tWrong[0];
    const resultBySystem = systemStats.map((sys) => {
      const answers = sessionAnswers.filter((a) => a.catId === sys.id);
      if (!answers.length) return null;
      return { ...sys, score: Math.round((answers.filter((a) => a.right).length / answers.length) * 100) };
    }).filter(Boolean).sort((a, b) => b.score - a.score);
    const strongest = resultBySystem[0];
    const weakest = resultBySystem[resultBySystem.length - 1];
    const milestoneSupport = pct >= 80 || knownCount >= 25;

    const repeatCurrentTest = () => {
      const retry = shuffle(test);
      setTest(retry); setTIdx(0); setTWrong([]); setTRight(0); setSessionAnswers([]);
      setTOpts(difficulty === 'recognition' ? recognitionOptions(retry[0], items) : optionsFor(retry[0]));
      setTPicked(null); setTChecked(false); setTyped(''); setScreen('test-run');
    };

    return (
      <Shell>
        <div className="px-5 py-6 text-center">
          <div className="rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center mx-auto mb-3" style={{ width: 62, height: 62 }}>
            <Sparkles size={30} className="text-amber-600" />
          </div>
          <p className="text-sm text-gray-500">{drillMode ? 'Drill complete' : 'Set complete'}</p>
          <h2 className="text-2xl font-semibold text-gray-900 mt-1">{tRight} / {test.length}</h2>
          <p className="text-sm text-gray-500 mt-1">{pct}% correct · {systemsTested} system{systemsTested === 1 ? '' : 's'} tested</p>

          <div className="h-2 bg-gray-100 rounded-full overflow-hidden mt-4 mb-5">
            <div className="h-full bg-teal-600 rounded-full" style={{ width: `${pct}%` }} />
          </div>

          <div className="rounded-2xl bg-teal-50 border border-teal-100 p-4 mb-4 text-left">
            <p className="text-xs font-semibold uppercase tracking-wide text-teal-700">What this means</p>
            <p className="text-sm text-teal-900 mt-1">{capabilityMessage}</p>
            {nextFocus && <p className="text-xs text-teal-800 mt-2">Next edge: <span className="font-semibold">{nextFocus.name}</span> on {nextFocus.actTitle}.</p>}
          </div>

          {strongest && (
            <div className="grid grid-cols-2 gap-2 mb-4 text-left">
              <div className="rounded-xl border border-gray-200 p-3"><p className="text-[11px] text-gray-500">Strongest</p><p className="text-sm font-semibold text-gray-900 mt-1">{strongest.title}</p><p className="text-xs text-teal-700">{strongest.score}%</p></div>
              <div className="rounded-xl border border-gray-200 p-3"><p className="text-[11px] text-gray-500">Next edge</p><p className="text-sm font-semibold text-gray-900 mt-1">{weakest?.title}</p><p className="text-xs text-amber-700">{weakest?.score}%</p></div>
            </div>
          )}

          {tWrong.length > 0 && (
            <button onClick={() => {
              const retry = shuffle(tWrong);
              setTest(retry); setTIdx(0); setTWrong([]); setTRight(0); setSessionAnswers([]);
              setTestMode('practice'); setDifficulty('discrimination'); setTOpts(optionsFor(retry[0])); setTPicked(null); setTChecked(false);
              setTyped(''); setDrillMode(true); setScreen('test-run');
            }} className="w-full py-3 rounded-2xl bg-teal-600 text-white font-medium mb-2">
              Review {tWrong.length} missed structure{tWrong.length === 1 ? '' : 's'}
            </button>
          )}

          <button onClick={repeatCurrentTest} className="w-full py-3 rounded-2xl border border-gray-300 text-gray-700 font-medium mb-2">
            Repeat this set
          </button>

          <button onClick={() => shareText(`I scored ${pct}% in Aceapp anatomy (${tRight}/${test.length}). Overall mastery: ${masteryPct}%.`)}
            className="w-full py-3 rounded-2xl border border-gray-300 text-gray-700 font-medium mb-2">Share result</button>
          {shareStatus && <p className="text-xs text-gray-500 mb-2">{shareStatus}</p>}

          {milestoneSupport && (
            <div className="rounded-2xl bg-gray-50 p-4 mb-3 text-left">
              <p className="text-sm font-semibold text-gray-900">You&apos;re building real recall.</p>
              <p className="text-xs text-gray-500 leading-5 mt-1">Aceapp is free. Optional support helps with my sister&apos;s tuition while I continue building the project.</p>
              <button onClick={() => { logEvent('donation_opened', { source: 'milestone' }); setScreen('donate'); }} className="text-sm font-medium text-teal-700 mt-2">Support Aceapp ❤️</button>
            </div>
          )}

          <button onClick={() => setScreen('home')} className="w-full py-3 text-sm text-gray-500">Home</button>
        </div>
      </Shell>
    );
  }

  // ----------------------------------------------------------------- LEARN --
  if (screen === 'learn' && !catId) return (
    <Shell>
      <div className="px-5 py-5">
        <button onClick={() => setScreen('home')} className="text-sm text-gray-500 mb-4">← Back</button>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Choose a system</h2>
        <div className="space-y-2">
          {LABEL_CATEGORIES.map((c) => {
            const visible = c.activities.filter(activityAvailable);
            const total = visible.reduce((s, a) => s + a.regions.length, 0);
            const known = visible.reduce((s, a) => s + a.regions.filter(
              (r) => (mastered[c.id + '/' + a.id + '/' + r.name] || 0) >= 2).length, 0);
            const Icon = c.icon;
            return (
              <button key={c.id} onClick={() => setCatId(c.id)}
                className="w-full text-left rounded-2xl border border-gray-200 p-4 active:bg-gray-50">
                <div className="flex items-center gap-2">
                  {Icon && <Icon size={18} className="text-teal-700" />}
                  <span className="font-medium text-gray-900">{c.title}</span>
                </div>
                <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden mt-2">
                  <div className="h-full bg-teal-600" style={{ width: (known / total) * 100 + '%' }} />
                </div>
                <p className="text-xs text-gray-500 mt-1">{known} of {total} learned</p>
              </button>
            );
          })}
        </div>
      </div>
    </Shell>
  );

  if (screen === 'learn' && cat && !act) return (
    <Shell>
      <div className="px-5 py-5">
        <button onClick={() => setCatId(null)} className="text-sm text-gray-500 mb-4">← Systems</button>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">{cat.title}</h2>
        <div className="space-y-2">
          {cat.activities.filter(activityAvailable).map((a) => {
            const known = a.regions.filter((r) => (mastered[cat.id + '/' + a.id + '/' + r.name] || 0) >= 2).length;
            return (
              <button key={a.id} onClick={() => openActivity(a)}
                className="w-full text-left rounded-2xl border border-gray-200 p-4 active:bg-gray-50">
                <span className="font-medium text-gray-900">{a.title}</span>
                <p className="text-xs text-gray-500 mt-1">{known} of {a.regions.length} learned</p>
              </button>
            );
          })}
        </div>
      </div>
    </Shell>
  );

  if (screen === 'learn' && act && phase === 'teach') {
    const r = act.regions[teachIdx];
    const D = act.Diagram;
    const TeachD = r.TeachDiagram || act.TeachDiagram || D;
    return (
      <Shell>
        <div className="px-5 pt-5 pb-2 flex items-center justify-between">
          <button onClick={() => setActId(null)} className="text-sm text-gray-500">Exit</button>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">{teachIdx + 1} / {act.regions.length}</span>
            <ThemeToggle />
          </div>
        </div>
        <div className="px-5 pb-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] uppercase tracking-wide text-teal-700 font-semibold">Learn mode</span>
            <span className="text-[11px] text-gray-400">{act.title}</span>
          </div>

          <DiagramCard D={TeachD} activeName={r.name} learnLabel={r.name} caption={act.title} />

          <h3 className="text-lg font-semibold text-gray-900 mb-1">{r.name}</h3>
          <p className="text-sm text-gray-600 mb-2 leading-6">{r.teach}</p>
          {r.mnemonic && (
            <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 text-sm text-amber-900 mb-3">
              <span className="font-medium">Memory hook: </span>{r.mnemonic}
            </div>
          )}
          <button onClick={nextTeach} className="w-full py-3 rounded-2xl bg-teal-600 text-white font-medium">
            {teachIdx === act.regions.length - 1 ? 'Quiz me' : 'Next structure'}
          </button>
        </div>
      </Shell>
    );
  }

  if (screen === 'learn' && act && phase === 'quiz') {
    const r = act.regions[queue[qIdx]];
    const D = act.Diagram;
    const right = checked && picked === r.name;
    return (
      <Shell>
        <div className="px-5 pt-5 pb-2 flex items-center justify-between">
          <button onClick={() => setActId(null)} className="text-sm text-gray-500">Exit</button>
          <span className="text-sm text-gray-500">{qIdx + 1} / {queue.length}</span>
        </div>
        <div className="h-1 bg-gray-100 mx-5 rounded-full overflow-hidden mb-3">
          <div className="h-full bg-teal-600" style={{ width: (((qIdx + 1) / queue.length) * 100) + '%' }} />
        </div>
        <div className="px-5 pb-5">
          <DiagramCard D={D} activeName={r.name} hideName caption={act.title} />
          <p className="text-sm font-semibold text-gray-900 mb-3">What structure is highlighted?</p>
          <div className="space-y-2 mb-3">
            {opts.map((o) => {
              let cls = 'border-gray-200 bg-white';
              if (checked && o === r.name) cls = 'border-teal-500 bg-teal-50';
              else if (checked && o === picked) cls = 'border-rose-400 bg-rose-50';
              else if (!checked && o === picked) cls = 'border-teal-400 bg-teal-50';
              return (
                <button key={o} disabled={checked} onClick={() => setPicked(o)}
                  className={'w-full text-left px-4 py-3 rounded-xl border text-sm ' + cls}>{o}</button>
              );
            })}
          </div>
          {checked && right && (
            <div className="rounded-2xl bg-teal-50 border border-teal-100 p-4 mb-3">
              <p className="text-sm font-semibold text-teal-900">Correct!</p>
              <p className="text-sm font-semibold text-teal-900 mt-1">{r.name}</p>
              <p className="text-xs text-teal-800 mt-1 leading-5">{r.teach}</p>
            </div>
          )}
          {checked && !right && (
            <div className="rounded-2xl bg-rose-50 border border-rose-100 p-4 mb-3">
              <p className="text-sm font-semibold text-rose-900">Not quite.</p>
              <p className="text-xs text-rose-900 mt-1">Correct answer: <span className="font-semibold">{r.name}</span></p>
              <p className="text-xs text-rose-900 mt-2 leading-5">{r.teach}</p>
              {r.mnemonic && <p className="text-xs text-rose-900 mt-2"><span className="font-semibold">Tip:</span> {r.mnemonic}</p>}
            </div>
          )}
          <button onClick={checked ? nextLearn : checkLearn} disabled={!checked && !picked}
            className="w-full py-3 rounded-2xl bg-teal-600 text-white font-medium disabled:bg-gray-200 disabled:text-gray-400">
            {checked ? (qIdx === queue.length - 1 ? 'See result' : 'Next question') : 'Check answer'}
          </button>
        </div>
      </Shell>
    );
  }

  if (screen === 'learn' && act && phase === 'done') return (
    <Shell>
      <div className="px-5 py-6 text-center">
        <div className="rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center mx-auto mb-3" style={{ width: 62, height: 62 }}>
          <Sparkles size={30} className="text-amber-600" />
        </div>
        <p className="text-sm text-gray-500">{act.title}</p>
        <h2 className="text-2xl font-semibold text-gray-900 mt-1">Set complete!</h2>
        <p className="text-sm text-gray-600 mt-2">
          You identified <span className="font-semibold">{gotRight} of {queue.length}</span> structures correctly.
        </p>
        <div className="h-2 bg-gray-100 rounded-full overflow-hidden mt-4 mb-5">
          <div className="h-full bg-teal-600 rounded-full" style={{ width: `${Math.round((gotRight / Math.max(1, queue.length)) * 100)}%` }} />
        </div>
        <p className="text-sm text-gray-600 mb-5">
          You can now pick out {gotRight} structure{gotRight === 1 ? '' : 's'} on this plate without help.
        </p>

        {nextCurriculum && (
          <button onClick={() => openActivityByRef(nextCurriculum)} className="w-full py-3 rounded-2xl bg-teal-600 text-white font-medium mb-2">
            Continue to next set: {nextCurriculum.activity.title}
          </button>
        )}
        <button onClick={() => { setPhase('teach'); setTeachIdx(0); setQueue([]); setQIdx(0); setGotRight(0); }}
          className="w-full py-3 rounded-2xl border border-gray-300 text-gray-700 font-medium mb-2">
          Repeat this set
        </button>
        <button onClick={() => { setActId(null); }} className="w-full py-3 rounded-2xl border border-gray-300 text-gray-700 font-medium mb-2">
          Back to {cat.title}
        </button>
        <button onClick={() => { setScreen('home'); setCatId(null); setActId(null); }} className="w-full py-3 text-sm text-gray-500">
          Home
        </button>
      </div>
    </Shell>
  );

  return (
    <Shell>
      <div className="px-5 py-6">
        <p className="text-sm text-gray-500 mb-3">Nothing to show.</p>
        <button onClick={() => setScreen('home')} className="w-full py-3 rounded-2xl bg-teal-600 text-white font-medium">Home</button>
      </div>
    </Shell>
  );
}
