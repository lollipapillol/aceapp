# Aceapp v7 — Product review and remaining priorities

## Implemented in v7

- Friendly & Illustrative home direction (mockup C)
- Dark mode with persisted preference
- Question screen redesign (mockup 5)
- Correct-answer feedback state (mockup 6)
- Incorrect-answer feedback state (mockup 7)
- Learn-mode redesign (mockup 8)
- Full-screen image inspection / zoom controls (mockup 9)
- Set-complete/result redesign (mockup 10)
- Simplified hosted-checkout support screen (mockup 11)
- Persistent bottom navigation on browsing/configuration screens
- Existing static anatomy annotations retained; no flashing/pulsing animation
- v7 source passes JSX/TypeScript transpilation with zero diagnostics

## Product-level issues still worth fixing

### P0 — before public launch

1. **Real payment backend**
   `/api/create-donation-checkout` is still only a frontend contract. A server/serverless function and merchant account must create the hosted checkout. Never put the merchant secret key into the public HTML.

2. **Production bundling**
   The preview HTML imports React/Lucide from `esm.sh`. A production deployment should bundle dependencies locally (Vite or similar), version assets, and remove reliance on third-party runtime module CDNs.

3. **Progress schema/version migration**
   Progress keys currently depend heavily on category/activity/structure names. When labels are renamed, old local progress can become orphaned. Introduce a stable structure ID plus a save-schema version and migration map.

4. **Final visual hotspot audit**
   Continue the plate-by-plate backlog. A structurally correct label with an inaccurate region/highlight still creates a bad question.

5. **Responsive QA**
   Test Android Chrome, iPhone Safari, tablet, desktop, orientation changes, browser zoom, and very small screens. Pay special attention to image zoom, long answer labels, and bottom navigation.

### P1 — soon after launch

6. **Accessibility**
   Add stronger keyboard focus styling, screen-reader descriptions for quiz state, explicit live regions for correct/incorrect feedback, and a non-color-only indicator for answer states.

7. **Offline/PWA hardening**
   Current service-worker logic is a foundation only. Precache the actual application bundle and selectively cache the anatomy plates. Avoid downloading all future subjects on first visit.

8. **Analytics dashboard**
   Track activation, Today's 10 completion, delayed recall success, weak-item recovery, D1/D7 return, and checkout conversion. The best learning metric remains delayed successful recall rather than raw time-in-app.

9. **Account sync later, not mandatory**
   Keep immediate no-login use. Offer optional sign-in only after a learner has created meaningful progress, then sync progress across devices.

10. **Module architecture**
    Anatomy is the first Aceapp module, not the product boundary. Before Biochemistry/Clinical Laboratory content is added, separate the shared learning engine from subject-specific datasets so new subjects reuse Practice / Review / Mastery / spaced retrieval.

### P2 — enhancements

11. **True pinch/pan zoom**
    v7 has a reliable full-screen enlarged inspection mode with zoom controls. Native pinch/pan would be a later polish improvement.

12. **Shareable mastery cards**
    Generate a visual result card with mastery, strongest system and milestone; keep it accomplishment-based rather than generic app promotion.

13. **Teacher/class mode**
    Much later: custom sets, assignment codes, class aggregate weak topics, and exportable results. This should not delay the learner MVP.

## Product direction

Aceapp's differentiator should remain **active retrieval for memorization-heavy medical material**, not becoming another long passive content library. Lessons can return later when they add something that videos/books/classes do not already solve well.

The reusable product loop is:
**see → retrieve → answer → immediate feedback → spaced revisit → demonstrate mastery.**

That loop can later support:
- Anatomy & Physiology identification
- Biochemistry nomenclature and structure drawing
- Hematology cell identification
- Clinical Chemistry analyte/method interpretation
- Urinalysis microscopy
- Microbiology organism/media identification
- other visual or recall-heavy medical subjects
