# Aceapp v49.1 — Startup Hotfix

This is a stability-only hotfix for v49 Readiness Matrix.

## Fixed
- Prevents the Readiness Matrix from eagerly evaluating every transfer check before startup has safely completed.
- Readiness calculations now run only for signed-in, loaded sessions and are guarded per structure.
- Unexpected legacy/saved-progress shapes can no longer blank the entire app; affected readiness evidence falls back safely.
- Added a React error boundary so an unexpected render problem shows an Aceapp Recovery screen instead of a blank page.
- Service-worker cache bumped to force the repaired startup path after deployment.

## Unchanged
- Anatomy data and coordinates are unchanged.
- All plate image files are unchanged.
- Firebase rules are unchanged.
- v49 Readiness Matrix and targeted prescriptions remain available.
